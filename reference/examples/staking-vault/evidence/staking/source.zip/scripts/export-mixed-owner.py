#!/usr/bin/env python3
"""Rebuild and package public staking source/unsigned evidence; no network or keys."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import zipfile

root = Path(__file__).resolve().parents[1]
out = root / 'integration/mixed-owner-v1'
out.mkdir(parents=True, exist_ok=True)
subprocess.run(['aiken', 'build'], cwd=root, check=True)
compiler = subprocess.check_output(['aiken', '--version'], cwd=root, text=True).strip()
blueprint = json.loads((root / 'plutus.json').read_text())
validators = {v['title']: v for v in blueprint['validators']}
mint = validators['single_staking.single_staking.mint']
spend = validators['single_staking.single_staking.spend']
assert mint['compiledCode'] == spend['compiledCode']
assert len(mint['parameters']) == 8
files = [root / 'aiken.toml', root / 'aiken.lock', root / 'MIXED-OWNER-INTERFACE.json']
for directory, pattern in [('lib', '*.ak'), ('validators', '*.ak'), ('offchain', '*.ts'), ('scripts', '*.py')]:
    files += sorted((root / directory).rglob(pattern))
files += [root / 'offchain/shared/authorization-vectors.json', root / 'FRAC-MIXED-OWNER-STATUS.md', root / 'MIXED-OWNER-AUTHORIZATION.md', root / 'offchain/README.md']
digests = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(out / 'source.zip', 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    for p in files:
        archive.write(p, str(p.relative_to(root)))
with zipfile.ZipFile(out / 'source.zip') as archive:
    for name, digest in digests.items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == digest
shutil.copyfile(root / 'plutus.json', out / 'blueprint.json')
shutil.copyfile(root / 'offchain/shared/authorization-vectors.json', out / 'authorization-vectors.json')
shutil.copyfile(root / 'MIXED-OWNER-INTERFACE.json', out / 'interface.json')
evidence = json.loads((out / 'emulator-evidence.json').read_text())
assert evidence['blueprintSha256'] == hashlib.sha256((root / 'plutus.json').read_bytes()).hexdigest()
assert evidence['referencePublication']['signedBytesMeasuredInEmulator'] <= 16384
assert evidence['initialization']['signedBytesMeasuredInEmulator'] <= 16384
manifest = {
    'schema': 'FRAC-MIXED-OWNER-BUILD-1', 'compiler': compiler,
    'ancestor': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'workingTree': True, 'sharedInterfaceVersion': 1, 'positionSchemaVersion': 2,
    'validatorTitles': [mint['title'], spend['title']],
    'parameters': [p['title'] for p in mint['parameters']],
    'unappliedScriptBytes': len(mint['compiledCode']) // 2,
    'blueprintSha256': hashlib.sha256((out / 'blueprint.json').read_bytes()).hexdigest(),
    'sourceArchiveSha256': hashlib.sha256((out / 'source.zip').read_bytes()).hexdigest(),
    'sources': digests, 'stakingHandlersImplemented': True,
    'evidenceSha256': {name: hashlib.sha256((out / name).read_bytes()).hexdigest() for name in ['emulator-evidence.json', 'reference-publication.unsigned.cbor', 'pool-initialization.unsigned.cbor']},
    'unsupportedActions': ['Vault standalone Withdraw', 'Vault standalone Claim', 'Vault Exit/CloseEmptyPosition (position NFT burn)', 'Same principal/reward asset in the registered CTVS vault profile'],
    'productionFactoryPolicy': None, 'externalFactoryIssuanceTested': False,
    'fullExternalControllerLifecycleTested': False, 'networkAcceptance': False,
    'deploymentReady': False, 'executionEnabled': False,
    'remainingIntegrationGates': [
        'Actual factory/controller publication and automatic registration acceptance in the vault repository',
        'Complete unsigned wallet-plus-two-real-vault lifecycle against both final programs',
        'Fresh vault-side import of this source-bound build and final size/budget evaluation',
    ],
}
(out / 'build.json').write_text(json.dumps(manifest, indent=2) + '\n')
print('Exported source-bound staking build:', out)
