import type { Network } from "npm:@lucid-evolution/lucid@0.4.29";
import { prepareSingleStaking } from "./scripts.ts";
import { type StakingConfig } from "./types.ts";
import { validAsset } from "./pool-registry.ts";
import { toUnit } from "npm:@lucid-evolution/lucid@0.4.29";

/** Restore the original parameters; never choose a fresh bootstrap for an existing pool. */
export async function loadPoolDeployment(
  path: string,
  network: Network,
  blueprintPath = "plutus.json",
) {
  const saved = JSON.parse(await Deno.readTextFile(path));
  const source = saved.config ?? JSON.parse(saved.identity ?? "{}");
  const ref = source.bootstrapRef ?? saved.bootstrapRef;
  if ((saved.network ?? source.network) !== network) {
    throw new Error("Pool deployment network mismatch.");
  }
  if (!validAsset(source.stakingAsset) || !validAsset(source.rewardAsset)) {
    throw new Error(
      "Pool has invalid original staking/reward asset parameters.",
    );
  }
  const tokens = {
    network,
    stakingAsset: source.stakingAsset,
    rewardAsset: source.rewardAsset,
    stakingUnit: toUnit(
      source.stakingAsset.policyId,
      source.stakingAsset.tokenNameHex,
    ),
    rewardUnit: toUnit(
      source.rewardAsset.policyId,
      source.rewardAsset.tokenNameHex,
    ),
    decimals: 6,
  };
  if (
    !/^[0-9a-f]{64}$/.test(ref?.txHash ?? "") ||
    !/^[0-9a-f]{56}$/.test(source.manager ?? "") ||
    !/^[0-9a-f]{56}$/.test(source.rewardsDistributor ?? "") ||
    typeof source.initiallyLocked !== "boolean" ||
    (source.vaultSupported !== undefined &&
      typeof source.vaultSupported !== "boolean")
  ) {
    throw new Error(
      "Pool deployment is missing its original validator parameters.",
    );
  }
  const index = BigInt(ref.outputIndex);
  if (index < 0n) throw new Error("Invalid bootstrap output index.");
  const config: StakingConfig = {
    bootstrapRef: { txHash: ref.txHash, outputIndex: index },
    manager: source.manager,
    rewardsDistributor: source.rewardsDistributor,
    stakingAsset: tokens.stakingAsset,
    rewardAsset: tokens.rewardAsset,
    initiallyLocked: source.initiallyLocked,
    ...(source.vaultSupported === undefined
      ? {}
      : { vaultSupported: source.vaultSupported }),
  };
  if (source.factoryPolicy !== undefined) {
    config.factoryPolicy = source.factoryPolicy;
  }
  const scripts = await prepareSingleStaking(config, network, blueprintPath);
  if (
    (saved.protocolVersion !== undefined &&
      saved.protocolVersion !== scripts.interfaceVersion) ||
    (saved.positionSchemaVersion !== undefined &&
      saved.positionSchemaVersion !== scripts.positionSchemaVersion)
  ) {
    throw new Error(
      "Deployment schema metadata does not match the authenticated script version.",
    );
  }
  if (
    scripts.poolPolicyId !== saved.poolPolicyId ||
    scripts.poolAddress !== saved.poolAddress
  ) {
    throw new Error(
      "Blueprint/parameters do not match the saved pool identity.",
    );
  }
  return { config, scripts, tokens };
}
