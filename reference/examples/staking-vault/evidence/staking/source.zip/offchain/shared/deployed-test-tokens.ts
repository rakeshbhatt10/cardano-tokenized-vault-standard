import type { AssetClass } from "./types.ts";

// These are the exact Mainnet units recorded by deploy-test-tokens.ts.
const TEST1_UNIT =
  "a85391660314dbb4c89b5e4eea88d8b256a60c121403ec04cc706f265465737431";
const TEST2_UNIT =
  "81fe6badbc95b6660ffd2f3f1e7333a7526acf8cca928dcc23f90a475465737432";

/** Read existing identities only. Does not derive new policies or mint tokens. */
export async function loadDeployedTestTokens(
  path = "offchain/test-tokens-state.json",
) {
  const journal = JSON.parse(await Deno.readTextFile(path));
  const identity = JSON.parse(journal.identity);
  if (
    identity.network !== "Mainnet" || !Array.isArray(identity.units) ||
    !identity.units.includes(TEST1_UNIT) ||
    !identity.units.includes(TEST2_UNIT) ||
    typeof journal.mintTx !== "string" || !/^[0-9a-f]{64}$/.test(journal.mintTx)
  ) {
    throw new Error(
      "Expected the saved Mainnet Test1/Test2 deployment; refusing substitute assets.",
    );
  }
  const asset = (unit: string): AssetClass => ({
    policyId: unit.slice(0, 56),
    tokenNameHex: unit.slice(56),
  });
  return {
    network: "Mainnet" as const,
    stakingAsset: asset(TEST1_UNIT),
    rewardAsset: asset(TEST2_UNIT),
    stakingUnit: TEST1_UNIT,
    rewardUnit: TEST2_UNIT,
    decimals: identity.decimals as number,
    recipientAddress: identity.recipient as string,
    mintTx: journal.mintTx as string,
  };
}
