import { checkpointPool, previewClaim } from "./rewards.ts";

Deno.test("Alice earns 60 then only 10 after her claim checkpoint", () => {
  const pool = {
    totalStaked: 1000n,
    periodFinishSeconds: 600n,
    rewardRate: 10n,
    lastUpdateSeconds: 0n,
    rewardPerTokenStored: 0n,
    accruedLiabilityBound: 0n,
  };
  const position = {
    stakedAmount: 100n,
    rewardPerTokenPaid: 0n,
    pendingRewards: 0n,
  };
  const first = previewClaim(pool, position, 60n);
  if (first.rewardAmount !== 60n) throw new Error("Expected 60");
  const second = previewClaim(
    {
      ...first.pool,
      accruedLiabilityBound: first.pool.accruedLiabilityBound -
        first.rewardAmount,
    },
    { ...first.position, pendingRewards: 0n },
    70n,
  );
  if (second.rewardAmount !== 10n) throw new Error("Old rewards claimed twice");
});
Deno.test("expiry caps emissions and empty pools allocate nothing", () => {
  const pool = {
    totalStaked: 1000n,
    periodFinishSeconds: 60n,
    rewardRate: 10n,
    lastUpdateSeconds: 0n,
    rewardPerTokenStored: 0n,
    accruedLiabilityBound: 0n,
  };
  if (checkpointPool(pool, 90n).accruedLiabilityBound !== 600n) {
    throw new Error("Rewards exceed period");
  }
  if (
    checkpointPool({ ...pool, totalStaked: 0n }, 60n).accruedLiabilityBound !==
      0n
  ) throw new Error("Empty pool accrued rewards");
});

Deno.test("integer rounding retains pending rewards", () => {
  const pool = {
    totalStaked: 3n,
    periodFinishSeconds: 600n,
    rewardRate: 1n,
    lastUpdateSeconds: 0n,
    rewardPerTokenStored: 0n,
    accruedLiabilityBound: 0n,
  };
  const position = {
    stakedAmount: 1n,
    rewardPerTokenPaid: 0n,
    pendingRewards: 7n,
  };
  if (previewClaim(pool, position, 1n).rewardAmount !== 7n) {
    throw new Error("Expected floor rounding");
  }
});
Deno.test("invalid stake and backwards time or accumulator are rejected", () => {
  const pool = {
    totalStaked: 1000n,
    periodFinishSeconds: 600n,
    rewardRate: 10n,
    lastUpdateSeconds: 60n,
    rewardPerTokenStored: 0n,
    accruedLiabilityBound: 0n,
  };
  const position = {
    stakedAmount: 100n,
    rewardPerTokenPaid: 1n,
    pendingRewards: 0n,
  };
  for (
    const run of [
      () => checkpointPool(pool, 59n),
      () => checkpointPool({ ...pool, totalStaked: -1n }, 60n),
      () => previewClaim({ ...pool, rewardRate: 0n }, position, 60n),
    ]
  ) {
    let rejected = false;
    try {
      run();
    } catch {
      rejected = true;
    }
    if (!rejected) throw new Error("Invalid input accepted");
  }
});

Deno.test("notification carries leftover and accrued liabilities", async () => {
  const { previewNotifyRewards } = await import("./rewards.ts");
  const next = previewNotifyRewards(
    {
      totalStaked: 1000n,
      periodFinishSeconds: 700n,
      rewardRate: 10n,
      lastUpdateSeconds: 100n,
      rewardPerTokenStored: 0n,
      accruedLiabilityBound: 0n,
    },
    3000n,
    600n,
    160n,
  );
  if (
    next.rewardRate !== 14n || next.periodFinishSeconds !== 760n ||
    next.accruedLiabilityBound !== 600n ||
    next.rewardPerTokenStored !== 600_000_000_000_000_000n
  ) throw new Error("Incorrect active notification arithmetic.");
});
