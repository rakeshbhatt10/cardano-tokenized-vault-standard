import {
  deepStrictEqual as assertEquals,
  throws as assertThrows,
} from "node:assert";
import { loadPools, selectPool, validatePools } from "./pool-registry.ts";

Deno.test("pool registry isolates existing and tokenC deployment journals", async () => {
  const pools = await loadPools("offchain/config/pools.json");
  const original = selectPool(pools, "test1-test2");
  const next = selectPool(pools, "tokenc-test2");
  assertEquals(original.statePath, "offchain/single-staking-state.json");
  assertEquals(next.statePath, "offchain/state/pools/tokenc-test2/pool.json");
  assertEquals(original.rewardAsset, next.rewardAsset);
  assertEquals(
    original.stakingAsset.policyId === next.stakingAsset.policyId,
    false,
  );
  assertThrows(() => selectPool(pools, "missing"));
});

Deno.test("pool registry rejects duplicate identities and aliased journals", async () => {
  const pools = await loadPools("offchain/config/pools.json");
  const duplicateId = structuredClone(pools);
  duplicateId[1].id = duplicateId[0].id;
  assertThrows(() => validatePools({ pools: duplicateId }));
  const duplicatePath = structuredClone(pools);
  duplicatePath[1].statePath = `./${duplicatePath[0].statePath}`;
  assertThrows(() => validatePools({ pools: duplicatePath }));
  const invalidAsset = structuredClone(pools);
  invalidAsset[1].stakingAsset.policyId = "invalid";
  assertThrows(() => validatePools({ pools: invalidAsset }));
});

Deno.test("registry rejects vault-supported pools with initial withdrawal locks", async () => {
  const pools = await loadPools("offchain/config/pools.json");
  pools[0].vaultSupported = true;
  pools[0].initiallyLocked = true;
  assertThrows(() => validatePools({ pools }), /Invalid pool configuration/);
  pools[0].initiallyLocked = false;
  assertEquals(validatePools({ pools })[0].vaultSupported, true);
});
