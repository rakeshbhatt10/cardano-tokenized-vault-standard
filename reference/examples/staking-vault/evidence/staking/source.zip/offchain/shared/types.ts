export type AssetClass = { policyId: string; tokenNameHex: string };
export type StakingConfig = {
  bootstrapRef: { txHash: string; outputIndex: bigint };
  manager: string;
  rewardsDistributor: string;
  stakingAsset: AssetClass;
  rewardAsset: AssetClass;
  initiallyLocked: boolean;
  /** Absent only for original six-parameter deployment records. */
  vaultSupported?: boolean;
  /** Explicit null for wallet-only eight-parameter pools; absent for legacy formats. */
  factoryPolicy?: string | null;
};
