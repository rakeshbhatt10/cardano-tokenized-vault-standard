import {
  type LucidEvolution,
  type TxBuilder,
  validatorToScriptHash,
} from "npm:@lucid-evolution/lucid@0.4.29";
import type { StakingScripts } from "./scripts.ts";

/** One shared program serves mint and spend; use a verified reference when supplied. */
export function attachStakingProgram(tx: TxBuilder, scripts: StakingScripts) {
  const reference = scripts.referenceUtxo;
  if (reference) {
    if (
      !reference.scriptRef ||
      validatorToScriptHash(reference.scriptRef) !== scripts.poolPolicyId
    ) {
      throw new Error(
        "Staking reference does not carry the exact pool script.",
      );
    }
    return tx.readFrom([reference]);
  }
  return tx.attach.SpendingValidator(scripts.spendingValidator);
}

export function stakingTransaction(
  lucid: LucidEvolution,
  scripts: StakingScripts,
) {
  return attachStakingProgram(lucid.newTx(), scripts);
}
