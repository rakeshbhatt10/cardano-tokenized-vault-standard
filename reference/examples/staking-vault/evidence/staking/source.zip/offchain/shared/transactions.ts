import type { LucidEvolution } from "npm:@lucid-evolution/lucid@0.4.29";
export async function confirmTransaction(
  lucid: LucidEvolution,
  hash: string,
) {
  if (!await lucid.awaitTx(hash)) {
    throw new Error(
      `Confirmation missing for ${hash}; resume with the same state.`,
    );
  }
}

/** Query current state by identity, never by a possibly spent cached reference. */
export async function findStateUtxo(
  lucid: LucidEvolution,
  poolAddress: string,
  unit: string,
) {
  const utxos = await lucid.utxosAtWithUnit(poolAddress, unit);
  if (utxos.length !== 1 || utxos[0].assets[unit] !== 1n) {
    throw new Error(
      "Expected one authenticated state UTxO; retry after indexing catches up.",
    );
  }
  return utxos[0];
}

/** Sum only the requested asset; reward tokens and ADA are excluded. */
export async function walletTokenBalance(lucid: LucidEvolution, unit: string) {
  return (await lucid.wallet().getUtxos()).reduce(
    (sum, utxo) => sum + (utxo.assets[unit] ?? 0n),
    0n,
  );
}
