import {
  type Credential,
  credentialToAddress,
  type Network,
} from "npm:@lucid-evolution/lucid@0.4.29";
import { Constr, Data } from "npm:@lucid-evolution/lucid@0.4.29";
import type { PoolRewards, PositionRewards } from "./rewards.ts";

export type PoolState = PoolRewards & {
  rewardDurationSeconds: bigint;
  isPaused: boolean;
  isLocked: boolean;
};
export function encodePoolDatum(pool: PoolState): string {
  return Data.to(
    new Constr(0, [
      new Constr(0, [
        pool.totalStaked,
        pool.rewardDurationSeconds,
        pool.periodFinishSeconds,
        pool.rewardRate,
        pool.lastUpdateSeconds,
        pool.rewardPerTokenStored,
        pool.accruedLiabilityBound,
        new Constr(pool.isPaused ? 1 : 0, []),
        new Constr(pool.isLocked ? 1 : 0, []),
      ]),
    ]),
  );
}
export function decodePoolDatum(cbor: string): PoolState {
  const outer = Data.from(cbor);
  if (
    !(outer instanceof Constr) || outer.index !== 0 || outer.fields.length !== 1
  ) throw new Error("Expected Pool datum.");
  const record = outer.fields[0];
  if (
    !(record instanceof Constr) || record.index !== 0 ||
    record.fields.length !== 9
  ) throw new Error("Malformed PoolDatum.");
  const integer = (i: number) => {
    const value = record.fields[i];
    if (typeof value !== "bigint" || value < 0n) {
      throw new Error("Invalid pool integer.");
    }
    return value;
  };
  const boolean = (i: number) => {
    const value = record.fields[i];
    if (
      !(value instanceof Constr) || value.fields.length !== 0 ||
      (value.index !== 0 && value.index !== 1)
    ) throw new Error("Invalid pool boolean.");
    return value.index === 1;
  };
  return {
    totalStaked: integer(0),
    rewardDurationSeconds: integer(1),
    periodFinishSeconds: integer(2),
    rewardRate: integer(3),
    lastUpdateSeconds: integer(4),
    rewardPerTokenStored: integer(5),
    accruedLiabilityBound: integer(6),
    isPaused: boolean(7),
    isLocked: boolean(8),
  };
}

export const POSITION_SCHEMA_VERSION = 2 as const;
export type PositionSchemaVersion = 1 | 2;
export type PositionOwner =
  | { kind: "WalletOwner"; paymentKeyHash: string }
  | {
    kind: "VaultOwner";
    controllerScriptHash: string;
    statePolicyId: string;
    stateAssetName: string;
  };

function hash28(value: unknown): string {
  if (typeof value !== "string" || !/^[0-9a-f]{56}$/.test(value)) {
    throw new Error("Expected 28-byte owner hash.");
  }
  return value;
}
function assetName(value: unknown): string {
  if (typeof value !== "string" || !/^(?:[0-9a-f]{2}){0,32}$/.test(value)) {
    throw new Error("Invalid State asset name.");
  }
  return value;
}
export function encodePositionOwner(owner: PositionOwner): Data {
  switch (owner.kind) {
    case "WalletOwner":
      return new Constr(0, [hash28(owner.paymentKeyHash)]);
    case "VaultOwner":
      return new Constr(1, [
        hash28(owner.controllerScriptHash),
        hash28(owner.statePolicyId),
        assetName(owner.stateAssetName),
      ]);
    default:
      throw new Error("Unsupported position owner.");
  }
}
export function decodePositionOwner(data: Data): PositionOwner {
  if (!(data instanceof Constr)) {
    throw new Error("Expected tagged position owner.");
  }
  if (data.index === 0 && data.fields.length === 1) {
    return { kind: "WalletOwner", paymentKeyHash: hash28(data.fields[0]) };
  }
  if (data.index === 1 && data.fields.length === 3) {
    return {
      kind: "VaultOwner",
      controllerScriptHash: hash28(data.fields[0]),
      statePolicyId: hash28(data.fields[1]),
      stateAssetName: assetName(data.fields[2]),
    };
  }
  throw new Error("Unsupported position owner tag or fields.");
}
export function walletOwnerKey(owner: PositionOwner): string {
  if (owner.kind !== "WalletOwner") {
    throw new Error(
      "Vault positions require controller authorization; wallet builder cannot authorize them.",
    );
  }
  return hash28(owner.paymentKeyHash);
}

export type PositionState = PositionRewards & {
  poolId: string;
  positionName: string;
  owner: PositionOwner;
  payoutAddress: Data;
};
export function encodePositionDatum(
  position: PositionState,
  version: PositionSchemaVersion = POSITION_SCHEMA_VERSION,
): string {
  if (version !== 1 && version !== 2) {
    throw new Error("Unsupported position schema version.");
  }
  const fields: Data[] = [
    position.poolId,
    position.positionName,
    version === 1
      ? walletOwnerKey(position.owner)
      : encodePositionOwner(position.owner),
    position.payoutAddress,
    position.stakedAmount,
    position.rewardPerTokenPaid,
    position.pendingRewards,
  ];
  if (version === 2) fields.unshift(BigInt(POSITION_SCHEMA_VERSION));
  return Data.to(new Constr(1, [new Constr(0, fields)]));
}
export function decodePositionDatum(
  cbor: string,
  version: PositionSchemaVersion = POSITION_SCHEMA_VERSION,
): PositionState {
  if (version !== 1 && version !== 2) {
    throw new Error("Unsupported position schema version.");
  }
  const outer = Data.from(cbor);
  if (
    !(outer instanceof Constr) || outer.index !== 1 || outer.fields.length !== 1
  ) throw new Error("Expected Position datum.");
  const record = outer.fields[0];
  if (
    !(record instanceof Constr) || record.index !== 0 ||
    record.fields.length !== (version === 1 ? 7 : 8)
  ) throw new Error("Malformed or mismatched PositionDatum schema.");
  if (version === 2 && record.fields[0] !== BigInt(POSITION_SCHEMA_VERSION)) {
    throw new Error("Unsupported position schema version.");
  }
  const fields = version === 1 ? record.fields : record.fields.slice(1);
  const bytes = (i: number) => {
    const value = fields[i];
    if (typeof value !== "string") {
      throw new Error("Invalid position identity.");
    }
    return value;
  };
  const integer = (i: number) => {
    const value = fields[i];
    if (typeof value !== "bigint" || value < 0n) {
      throw new Error("Invalid position quantity.");
    }
    return value;
  };
  return {
    poolId: bytes(0),
    positionName: bytes(1),
    owner: version === 1
      ? { kind: "WalletOwner", paymentKeyHash: hash28(fields[2]) }
      : decodePositionOwner(fields[2]),
    payoutAddress: fields[3],
    stakedAmount: integer(4),
    rewardPerTokenPaid: integer(5),
    pendingRewards: integer(6),
  };
}

/** Decode the immutable base/enterprise payout address used by position builders. */
export function positionPayoutAddress(
  position: PositionState,
  network: Network,
): string {
  const address = position.payoutAddress;
  if (
    !(address instanceof Constr) || address.index !== 0 ||
    address.fields.length !== 2
  ) throw new Error("Invalid payout address.");
  const credential = (value: Data): Credential => {
    if (
      !(value instanceof Constr) || value.fields.length !== 1 ||
      typeof value.fields[0] !== "string" ||
      (value.index !== 0 && value.index !== 1)
    ) throw new Error("Invalid address credential.");
    return {
      type: value.index === 0 ? "Key" : "Script",
      hash: value.fields[0],
    };
  };
  const payment = credential(address.fields[0]);
  if (
    payment.type !== "Key" || payment.hash !== walletOwnerKey(position.owner)
  ) {
    throw new Error("Payout address is not controlled by position owner.");
  }
  const option = address.fields[1];
  if (!(option instanceof Constr)) {
    throw new Error("Invalid stake credential option.");
  }
  let staking: Credential | undefined;
  if (option.index === 0 && option.fields.length === 1) {
    const inline = option.fields[0];
    if (
      !(inline instanceof Constr) || inline.index !== 0 ||
      inline.fields.length !== 1
    ) throw new Error("Pointer payout addresses are unsupported.");
    staking = credential(inline.fields[0]);
  } else if (option.index !== 1 || option.fields.length !== 0) {
    throw new Error("Invalid stake credential option.");
  }
  return credentialToAddress(network, payment, staking);
}
