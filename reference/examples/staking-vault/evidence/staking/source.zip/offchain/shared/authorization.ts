import { Constr, Data } from "npm:@lucid-evolution/plutus@0.1.29";
import {
  type Authorization,
  decodeAuthorization,
  encodeAuthorization,
  stakingAction,
  type Wire,
} from "./authorization-wire.ts";
const bytes = (s: string) =>
  Uint8Array.from(s.match(/../g)?.map((b) => parseInt(b, 16)) ?? []);
function fromSdk(v: Data): Wire {
  if (typeof v === "bigint") return v;
  if (typeof v === "string") return bytes(v);
  if (v instanceof Constr) {
    return { constr: v.index, fields: v.fields.map(fromSdk) };
  }
  if (Array.isArray(v)) return v.map(fromSdk);
  if (v instanceof Map) {
    return { map: Array.from(v, ([k, x]) => [fromSdk(k), fromSdk(x)]) };
  }
  throw Error("Unsupported authorization Data");
}
function toSdk(v: Wire): Data {
  if (typeof v === "bigint") return v;
  if (v instanceof Uint8Array) {
    return Array.from(v, (b) => b.toString(16).padStart(2, "0")).join("");
  }
  if (Array.isArray(v)) return v.map(toSdk);
  if ("constr" in v) return new Constr(Number(v.constr), v.fields.map(toSdk));
  return new Map(v.map.map(([k, x]) => [toSdk(k), toSdk(x)]));
}
export const encodeVaultAuthorization = (a: Authorization) =>
  Data.to(toSdk(encodeAuthorization(a)));
export const decodeVaultAuthorization = (cbor: string) =>
  decodeAuthorization(fromSdk(Data.from(cbor)));
export { fromSdk, toSdk };
export type { Authorization };

import { decodeRegistration } from "./registration-wire.ts";
export const decodeFactoryRegistration = (cbor: string) =>
  decodeRegistration(fromSdk(Data.from(cbor)));

export const encodeStakingOperation = (authorizationCbor: string) =>
  Data.to(toSdk(stakingAction(decodeVaultAuthorization(authorizationCbor))));
