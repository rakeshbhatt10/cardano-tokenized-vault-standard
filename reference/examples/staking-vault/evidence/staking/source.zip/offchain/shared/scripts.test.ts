import { deepStrictEqual, notStrictEqual, rejects } from "node:assert";
import { prepareSingleStaking } from "./scripts.ts";
import type { StakingConfig } from "./types.ts";

const config: StakingConfig = {
  bootstrapRef: { txHash: "ab".repeat(32), outputIndex: 0n },
  manager: "11".repeat(28),
  rewardsDistributor: "11".repeat(28),
  stakingAsset: { policyId: "22".repeat(28), tokenNameHex: "41" },
  rewardAsset: { policyId: "33".repeat(28), tokenNameHex: "42" },
  initiallyLocked: false,
  vaultSupported: false,
  factoryPolicy: null,
};

Deno.test("vault support changes immutable pool identity and rejects initial locking", async () => {
  const wallet = await prepareSingleStaking(config, "Custom");
  const vault = await prepareSingleStaking(
    { ...config, vaultSupported: true, factoryPolicy: "55".repeat(28) },
    "Custom",
  );
  notStrictEqual(wallet.poolPolicyId, vault.poolPolicyId);
  await rejects(
    () =>
      prepareSingleStaking({
        ...config,
        vaultSupported: true,
        initiallyLocked: true,
      }, "Custom"),
    /cannot start/,
  );
  const { vaultSupported: _ignored, ...missing } = config;
  await rejects(
    () => prepareSingleStaking(missing, "Custom"),
    /version does not match/,
  );
});

Deno.test("original six-parameter deployment identity remains reproducible", async () => {
  const directory = "deployments/mainnet/staking-pool";
  const record = JSON.parse(
    await Deno.readTextFile(`${directory}/deployment.json`),
  );
  const original: StakingConfig = {
    ...record.validatorParameters,
    bootstrapRef: {
      ...record.validatorParameters.bootstrapRef,
      outputIndex: BigInt(record.validatorParameters.bootstrapRef.outputIndex),
    },
  };
  const scripts = await prepareSingleStaking(
    original,
    "Mainnet",
    `${directory}/plutus.json`,
  );
  deepStrictEqual(scripts.poolPolicyId, record.poolPolicyId);
  deepStrictEqual(scripts.poolAddress, record.poolAddress);
  await rejects(
    () =>
      prepareSingleStaking(
        { ...original, vaultSupported: false },
        "Mainnet",
        `${directory}/plutus.json`,
      ),
    /version does not match/,
  );
});

Deno.test("factory trust anchor is mandatory, immutable and absent for wallet-only pools", async () => {
  await rejects(
    () => prepareSingleStaking({ ...config, vaultSupported: true }, "Custom"),
    /explicit factory policy/,
  );
  await rejects(
    () =>
      prepareSingleStaking(
        { ...config, factoryPolicy: "55".repeat(28) },
        "Custom",
      ),
    /wallet-only/,
  );
  await rejects(
    () =>
      prepareSingleStaking({
        ...config,
        vaultSupported: true,
        factoryPolicy: "55",
      }, "Custom"),
    /identity hex/,
  );
  const { factoryPolicy: _ignored, ...missing } = config;
  await rejects(
    () => prepareSingleStaking(missing, "Custom"),
    /explicit factoryPolicy/,
  );
  const first = await prepareSingleStaking({
    ...config,
    vaultSupported: true,
    factoryPolicy: "55".repeat(28),
  }, "Custom");
  const second = await prepareSingleStaking({
    ...config,
    vaultSupported: true,
    factoryPolicy: "66".repeat(28),
  }, "Custom");
  notStrictEqual(first.poolPolicyId, second.poolPolicyId);
  deepStrictEqual(first.interfaceVersion, "factory-v1");
});
