import { Constr, Data } from "npm:@lucid-evolution/lucid@0.4.29";
export const initializePoolRedeemer = () => Data.to(new Constr(0, []));
export const claimRedeemer = (positionNameHex: string) =>
  Data.to(new Constr(2, [positionNameHex]));

import {
  encodePositionOwner,
  POSITION_SCHEMA_VERSION,
  type PositionOwner,
  type PositionSchemaVersion,
  walletOwnerKey,
} from "./datum.ts";

/** IdentityAction.OpenPosition: legacy wallet format or versioned tagged owner. */
export function openPositionRedeemer(
  creationRef: Data,
  owner: PositionOwner,
  version: PositionSchemaVersion = POSITION_SCHEMA_VERSION,
): string {
  if (version === 1) {
    return Data.to(new Constr(1, [creationRef, walletOwnerKey(owner)]));
  }
  if (version !== 2) throw new Error("Unsupported position schema version.");
  return Data.to(
    new Constr(1, [
      BigInt(POSITION_SCHEMA_VERSION),
      creationRef,
      encodePositionOwner(owner),
    ]),
  );
}
