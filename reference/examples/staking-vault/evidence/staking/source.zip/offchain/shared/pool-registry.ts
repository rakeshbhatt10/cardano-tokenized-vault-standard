/** Public deployment inventory. Pool selection must be explicit when using the registry. */
import { toUnit } from "npm:@lucid-evolution/lucid@0.4.29";
import type { AssetClass } from "./types.ts";

export type PoolDefinition = {
  id: string;
  name: string;
  deploy: boolean;
  network: "Mainnet";
  stakingAsset: AssetClass;
  rewardAsset: AssetClass;
  decimals: number;
  rewardAmountBaseUnits: string;
  durationSeconds: string;
  initiallyLocked: boolean;
  vaultSupported?: boolean;
  factoryPolicy?: string | null;
  statePath: string;
  stakerStatePath: string;
  deploymentDirectory: string;
  blueprintPath: string;
  tokenManifestPath: string;
};
export function validAsset(asset: AssetClass): boolean {
  return !!asset && /^[0-9a-f]{56}$/.test(asset.policyId) &&
    /^(?:[0-9a-f]{2}){0,32}$/.test(asset.tokenNameHex);
}
export function validatePools(
  value: { pools: PoolDefinition[] },
): PoolDefinition[] {
  if (!value || !Array.isArray(value.pools) || !value.pools.length) {
    throw new Error("Pool registry must contain a nonempty pools array.");
  }
  const ids = new Set<string>();
  const paths = new Set<string>();
  for (const p of value.pools) {
    if (!p || !/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(p.id) || ids.has(p.id)) {
      throw new Error("Pool IDs must be unique lowercase names.");
    }
    if (
      typeof p.name !== "string" || !p.name.trim() || p.network !== "Mainnet" ||
      typeof p.deploy !== "boolean" ||
      typeof p.initiallyLocked !== "boolean" || p.decimals !== 6 ||
      (p.vaultSupported !== undefined &&
        typeof p.vaultSupported !== "boolean") ||
      (p.vaultSupported === true && p.initiallyLocked) ||
      (p.factoryPolicy !== undefined && p.factoryPolicy !== null &&
        !/^[0-9a-f]{56}$/.test(p.factoryPolicy)) ||
      (p.factoryPolicy !== undefined &&
        (p.vaultSupported === true
          ? p.factoryPolicy === null
          : p.factoryPolicy !== null)) ||
      !validAsset(p.stakingAsset) || !validAsset(p.rewardAsset)
    ) throw new Error(`Invalid pool configuration: ${p.id}`);
    if (
      !/^[1-9][0-9]*$/.test(p.rewardAmountBaseUnits) ||
      !/^[1-9][0-9]*$/.test(p.durationSeconds) ||
      BigInt(p.rewardAmountBaseUnits) < BigInt(p.durationSeconds)
    ) throw new Error(`Invalid reward budget/duration: ${p.id}`);
    for (
      const path of [
        p.statePath,
        p.stakerStatePath,
        p.deploymentDirectory,
        p.blueprintPath,
        p.tokenManifestPath,
      ]
    ) {
      if (
        typeof path !== "string" || !path || path.startsWith("/") ||
        path.split("/").includes("..") ||
        paths.has(
          path.split("/").filter((part) => part && part !== ".").join("/"),
        )
      ) {
        throw new Error(
          "Each pool must use distinct repository-relative journal/artifact paths.",
        );
      }
      paths.add(
        path.split("/").filter((part) => part && part !== ".").join("/"),
      );
    }
    ids.add(p.id);
  }
  return value.pools;
}
export async function loadPools(
  path = Deno.env.get("POOLS_CONFIG_PATH") ?? "offchain/config/pools.json",
) {
  return validatePools(JSON.parse(await Deno.readTextFile(path)));
}
export function selectPool(pools: PoolDefinition[], id: string) {
  const pool = pools.find((p) => p.id === id);
  if (!pool) throw new Error(`Unknown POOL_ID: ${id}`);
  return pool;
}
export async function loadSelectedPool(): Promise<PoolDefinition | undefined> {
  const id = Deno.env.get("POOL_ID")?.trim();
  return id ? selectPool(await loadPools(), id) : undefined;
}
export function poolAssets(pool: PoolDefinition) {
  return {
    network: pool.network,
    stakingAsset: pool.stakingAsset,
    rewardAsset: pool.rewardAsset,
    stakingUnit: toUnit(
      pool.stakingAsset.policyId,
      pool.stakingAsset.tokenNameHex,
    ),
    rewardUnit: toUnit(
      pool.rewardAsset.policyId,
      pool.rewardAsset.tokenNameHex,
    ),
    decimals: pool.decimals,
  };
}
