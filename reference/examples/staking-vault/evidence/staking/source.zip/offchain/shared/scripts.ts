import { factoryTrustParameter } from "./authorization-wire.ts";
import {
  applyParamsToScript,
  Constr,
  type MintingPolicy,
  mintingPolicyToId,
  type Network,
  type SpendingValidator,
  type UTxO,
  validatorToAddress,
} from "npm:@lucid-evolution/lucid@0.4.29";
import { type AssetClass, type StakingConfig } from "./types.ts";

/** Prepare scripts only: does not initialize a pool or submit transactions. */
export async function prepareSingleStaking(
  config: StakingConfig,
  network: Network,
  blueprintPath = "plutus.json",
) {
  const blueprint = JSON.parse(await Deno.readTextFile(blueprintPath));
  const mint = blueprint.validators.find((v: { title: string }) =>
    v.title === "single_staking.single_staking.mint"
  );
  const spend = blueprint.validators.find((v: { title: string }) =>
    v.title === "single_staking.single_staking.spend"
  );
  if (
    blueprint.preamble?.plutusVersion !== "v3" || !mint || !spend ||
    ![6, 7, 8].includes(mint.parameters?.length) ||
    mint.parameters?.length !== spend.parameters?.length
  ) {
    throw new Error(
      "Build a supported single_staking mint/spend validator first.",
    );
  }
  const parameterCount = mint.parameters.length;
  const expectedNames = [
    "bootstrap_ref",
    "manager",
    "rewards_distributor",
    "staking_asset",
    "reward_asset",
    "initially_locked",
    "vault_supported",
    "factory_policy",
  ].slice(0, parameterCount);
  for (const validator of [mint, spend]) {
    if (
      validator.parameters.some((p: { title: string }, i: number) =>
        p.title !== expectedNames[i]
      )
    ) {
      throw new Error("Unsupported single_staking parameter names/order.");
    }
  }
  const legacy = parameterCount === 6;
  const factoryVersion = parameterCount === 8;
  if (
    legacy
      ? config.vaultSupported !== undefined
      : typeof config.vaultSupported !== "boolean"
  ) {
    throw new Error(
      "Validator version does not match vaultSupported parameters.",
    );
  }
  if (config.vaultSupported && config.initiallyLocked) {
    throw new Error(
      "Vault-supported pools cannot start with withdrawals locked.",
    );
  }
  if (factoryVersion) {
    if (config.factoryPolicy === undefined) {
      throw new Error(
        "Eight-parameter pools require explicit factoryPolicy (null for wallet-only).",
      );
    }
    factoryTrustParameter(config.vaultSupported!, config.factoryPolicy);
  } else if (config.factoryPolicy !== undefined) {
    throw new Error("Legacy validator does not accept factoryPolicy.");
  }
  const asset = (a: AssetClass) => new Constr(0, [a.policyId, a.tokenNameHex]);
  const params = [
    new Constr(0, [
      config.bootstrapRef.txHash,
      config.bootstrapRef.outputIndex,
    ]),
    config.manager,
    config.rewardsDistributor,
    asset(config.stakingAsset),
    asset(config.rewardAsset),
    new Constr(config.initiallyLocked ? 1 : 0, []),
  ];
  if (!legacy) params.push(new Constr(config.vaultSupported ? 1 : 0, []));
  if (factoryVersion) {
    params.push(
      config.factoryPolicy === null
        ? new Constr(1, [])
        : new Constr(0, [config.factoryPolicy!]),
    );
  }
  const mintScript = applyParamsToScript(mint.compiledCode, params);
  const spendScript = applyParamsToScript(spend.compiledCode, params);
  if (mintScript !== spendScript) {
    throw new Error("Expected one shared mint/spend script for pool identity.");
  }
  const mintingPolicy: MintingPolicy = { type: "PlutusV3", script: mintScript };
  const spendingValidator: SpendingValidator = {
    type: "PlutusV3",
    script: spendScript,
  };
  return {
    mintingPolicy,
    interfaceVersion: factoryVersion
      ? "factory-v1" as const
      : legacy
      ? "wallet-v1" as const
      : "owner-v2" as const,
    positionSchemaVersion: legacy ? 1 as const : 2 as const,
    spendingValidator,
    poolPolicyId: mintingPolicyToId(mintingPolicy),
    poolAddress: validatorToAddress(network, spendingValidator),
    stakingAsset: config.stakingAsset,
    rewardAsset: config.rewardAsset,
  };
}

export type StakingScripts =
  & Awaited<ReturnType<typeof prepareSingleStaking>>
  & {
    /** Fresh caller-supplied reference UTxO carrying this exact shared script. */
    referenceUtxo?: UTxO;
  };
