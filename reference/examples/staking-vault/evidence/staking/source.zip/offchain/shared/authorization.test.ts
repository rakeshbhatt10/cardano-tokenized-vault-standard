import { Constr, Data } from "npm:@lucid-evolution/plutus@0.1.29";
import { deepStrictEqual, equal, throws } from "node:assert";
import {
  decodeFactoryRegistration,
  decodeVaultAuthorization,
  encodeStakingOperation,
  encodeVaultAuthorization,
} from "./authorization.ts";
const vectors = JSON.parse(
  Deno.readTextFileSync(
    new URL("./authorization-vectors.json", import.meta.url),
  ),
).vectors as {
  name: string;
  accepted: boolean;
  cbor: string;
  stakingCbor?: string;
}[];
for (const v of vectors) {
  Deno.test("shared authorization vector: " + v.name, () => {
    if (!v.accepted) {
      throws(() => decodeVaultAuthorization(v.cbor));
      return;
    }
    const decoded = decodeVaultAuthorization(v.cbor);
    if (v.stakingCbor) equal(encodeStakingOperation(v.cbor), v.stakingCbor);
    else throws(() => encodeStakingOperation(v.cbor));
    equal(encodeVaultAuthorization(decoded), v.cbor);
    deepStrictEqual(
      decodeVaultAuthorization(encodeVaultAuthorization(decoded)),
      decoded,
    );
  });
}

Deno.test("factory registration profile rejects the identity-only probe", () => {
  const controller = "11".repeat(28),
    base = [
      1n,
      controller,
      controller,
      "5354415445",
      "43545653312d4d495845442d464143544f52592d31",
      "22".repeat(32),
      "33".repeat(32),
    ];
  equal(
    decodeFactoryRegistration(Data.to(new Constr(0, base))).controller,
    controller,
  );
  base[4] = "464143544f52592d4944454e544954592d50524f42452d31";
  throws(() => decodeFactoryRegistration(Data.to(new Constr(0, base))));
});
