import { deepStrictEqual as equal, throws } from "node:assert";
import { Constr, Data } from "npm:@lucid-evolution/lucid@0.4.29";
import {
  decodePositionDatum,
  decodePositionOwner,
  encodePositionDatum,
  encodePositionOwner,
  POSITION_SCHEMA_VERSION,
  type PositionOwner,
  type PositionState,
  walletOwnerKey,
} from "./datum.ts";
import { openPositionRedeemer } from "./redeemers.ts";
const wallet: PositionOwner = {
  kind: "WalletOwner",
  paymentKeyHash: "11".repeat(28),
};
const vault: PositionOwner = {
  kind: "VaultOwner",
  controllerScriptHash: "22".repeat(28),
  statePolicyId: "33".repeat(28),
  stateAssetName: "5354415445",
};
const position = (owner: PositionOwner): PositionState => ({
  poolId: "44".repeat(28),
  positionName: "55".repeat(32),
  owner,
  payoutAddress: new Constr(0, [
    new Constr(owner.kind === "WalletOwner" ? 0 : 1, [
      owner.kind === "WalletOwner"
        ? owner.paymentKeyHash
        : owner.controllerScriptHash,
    ]),
    new Constr(1, []),
  ]),
  stakedAmount: 100n,
  rewardPerTokenPaid: 3n,
  pendingRewards: 7n,
});
Deno.test("version 2 position owners and OpenPosition have explicit constructor layouts", () => {
  equal(encodePositionOwner(wallet), new Constr(0, ["11".repeat(28)]));
  equal(
    encodePositionOwner(vault),
    new Constr(1, ["22".repeat(28), "33".repeat(28), "5354415445"]),
  );
  for (const owner of [wallet, vault]) {
    equal(
      decodePositionDatum(encodePositionDatum(position(owner))),
      position(owner),
    );
    const ref = new Constr(0, ["ab".repeat(32), 0n]);
    equal(
      Data.from(openPositionRedeemer(ref, owner)),
      new Constr(1, [
        BigInt(POSITION_SCHEMA_VERSION),
        ref,
        encodePositionOwner(owner),
      ]),
    );
  }
});
Deno.test("legacy position and mint codecs preserve original bytes without guessing schema", () => {
  const p = position(wallet);
  const legacy = Data.to(
    new Constr(1, [
      new Constr(0, [
        p.poolId,
        p.positionName,
        walletOwnerKey(wallet),
        p.payoutAddress,
        100n,
        3n,
        7n,
      ]),
    ]),
  );
  equal(encodePositionDatum(p, 1), legacy);
  equal(decodePositionDatum(legacy, 1), p);
  const ref = new Constr(0, ["ab".repeat(32), 0n]);
  equal(
    Data.from(openPositionRedeemer(ref, wallet, 1)),
    new Constr(1, [ref, walletOwnerKey(wallet)]),
  );
  throws(() => decodePositionDatum(legacy));
  throws(() => decodePositionDatum(encodePositionDatum(p), 1));
  throws(
    () => encodePositionDatum(position(vault), 1),
    /controller authorization/,
  );
  throws(() => openPositionRedeemer(ref, vault, 1), /controller authorization/);
});
Deno.test("owner codecs reject untagged hashes, unknown tags, malformed hashes and fields", () => {
  for (
    const invalid of [
      "11".repeat(28),
      new Constr(2, []),
      new Constr(0, []),
      new Constr(0, ["11"]),
      new Constr(1, ["22".repeat(28), "33".repeat(28), "aa".repeat(33)]),
      new Constr(1, ["22".repeat(28), "33".repeat(28), "zz"]),
    ]
  ) {
    throws(() => decodePositionOwner(invalid));
  }
  throws(() => walletOwnerKey(vault), /controller authorization/);
  const outer = Data.from(encodePositionDatum(position(wallet))) as Constr<
    Data
  >;
  (outer.fields[0] as Constr<Data>).fields[0] = 3n;
  throws(
    () => decodePositionDatum(Data.to(outer)),
    /Unsupported position schema/,
  );
});
