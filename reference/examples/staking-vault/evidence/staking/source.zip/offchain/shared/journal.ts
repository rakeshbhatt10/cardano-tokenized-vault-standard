import { dirname } from "node:path";

export function stringify(value: unknown): string {
  return JSON.stringify(
    value,
    (_, field) => typeof field === "bigint" ? field.toString() : field,
    2,
  );
}

/** Replace JSON atomically; supports bigint without losing precision. */
export async function writeJsonAtomic(path: string, value: unknown) {
  await Deno.mkdir(dirname(path), { recursive: true });
  await Deno.writeTextFile(`${path}.tmp`, stringify(value));
  await Deno.rename(`${path}.tmp`, path);
}

/** One local run per journal. A terminated process can leave a stale lock. */
export async function withStateLock<T>(
  path: string,
  work: () => Promise<T>,
): Promise<T> {
  await Deno.mkdir(dirname(path), { recursive: true });
  const lock = await Deno.open(`${path}.lock`, {
    write: true,
    createNew: true,
  });
  try {
    return await work();
  } finally {
    lock.close();
    await Deno.remove(`${path}.lock`);
  }
}
