/** Test2 has six decimals. Budget: 10 display tokens/day for seven days. */
export const REWARD_DECIMALS = 6;
export const DAILY_REWARD_BUDGET = 10n * 10n ** BigInt(REWARD_DECIMALS);
export const INITIAL_REWARD_DURATION = 7n * 86_400n;
export const INITIAL_REWARD_AMOUNT = DAILY_REWARD_BUDGET * 7n; // 70,000,000 base units
// On-chain integer division rounds this to 115 base units/second.
export const INITIAL_REWARD_RATE = INITIAL_REWARD_AMOUNT /
  INITIAL_REWARD_DURATION;
