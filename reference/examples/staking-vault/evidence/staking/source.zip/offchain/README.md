# Off-chain modules

Run commands from the repository root. `owner/` contains pool setup and owner
operations; `user/` contains staker operations. `shared/` supplies role-neutral
configuration, codecs, accounting and transaction utilities. Importing a
`mod.ts` API does not connect a wallet or submit a transaction.

```text
offchain/
  owner/
    deploy-single-staking.ts       Pool initialization and first notification
    fund-rewards.ts                Add reward reserves
    recover-surplus.ts             Recover protected surplus
    toggle-pause.ts                Pause/resume deposits
    toggle-withdraw-lock.ts        Enable/disable withdrawal locking
    generate-wallet.ts            Generate the owner wallet locally
    setup/                        Bootstrap, applied parameters, deployment journal
    builders/                     Unsigned owner/distributor transactions
    flows/                        Shared manager control orchestration
    tokens/                       Token minting, configuration, recipient generation
    wallet.ts                     Owner signing/provider configuration
    mod.ts                        Owner builder API
  user/
    stake-all.ts                  Deposit available Test1
    unstake-all.ts                Withdraw Test1 principal
    claim-all.ts                  Claim earned Test2
    exit-all.ts                   Withdraw, claim and close atomically
    close-empty-position.ts       Close a settled position
    generate-staker.ts            Generate the separate staker wallet locally
    builders/                     Unsigned user transactions
    flows/                        Position closure orchestration
    wallet.ts                     Staker signing/provider configuration
    state.ts                      Position journal and operation guards
    mod.ts                        User builder API
  shared/                         Types, scripts, datum codecs, rewards, journals
  testing/                        Cross-role integration tests and emulator fixture
```

Feature tests live beside their feature. Shared code does not import either
role. Transaction builders do not import CLI entry points; CLI functions own
wallet selection, signing, submission and progress. Pool deployment alone may
optionally run the user staking CLI after setup has completed and released its
owner lock.

## APIs

Use `owner/mod.ts` for `initializationBuilder`, `notifyRewards`, `fundRewards`,
`togglePause`, `toggleWithdrawLock` and `recoverSurplus`. Use `user/mod.ts` for
`stake`, `withdraw`/`unstake`, `getReward`/`claim`, `previewGetReward`, `exit`
and `closeEmptyPosition`. Use `shared/mod.ts` for `StakingConfig`, `AssetClass`,
`prepareSingleStaking`, datum codecs and reward formulas. Internal modules
import the specific owning module directly, keeping dependencies clear.

Builders receive a selected Lucid wallet, the original applied pool
configuration, scripts and current authenticated pool/position UTxOs. They
return an unsigned completed transaction. The caller signs and submits it.
Principal/reward amounts are integer base units; Test1 and Test2 use six
decimals.

The old root-level scripts and mixed `single-staking.ts` module have been
removed. Use the paths below. Existing runtime JSON journals deliberately keep
their original paths and formats; no pool identities, wallet credentials or
journals were moved.

## Wallets and configuration

Copy `.env.example` to `.env` or generate an owner wallet:

```sh
deno run --conditions=require --allow-env --allow-read --allow-write=.env --allow-ffi offchain/owner/generate-wallet.ts
deno run --conditions=require --allow-env --allow-read --allow-write=.env --allow-ffi offchain/owner/tokens/generate-recipient.ts
deno run --conditions=require --allow-env --allow-read --allow-write=.env --allow-ffi offchain/user/generate-staker.ts
```

The generators refuse to overwrite configured wallets. Keep `.env` private; Git
excludes it and private-key files. Owner operations use `OWNER_MNEMONIC` or
`OWNER_PRIVATE_KEY_FILE`, never both. User operations use `STAKER_MNEMONIC` and
verify `STAKER_ADDRESS`. Wallets need ADA for fees, collateral and output
minimums. No transfer funds a generated wallet automatically.

Staking uses the existing Mainnet Test1 and Test2 identities recorded in
`offchain/test-tokens-state.json`. It does not mint substitutes. Configure a
Mainnet `BLOCKFROST_API_KEY`. The current setup selects the owner as manager and
requires it to also be the rewards distributor. The contract supports distinct
roles, but each operation must be signed by its configured role.

| Journal/configuration                      | Default path                         |
| ------------------------------------------ | ------------------------------------ |
| Token identity and mint/transfer progress  | `offchain/test-tokens-state.json`    |
| Pool parameters and deployment progress    | `offchain/single-staking-state.json` |
| Staker position and pending user operation | `offchain/staker-state.json`         |
| Compiled blueprint                         | `plutus.json`                        |

Overrides remain `STATE_PATH`, `STAKING_STATE_PATH`, `STAKER_STATE_PATH` and
`BLUEPRINT_PATH`. Default journals and their receipt/lock files remain
Git-ignored. Use one staker journal per wallet/pool. Current state references
must be queried again before every spend; cached UTxOs can already be spent.

## Pool setup

```sh
aiken build
deno run --env-file=.env --conditions=require --allow-net --allow-read --allow-write --allow-env --allow-ffi offchain/owner/deploy-single-staking.ts
```

The flow is `loadDeploymentContext` → `prepareDeployment` →
`ensurePoolInitialized` → `ensureRewardsNotified` → `refreshPoolState`.
Preparation selects/restores an ADA-only bootstrap UTxO and applies the manager,
distributor, exact staking/reward assets and initial lock flag. Initialization
mints the POOL identity NFT and creates an empty pool. Notification transfers
real Test2 and starts the schedule; it does not deposit user principal.

The default budget is `STAKING_REWARD_AMOUNT=70000000`: 70 Test2 over seven days
(604800 seconds), initially unlocked. Integer division gives 115 base units per
second, or 9.936 tokens/day and 69.552 scheduled tokens. The remaining 0.448
Test2 is unallocated reserve. On an active schedule, notification combines the
new budget with remaining scheduled rewards and verifies backing and accrued
claims.

Add `--stake-after-notify` or set `START_STAKING_AFTER_NOTIFY=true` to run the
separate staker after successful initialization/notification. An unfunded staker
skips its deposit. Existing deployment progress is resumed rather than creating
another pool or notifying twice.

## User actions

Each command below uses the same permissions and `.env`:

```sh
deno run --env-file=.env --conditions=require --allow-net --allow-read --allow-write --allow-env --allow-ffi offchain/user/stake-all.ts
```

Replace the final path with the desired action:

| Script                         | Behavior                                                                                                                               |
| ------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------- |
| `user/stake-all.ts`            | Deposit the wallet's entire available Test1 balance; create a position or top up the saved one. Test2 remains in the wallet.           |
| `user/unstake-all.ts`          | Withdraw all principal, or set `UNSTAKE_AMOUNT` to positive base units for a partial withdrawal. Preserve the NFT and pending rewards. |
| `user/claim-all.ts`            | Compute and pay all earned Test2. Skip zero rewards; preserve principal and position identity.                                         |
| `user/exit-all.ts`             | Withdraw all principal, claim rewards, burn the position NFT and return its ADA.                                                       |
| `user/close-empty-position.ts` | Require zero stake and pending rewards, burn the NFT and return its ADA.                                                               |

Payouts use the position's immutable address. Claims remain available while
paused/locked and after full withdrawal. Principal withdrawal/Exit is allowed
when unlocked or strictly after `period_finish_seconds`. Empty and reward-only
closures do not need a principal unlock. Closure clears saved active-position
tracking; a later deposit creates a new identity.

The scripts share the staker journal lock. An unfinished deposit, withdrawal,
claim or closure must finish in its original script before another operation.
Confirmed operations are archived in the journal's `.last-*.json` receipts.

## Owner and distributor actions

For example, pause deposits:

```sh
POOL_PAUSED=true deno run --env-file=.env --conditions=require --allow-net --allow-read --allow-write --allow-env --allow-ffi offchain/owner/toggle-pause.ts
```

| Script                          | Required setting                                                | Authorized role and effect                                                                                                                        |
| ------------------------------- | --------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------- |
| `owner/fund-rewards.ts`         | `FUND_REWARDS_AMOUNT`                                           | Distributor: add exactly that many reward base units without changing any pool datum field.                                                       |
| `owner/toggle-pause.ts`         | `POOL_PAUSED=true` or `false`                                   | Manager: change only deposit pause state. Emissions continue; withdrawals/claims remain available.                                                |
| `owner/toggle-withdraw-lock.ts` | `WITHDRAW_LOCKED=true` or `false`                               | Manager: change only withdrawal lock state. No manual unlock is needed after expiry. A later extended schedule applies if the flag stays enabled. |
| `owner/recover-surplus.ts`      | `RECOVER_POLICY_ID`, `RECOVER_TOKEN_NAME_HEX`, `RECOVER_AMOUNT` | Manager: checkpoint and recover only native-token surplus, protecting principal, earned liabilities and remaining scheduled rewards.              |

Pause/lock commands accept a desired state and skip an already-achieved state;
retries do not blindly toggle back. Funding/recovery journals each represent one
intentional operation. Select a fresh journal path for another intentional
top-up or recovery. Overrides are `FUND_REWARDS_STATE_PATH`, `PAUSE_STATE_PATH`,
`WITHDRAW_LOCK_STATE_PATH` and `RECOVER_STATE_PATH`; defaults are suffixed
versions of the pool journal path and remain Git-ignored. Owner operations share
the pool journal lock. User and owner operations can still contend on-chain;
re-query and rebuild after a definite input-spent failure.

Surplus recovery pays the manager and excludes ADA and all pool identity tokens.
Identical staking/reward assets protect principal plus reward obligations.
Unpaid earned rewards remain protected after expiry. Unrelated native tokens
have no staking/reward reserve requirement.

## Token administration

```sh
deno run --env-file=.env --conditions=require --allow-net --allow-read --allow-write --allow-env --allow-ffi offchain/owner/tokens/deploy-test-tokens.ts
deno run --env-file=.env --conditions=require --allow-net --allow-read --allow-write --allow-env --allow-ffi offchain/owner/tokens/deploy-token-c.ts
```

These apply the owner and token name to the token minting policy, mint missing
assets, transfer tokens and verify balances. Existing assets are identified by
policy ID plus token name; only an explicit provider 404 means absent. The token
CLI supports Preview, Preprod and Mainnet, using matching API keys/addresses.
Owner-only minting allows later issuance without a supply cap; holders may burn.
Amounts are base units. `owner/tokens/config.ts` supplies example display
metadata; it does not publish registry metadata or change asset identity.

## Verification and recovery limits

```sh
deno check offchain/user/mod.ts offchain/owner/mod.ts offchain/shared/mod.ts
deno fmt --check offchain
deno lint offchain
deno test --conditions=require --allow-env --allow-read --allow-write=/private/tmp --allow-ffi offchain
```

Tests use the local emulator and never load `.env` or submit Mainnet
transactions. Commands with network/signing permissions submit real transactions
when run. A local lock excludes concurrent runs using that journal; it does not
coordinate different machines. After a crash, inspect processes and saved
transaction hashes before removing a stale lock. Hashes are saved before
submission: a transaction that was never submitted or expired needs manual
reconciliation; these scripts do not automatically rebuild it. Never delete
pending state merely to retry.

Keep the original applied parameters and compiled blueprint for an existing
pool. Recompiling changes its script hash and does not upgrade deployed UTxOs.
Pool ADA and the POOL NFT stay locked in the pool; closing a user position
returns that position's ADA only.

## Independently fund the owner with existing Test2

Check Mainnet balances without submitting anything:

```sh
deno run --env-file=.env --conditions=require --allow-net --allow-read --allow-env --allow-ffi offchain/owner/tokens/transfer-rewards-to-owner.ts --check
```

The default sender is the saved recipient wallet (`RECIPIENT_MNEMONIC`). To send
from a different wallet holding Test2, configure `REWARD_SENDER_MNEMONIC` and
optionally `REWARD_SENDER_ADDRESS` privately in `.env`. The destination is
derived from the OWNER wallet and checked against `OWNER_ADDRESS` if configured.
The script reads the existing Test2 policy/name from the token manifest and
never mints or initializes/notifies a pool. Both wallets need appropriate ADA
for the subsequent transactions; the sender must already hold the full transfer
amount.

To submit the transfer, run the same command without `--check` and add
`--allow-write`. `REWARD_TRANSFER_AMOUNT` defaults to `1000000000` base units:
1,000 Test2 at six decimals. The default journal is
`offchain/single-staking-state.json.reward-transfer.json`; reuse it after an
interruption to prevent a duplicate transfer. Set `REWARD_TRANSFER_STATE_PATH`
to a fresh ignored journal for another intentional transfer. Saved-hash recovery
has the same manual-reconciliation limitations as the other transaction scripts.

### Initialization as an independent phase

To create only the pool identity/empty state without notifying rewards or
staking:

```sh
POOL_NAME='Staking pool' deno run --env-file=.env --conditions=require --allow-net --allow-read --allow-write --allow-env --allow-ffi offchain/owner/initialize-pool.ts
```

The display name is stored locally as `poolName`; the on-chain identity remains
its policy ID plus the POOL NFT. Preserve the same pool journal for subsequent
phases. Initialization records the current and original pool UTxO. Rewards do
not start until NotifyRewards is submitted separately.

After successful initialization, run notification independently using the same
journal and configuration:

```sh
deno run --env-file=.env --conditions=require --allow-net --allow-read --allow-write --allow-env --allow-ffi offchain/owner/notify-rewards.ts
```

This entry point refuses to create a pool. It funds and starts the configured
reward schedule; staking remains a separate user command.

## Multiple pools

The public inventory is `offchain/config/pools.json`. Each entry defines its staking
and reward asset IDs, reward budget, duration, frozen blueprint, deployment folder,
and separate pool/staker journals. Select a pool explicitly with `POOL_ID`:

```bash
deno run --conditions=require --allow-env --allow-read offchain/owner/list-pools.ts
POOL_ID=tokenc-test2 deno run --env-file=.env --conditions=require -A offchain/owner/initialize-pool.ts
POOL_ID=tokenc-test2 deno run --env-file=.env --conditions=require -A offchain/owner/notify-rewards.ts
POOL_ID=tokenc-test2 deno run --env-file=.env --conditions=require -A offchain/user/stake-all.ts
```

Use `POOL_ID=test1-test2` for the original pool. Without `POOL_ID`, existing scripts
retain the original pool's environment/default paths. With `POOL_ID`, registry
settings select the assets, journal paths, blueprint and initial reward schedule;
these take precedence over the corresponding global environment settings.
Owner and staker wallet credentials still come from `.env`. Wallets can be shared
across pools while their position journals remain separate.

For the initial tokenC issuance and an optional ADA-only bootstrap preparation:

```bash
POOL_ID=tokenc-test2 deno run --env-file=.env --conditions=require -A offchain/owner/tokens/mint-token-c.ts
POOL_ID=tokenc-test2 deno run --env-file=.env --conditions=require -A offchain/owner/tokens/prepare-pool-bootstrap.ts
```

Issuance sends 1,000 tokenC to the existing owner and journals the transaction before
submission. It does not mint Test1 or Test2. Initialization creates only the pool
identity and empty state. Notification separately transfers the reward budget and
starts the schedule. The registry defaults to 70 Test2 over seven days; integer
per-second rounding produces 9.936 Test2/day. Runtime journals under `offchain/state/`
are ignored by Git; public deployment records live in `deployments/mainnet/`.

### New validator: immutable vault support setting

New pool configurations include `vaultSupported` (`VAULT_SUPPORTED=true|false`
when not specified by the selected registry entry; default false). It is the
seventh script parameter and is recorded in the deployment configuration and
resume identity. Enabling it requires an initially unlocked pool and permanently
rejects manager withdrawal-lock toggles. Wallet-only pools retain existing lock
behavior. The current factory-v1 profile supports registered vault positions as described below; the earlier seven-parameter development profile remains separate.

Original six-parameter deployment records and their archived blueprints remain
supported with `vaultSupported` absent. New seven-parameter blueprints require
an explicit boolean. Mixing a legacy blueprint with a new configuration, or a
new blueprint with legacy parameters, is rejected to avoid changing an existing
pool's identity. Existing public Mainnet artifacts are unchanged.

### Position schema version 2

New validator positions use `PositionOwner`: `WalletOwner(paymentKeyHash)` or
`VaultOwner(controllerScriptHash, statePolicyId, stateAssetName)`. Wallet and
controller hashes are explicitly tagged; their equal byte lengths do not identify
the owner type. A vault's existing State NFT is referenced, not minted here.

Version 2 `PositionDatum` records contain, in order: schema version `2`, pool ID,
position name, tagged owner, payout address, principal, reward checkpoint, and
pending rewards. The outer Position constructor remains 1 and the record
constructor remains 0. Owner constructor 0 contains one wallet key hash; owner
constructor 1 contains the controller hash, State policy ID and State asset name.
Version 2 `OpenPosition` is constructor 1 with fields `[2, creationRef, owner]`.
Unsupported versions and malformed owner encodings are rejected.

The codecs accept an explicit schema version, defaulting to 2. Version 1 preserves
the original seven-field record and `[creationRef, walletKeyHash]` mint redeemer,
normalizing its owner to `WalletOwner` in TypeScript. Prepared scripts expose
`positionSchemaVersion`; wallet builders use it for both reads and writes. They
do not guess a datum version from its contents. Original six-parameter Mainnet
artifacts remain unchanged.

The current runtime supports authenticated factory-admitted creation, top-up and combined exits. Vault standalone claim/withdraw and closure remain rejected. A wallet signature never authorizes a `VaultOwner` position.

### Factory profile and reference-script construction

The current target is eight parameters: `factory_policy: Option<PolicyId>` follows
`vault_supported`. New wallet-only configurations set `factoryPolicy: null`;
vault-supported configurations require an explicit 28-byte policy and unlocked
initial state. `FACTORY_POLICY_ID` supplies this public value in new setup flows.
No production factory ID is provided by the repository. Existing six-/seven-
parameter records omit the field and must use their exact corresponding script.
Blueprint title and ordered parameter names are validated, not just their count.

The composable builders accept `scripts.referenceUtxo` carrying the exact applied
shared mint/spend program. Its script hash is validated before construction; the
caller must resolve an actual fresh reference UTxO. Without a reference the
builder attaches the script inline, which can exceed transaction size limits for
new programs. This API does not publish a reference, sign or submit a transaction.
The emulator tests publish a real synthetic reference without raising size limits.

The vault admission verifier and operation-evidence helpers are separate. A
certificate alone never authorizes a State operation. Factory-admitted creation and matched stake/combined-exit handlers are implemented; complete external-controller lifecycle acceptance remains pending.
See [implementation status](../FRAC-MIXED-OWNER-STATUS.md).

### Composing a vault operation

Import `composeVaultOperation` from `offchain/user/mod.ts`. Supply the eight-
parameter config/scripts, exact v1 authorization CBOR, explicit pool/position (or
creation seed), State input, Config reference and matching controller witness.
First creation additionally requires the authentic factory certificate reference
and explicit position storage ADA. The returned `tx` is unfinished and unsigned:
append the State continuation at `requiredStateOutputIndex`, share mint/burn,
receiver and fee outputs, and funding before completing/evaluating. Existing
transactions can be supplied for composition; output ordering must still match
the authorization. No wallet-only stake-all/claim-all flow is used.

Build handoff and precise limitations: [integration build](../integration/mixed-owner-v1/README.md).
