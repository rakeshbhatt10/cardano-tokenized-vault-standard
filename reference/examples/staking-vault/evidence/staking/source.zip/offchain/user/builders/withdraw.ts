import { stakingTransaction } from "../../shared/staking-transaction.ts";
import {
  Constr,
  Data,
  fromText,
  getAddressDetails,
  type LucidEvolution,
  toUnit,
  type UTxO,
} from "npm:@lucid-evolution/lucid@0.4.29";
import { checkpointPool, checkpointPosition } from "../../shared/rewards.ts";
import {
  decodePoolDatum,
  decodePositionDatum,
  encodePoolDatum,
  encodePositionDatum,
  positionPayoutAddress,
  walletOwnerKey,
} from "../../shared/datum.ts";
import { type StakingConfig } from "../../shared/types.ts";
import { type StakingScripts } from "../../shared/scripts.ts";

/** Build an unstake: principal payout, preserving position identity and pending rewards. */
export async function withdraw(
  lucid: LucidEvolution,
  config: StakingConfig,
  scripts: StakingScripts,
  poolUtxo: UTxO,
  positionUtxo: UTxO,
  amount: bigint,
  lowerBoundMs: number,
) {
  if (amount <= 0n) {
    throw new Error("Unstake amount must be positive base units.");
  }
  if (
    !Number.isSafeInteger(lowerBoundMs) || lowerBoundMs < 0 ||
    lowerBoundMs % 1000 !== 0
  ) throw new Error("Use whole-second validity lower bound milliseconds.");
  const poolUnit = toUnit(scripts.poolPolicyId, fromText("POOL"));
  if (
    poolUtxo.address !== scripts.poolAddress ||
    poolUtxo.assets[poolUnit] !== 1n || !poolUtxo.datum
  ) throw new Error("Expected authenticated pool state.");
  if (positionUtxo.address !== scripts.poolAddress || !positionUtxo.datum) {
    throw new Error("Expected inline position state.");
  }
  const before = decodePoolDatum(poolUtxo.datum);
  const old = decodePositionDatum(
    positionUtxo.datum,
    scripts.positionSchemaVersion,
  );
  const positionUnit = toUnit(scripts.poolPolicyId, old.positionName);
  const owner =
    getAddressDetails(await lucid.wallet().address()).paymentCredential;
  if (
    owner?.type !== "Key" || owner.hash !== walletOwnerKey(old.owner) ||
    old.poolId !== scripts.poolPolicyId ||
    positionUtxo.assets[positionUnit] !== 1n
  ) throw new Error("Position is not owned by the selected wallet/pool.");
  if (amount > old.stakedAmount || amount > before.totalStaked) {
    throw new Error("Unstake exceeds the staked balance.");
  }
  const time = BigInt(lowerBoundMs / 1000);
  if (before.isLocked && time <= before.periodFinishSeconds) {
    throw new Error(
      `Withdrawal locked until after ${before.periodFinishSeconds} Unix seconds.`,
    );
  }
  if (old.rewardPerTokenPaid > before.rewardPerTokenStored) {
    throw new Error("Invalid position checkpoint.");
  }
  const checkpoint = checkpointPool({
    totalStaked: before.totalStaked,
    periodFinishSeconds: before.periodFinishSeconds,
    rewardRate: before.rewardRate,
    lastUpdateSeconds: before.lastUpdateSeconds,
    rewardPerTokenStored: before.rewardPerTokenStored,
    accruedLiabilityBound: before.accruedLiabilityBound,
  }, time);
  const pool = {
    ...before,
    ...checkpoint,
    totalStaked: before.totalStaked - amount,
  };
  const position = {
    ...old,
    ...checkpointPosition({
      stakedAmount: old.stakedAmount,
      pendingRewards: old.pendingRewards,
      rewardPerTokenPaid: old.rewardPerTokenPaid,
    }, pool.rewardPerTokenStored),
    stakedAmount: old.stakedAmount - amount,
  };
  const stakeUnit = toUnit(
    config.stakingAsset.policyId,
    config.stakingAsset.tokenNameHex,
  );
  const rewardUnit = toUnit(
    config.rewardAsset.policyId,
    config.rewardAsset.tokenNameHex,
  );
  const poolAssets = {
    ...poolUtxo.assets,
    [stakeUnit]: (poolUtxo.assets[stakeUnit] ?? 0n) - amount,
  };
  if (poolAssets[stakeUnit] < pool.totalStaked) {
    throw new Error("Pool principal is underfunded.");
  }
  const remaining = before.periodFinishSeconds > time
    ? before.periodFinishSeconds - time
    : 0n;
  if (
    (poolAssets[rewardUnit] ?? 0n) <
      pool.accruedLiabilityBound + remaining * before.rewardRate +
        (stakeUnit === rewardUnit ? pool.totalStaked : 0n)
  ) throw new Error("Withdrawal would consume reward reserves.");
  const network = getAddressDetails(scripts.poolAddress).networkId === 1
    ? "Mainnet"
    : "Preview";
  // Ledger output token quantities must be positive; omit an emptied asset.
  if (poolAssets[stakeUnit] === 0n) delete poolAssets[stakeUnit];
  const payoutAddress = positionPayoutAddress(old, network);
  const poolDatum = encodePoolDatum(pool);
  const positionDatum = encodePositionDatum(
    position,
    scripts.positionSchemaVersion,
  );
  const action = Data.to(new Constr(1, [amount, old.positionName]));
  const completed = await stakingTransaction(lucid, scripts)
    .collectFrom([poolUtxo, positionUtxo], action)
    .addSignerKey(walletOwnerKey(old.owner))
    .validFrom(lowerBoundMs).validTo(lowerBoundMs + 50_000)
    .pay.ToContract(
      scripts.poolAddress,
      { kind: "inline", value: poolDatum },
      poolAssets,
    )
    .pay.ToContract(scripts.poolAddress, {
      kind: "inline",
      value: positionDatum,
    }, positionUtxo.assets)
    .pay.ToAddress(payoutAddress, { [stakeUnit]: amount })
    // Reserve a 2-ADA floor; Lucid raises it if the protocol requires more.
    .complete({ setCollateral: 2_000_000n });
  return {
    completed,
    pool,
    position,
    poolDatum,
    positionDatum,
    positionUnit,
    payoutAddress,
  };
}
export { withdraw as unstake };
