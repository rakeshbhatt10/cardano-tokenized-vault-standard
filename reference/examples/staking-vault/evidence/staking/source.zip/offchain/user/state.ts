import { writeJsonAtomic } from "../shared/journal.ts";
/** Local progress only; current balances and state are always fetched from the chain. */
export type StakerState = {
  owner: string;
  poolPolicyId: string;
  positionUnit?: string;
  txHash?: string;
  amount?: string;
  expectedStakedAmount?: string;
  positionRef?: { txHash: string; outputIndex: number };
  poolRef?: { txHash: string; outputIndex: number };
  pendingClosure?: {
    action: "exit" | "close-empty";
    txHash: string;
    positionUnit: string;
    principalAmount: string;
    rewardAmount: string;
  };
  pendingClaim?: {
    txHash: string;
    rewardAmount: string;
    expectedPositionDatum: string;
  };
  pendingWithdrawal?: {
    txHash: string;
    amount: string;
    expectedStakedAmount: string;
  };
};

/** Load prior progress without allowing a different wallet to reuse it. */
export async function readStakerState(path: string, owner: string) {
  let state: StakerState;
  try {
    state = JSON.parse(await Deno.readTextFile(path));
  } catch (error) {
    if (error instanceof Deno.errors.NotFound) return undefined;
    throw error;
  }
  if (state.owner !== owner) {
    throw new Error("Staker journal belongs to another wallet.");
  }
  return state;
}

/** Replace the journal atomically so interruption cannot leave partial JSON. */
export async function saveStakerState(path: string, state: StakerState) {
  await writeJsonAtomic(path, state);
}

/** Finish a closing transaction before touching the soon-to-be-burned position. */
export function requireNoPendingClosure(state: StakerState | undefined) {
  if (state?.pendingClosure) {
    const script = state.pendingClosure.action === "exit"
      ? "exit-all.ts"
      : "close-empty-position.ts";
    throw new Error(
      `Resume ${script} before starting another position operation.`,
    );
  }
}
