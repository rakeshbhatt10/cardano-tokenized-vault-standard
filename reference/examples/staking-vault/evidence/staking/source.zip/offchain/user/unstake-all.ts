/** Withdraw Test1 principal using the saved staker position; rewards remain claimable. */
import {
  fromText,
  type LucidEvolution,
  toUnit,
  type UTxO,
} from "npm:@lucid-evolution/lucid@0.4.29";
import { loadPoolDeployment } from "../shared/pool-deployment.ts";
import { decodePositionDatum, walletOwnerKey } from "../shared/datum.ts";
import { confirmTransaction, findStateUtxo } from "../shared/transactions.ts";
import { loadStakerContext, type StakerContext } from "./wallet.ts";
import {
  readStakerState,
  requireNoPendingClosure,
  saveStakerState,
} from "./state.ts";
import { withStateLock } from "../shared/journal.ts";
import { type StakingScripts } from "../shared/scripts.ts";
import { type StakingConfig } from "../shared/types.ts";
import { withdraw } from "./builders/withdraw.ts";

/** Omit UNSTAKE_AMOUNT to withdraw all; otherwise use positive integer base units. */
export function parseUnstakeAmount(
  value: string | undefined,
): bigint | undefined {
  if (value === undefined) return undefined;
  if (!/^[1-9][0-9]*$/.test(value)) {
    throw new Error(
      "UNSTAKE_AMOUNT must be a positive integer in staking-token base units.",
    );
  }
  return BigInt(value);
}

/** Build without signing/submitting. Full withdrawal leaves the position NFT and rewards. */
export async function buildUnstakeAll(
  lucid: LucidEvolution,
  config: StakingConfig,
  scripts: StakingScripts,
  poolUtxo: UTxO,
  positionUtxo: UTxO,
  lowerBoundMs: number,
  requestedAmount?: bigint,
) {
  if (!positionUtxo.datum) throw new Error("Expected inline position state.");
  const position = decodePositionDatum(
    positionUtxo.datum,
    scripts.positionSchemaVersion,
  );
  const amount = requestedAmount ?? position.stakedAmount;
  if (amount === 0n && requestedAmount === undefined) return undefined;
  // withdraw validates ownership, identity, available principal, lock expiry and reserves.
  const built = await withdraw(
    lucid,
    config,
    scripts,
    poolUtxo,
    positionUtxo,
    amount,
    lowerBoundMs,
  );
  return { ...built, amount };
}

/** Restore the original pool and position; refuse to overlap an unfinished deposit. */
export async function prepareWithdrawal(
  context: StakerContext,
  requestedAmount?: bigint,
) {
  const state = await readStakerState(context.path, context.owner);
  requireNoPendingClosure(state);
  if (!state?.positionUnit) {
    throw new Error("No saved staking position. Stake first.");
  }
  if (state.pendingClaim) {
    throw new Error("Resume claim-all.ts before starting a withdrawal.");
  }
  if (state.txHash) {
    throw new Error("Resume stake-all.ts before starting a withdrawal.");
  }
  const { config, scripts } = await loadPoolDeployment(
    context.deploymentPath,
    context.network,
    context.blueprintPath,
  );
  if (state.poolPolicyId !== scripts.poolPolicyId) {
    throw new Error("Staker journal belongs to another pool.");
  }
  // A pending withdrawal always takes precedence over a new amount on a retry.
  if (state.pendingWithdrawal) {
    await confirmTransaction(
      context.lucid,
      state.pendingWithdrawal.txHash,
    );
  }
  return {
    context,
    state,
    config,
    scripts,
    requestedAmount,
    positionUnit: state.positionUnit,
    poolUnit: toUnit(scripts.poolPolicyId, fromText("POOL")),
  };
}
export type WithdrawalSession = Awaited<ReturnType<typeof prepareWithdrawal>>;

function findState(session: WithdrawalSession, unit: string) {
  return findStateUtxo(
    session.context.lucid,
    session.scripts.poolAddress,
    unit,
  );
}

/** Save the hash before submission; a retry must reconcile it instead of withdrawing twice. */
export async function ensureWithdrawalSubmitted(session: WithdrawalSession) {
  const { context: { lucid, path }, state, config, scripts } = session;
  if (state.pendingWithdrawal) return;
  const [poolUtxo, positionUtxo] = await Promise.all([
    findState(session, session.poolUnit),
    findState(session, session.positionUnit),
  ]);
  const apiKey = Deno.env.get("BLOCKFROST_API_KEY");
  if (!apiKey) throw new Error("Set BLOCKFROST_API_KEY.");
  const response = await fetch(
    "https://cardano-mainnet.blockfrost.io/api/v0/blocks/latest",
    {
      headers: { project_id: apiKey },
      signal: AbortSignal.timeout(30_000),
    },
  );
  if (!response.ok) {
    throw new Error(`Network time lookup HTTP ${response.status}.`);
  }
  const tip = await response.json();
  if (!Number.isSafeInteger(tip.time) || tip.time < 0) {
    throw new Error("Invalid network block time.");
  }
  const built = await buildUnstakeAll(
    lucid,
    config,
    scripts,
    poolUtxo,
    positionUtxo,
    tip.time * 1000,
    session.requestedAmount,
  );
  if (!built) {
    console.log("Nothing to withdraw. Pending rewards can still be claimed.");
    return;
  }
  const signed = await built.completed.sign.withWallet().complete();
  state.pendingWithdrawal = {
    txHash: signed.toHash(),
    amount: built.amount.toString(),
    expectedStakedAmount: built.position.stakedAmount.toString(),
  };
  await saveStakerState(path, state);
  await signed.submit();
  console.log("Withdrawal transaction:", state.pendingWithdrawal.txHash);
  console.log("Principal payout address:", built.payoutAddress);
  await confirmTransaction(lucid, state.pendingWithdrawal.txHash);
}

/** Verify the continued position, archive progress, then save current pool/position refs. */
export async function refreshWithdrawalState(session: WithdrawalSession) {
  const { context: { owner, path }, state, scripts } = session;
  const pending = state.pendingWithdrawal;
  if (!pending) return;
  let positionUtxo = await findState(session, session.positionUnit);
  if (!positionUtxo.datum) throw new Error("Expected inline position state.");
  let position = decodePositionDatum(
    positionUtxo.datum,
    scripts.positionSchemaVersion,
  );
  for (
    let attempt = 0;
    position.stakedAmount.toString() !== pending.expectedStakedAmount &&
    attempt < 11;
    attempt++
  ) {
    await new Promise((resolve) => setTimeout(resolve, 5000));
    positionUtxo = await findState(session, session.positionUnit);
    if (!positionUtxo.datum) throw new Error("Expected inline position state.");
    position = decodePositionDatum(
      positionUtxo.datum,
      scripts.positionSchemaVersion,
    );
  }
  const poolUtxo = await findState(session, session.poolUnit);
  if (
    walletOwnerKey(position.owner) !== owner ||
    position.poolId !== scripts.poolPolicyId ||
    position.stakedAmount.toString() !== pending.expectedStakedAmount
  ) {
    throw new Error(
      "Withdrawal position is not indexed or does not match; resume with the same journal.",
    );
  }
  state.positionRef = {
    txHash: positionUtxo.txHash,
    outputIndex: positionUtxo.outputIndex,
  };
  state.poolRef = {
    txHash: poolUtxo.txHash,
    outputIndex: poolUtxo.outputIndex,
  };
  await Deno.writeTextFile(
    `${path}.last-withdrawal.json`,
    JSON.stringify(state, null, 2),
  );
  delete state.pendingWithdrawal;
  await saveStakerState(path, state);
  console.log("Confirmed withdrawal:", pending.txHash);
  console.log("Withdrawn staking-token base units:", pending.amount);
  console.log("Remaining staked base units:", position.stakedAmount.toString());
  console.log("Pending reward base units:", position.pendingRewards.toString());
}

/** Shares the stake-all lock so local deposits and withdrawals cannot run concurrently. */
export async function main() {
  const requestedAmount = parseUnstakeAmount(Deno.env.get("UNSTAKE_AMOUNT"));
  const context = await loadStakerContext();
  await withStateLock(context.path, async () => {
    const session = await prepareWithdrawal(context, requestedAmount);
    await ensureWithdrawalSubmitted(session);
    await refreshWithdrawalState(session);
  });
}

if (import.meta.main) await main();
