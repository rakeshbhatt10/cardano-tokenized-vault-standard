/** Shared orchestration for Exit and CloseEmptyPosition, using the staker journal/lock. */
import { fromText, toUnit } from "npm:@lucid-evolution/lucid@0.4.29";
import { loadPoolDeployment } from "../../shared/pool-deployment.ts";
import {
  confirmTransaction,
  findStateUtxo,
} from "../../shared/transactions.ts";
import { readStakerState, saveStakerState } from "../state.ts";
import { type StakerContext } from "../wallet.ts";
import {
  buildPositionClosure,
  type ClosureAction,
} from "../builders/position-closure.ts";

/** Restore the pool and refuse to overlap a deposit, withdrawal or claim. */
export async function preparePositionClosure(
  context: StakerContext,
  action: ClosureAction,
) {
  const state = await readStakerState(context.path, context.owner);
  if (state?.txHash) {
    throw new Error("Resume stake-all.ts before closing the position.");
  }
  if (state?.pendingWithdrawal) {
    throw new Error("Resume unstake-all.ts before closing the position.");
  }
  if (state?.pendingClaim) {
    throw new Error("Resume claim-all.ts before closing the position.");
  }
  if (state?.pendingClosure && state.pendingClosure.action !== action) {
    throw new Error(
      "Resume the original position closure script before starting another action.",
    );
  }
  if (!state?.positionUnit) {
    if (state?.pendingClosure) {
      throw new Error("Pending closure is missing its position identity.");
    }
    console.log("No active saved position to close.");
    return undefined;
  }
  const { config, scripts } = await loadPoolDeployment(
    context.deploymentPath,
    context.network,
    context.blueprintPath,
  );
  if (state.poolPolicyId !== scripts.poolPolicyId) {
    throw new Error("Staker journal belongs to another pool.");
  }
  if (state.pendingClosure) {
    if (state.pendingClosure.positionUnit !== state.positionUnit) {
      throw new Error("Pending closure position mismatch.");
    }
    await confirmTransaction(context.lucid, state.pendingClosure.txHash);
  }
  return {
    context,
    state,
    config,
    scripts,
    action,
    positionUnit: state.positionUnit,
    poolUnit: toUnit(scripts.poolPolicyId, fromText("POOL")),
  };
}
export type PositionClosureSession = NonNullable<
  Awaited<ReturnType<typeof preparePositionClosure>>
>;

/** Build/sign and persist progress before submission; recovery never builds a second exit. */
export async function ensurePositionClosureSubmitted(
  session: PositionClosureSession,
) {
  const { context: { lucid, path }, state, config, scripts, action } = session;
  if (state.pendingClosure) return;
  const [poolUtxo, positionUtxo] = await Promise.all([
    findStateUtxo(lucid, scripts.poolAddress, session.poolUnit),
    findStateUtxo(lucid, scripts.poolAddress, session.positionUnit),
  ]);
  const built = await buildPositionClosure(
    lucid,
    config,
    scripts,
    poolUtxo,
    positionUtxo,
    Math.floor(Date.now() / 1000) * 1000 - 5000,
    action,
  );
  const signed = await built.completed.sign.withWallet().complete();
  state.pendingClosure = {
    action,
    txHash: signed.toHash(),
    positionUnit: built.positionUnit,
    principalAmount: built.principalAmount.toString(),
    rewardAmount: built.rewardAmount.toString(),
  };
  await saveStakerState(path, state);
  await signed.submit();
  console.log("Position closure transaction:", state.pendingClosure.txHash);
  console.log("Payout address:", built.payoutAddress);
  await confirmTransaction(lucid, state.pendingClosure.txHash);
}

/** Wait for the burned identity to disappear, then clear active-position tracking. */
export async function refreshPositionClosureState(
  session: PositionClosureSession,
) {
  const { context: { lucid, path }, state, scripts } = session;
  const pending = state.pendingClosure;
  if (!pending) return;
  // awaitTx may resolve before the provider updates its UTxO index.
  for (let attempt = 0; attempt < 12; attempt++) {
    const positions = await lucid.utxosAtWithUnit(
      scripts.poolAddress,
      pending.positionUnit,
    );
    if (positions.length === 0) {
      const pool = await findStateUtxo(
        lucid,
        scripts.poolAddress,
        session.poolUnit,
      );
      state.poolRef = { txHash: pool.txHash, outputIndex: pool.outputIndex };
      await Deno.writeTextFile(
        `${path}.last-${pending.action}.json`,
        JSON.stringify(state, null, 2),
      );
      delete state.positionUnit;
      delete state.positionRef;
      delete state.expectedStakedAmount;
      delete state.amount;
      delete state.pendingClosure;
      await saveStakerState(path, state);
      console.log("Confirmed position closure:", pending.txHash);
      console.log("Returned Test1 base units:", pending.principalAmount);
      console.log("Claimed Test2 base units:", pending.rewardAmount);
      return;
    }
    await new Promise((resolve) => setTimeout(resolve, 5000));
  }
  throw new Error(
    "Position closure is not indexed yet; resume the same script/journal.",
  );
}
