import { stakingTransaction } from "../../shared/staking-transaction.ts";
/** Unsigned builders for closing a position and burning its identity NFT. */
import {
  Constr,
  Data,
  fromText,
  getAddressDetails,
  type LucidEvolution,
  toUnit,
  type UTxO,
} from "npm:@lucid-evolution/lucid@0.4.29";
import {
  decodePoolDatum,
  decodePositionDatum,
  encodePoolDatum,
  positionPayoutAddress,
  walletOwnerKey,
} from "../../shared/datum.ts";
import { previewClaim } from "../../shared/rewards.ts";
import type { StakingScripts } from "../../shared/scripts.ts";
import type { StakingConfig } from "../../shared/types.ts";

export type ClosureAction = "exit" | "close-empty";

/** Exit pays all principal/rewards; empty closure pays only the position's ADA. */
export async function buildPositionClosure(
  lucid: LucidEvolution,
  config: StakingConfig,
  scripts: StakingScripts,
  poolUtxo: UTxO,
  positionUtxo: UTxO,
  lowerBoundMs: number,
  action: ClosureAction,
) {
  if (
    !Number.isSafeInteger(lowerBoundMs) || lowerBoundMs < 0 ||
    lowerBoundMs % 1000 !== 0
  ) {
    throw new Error("Use whole-second validity lower bound milliseconds.");
  }
  const poolUnit = toUnit(scripts.poolPolicyId, fromText("POOL"));
  if (
    poolUtxo.address !== scripts.poolAddress ||
    poolUtxo.assets[poolUnit] !== 1n || !poolUtxo.datum
  ) {
    throw new Error("Expected authenticated pool state.");
  }
  if (positionUtxo.address !== scripts.poolAddress || !positionUtxo.datum) {
    throw new Error("Expected inline position state.");
  }
  const before = decodePoolDatum(poolUtxo.datum);
  const position = decodePositionDatum(
    positionUtxo.datum,
    scripts.positionSchemaVersion,
  );
  const positionUnit = toUnit(scripts.poolPolicyId, position.positionName);
  const owner =
    getAddressDetails(await lucid.wallet().address()).paymentCredential;
  if (
    owner?.type !== "Key" || owner.hash !== walletOwnerKey(position.owner) ||
    position.poolId !== scripts.poolPolicyId ||
    positionUtxo.assets[positionUnit] !== 1n
  ) {
    throw new Error("Position is not owned by the selected wallet/pool.");
  }
  if (
    Object.keys(positionUtxo.assets).some((unit) =>
      unit !== "lovelace" && unit !== positionUnit
    )
  ) {
    throw new Error("Position must contain only its identity NFT and ADA.");
  }
  if (
    position.stakedAmount > before.totalStaked ||
    position.rewardPerTokenPaid > before.rewardPerTokenStored
  ) {
    throw new Error("Invalid position accounting.");
  }
  if (
    action === "close-empty" &&
    (position.stakedAmount !== 0n || position.pendingRewards !== 0n)
  ) {
    throw new Error(
      "Withdraw and claim first; position must have zero stake and pending rewards.",
    );
  }
  const time = BigInt(lowerBoundMs / 1000);
  if (
    action === "exit" && position.stakedAmount > 0n && before.isLocked &&
    time <= before.periodFinishSeconds
  ) {
    throw new Error(
      `Withdrawal locked until after ${before.periodFinishSeconds} Unix seconds.`,
    );
  }
  const preview = previewClaim(before, position, time);
  const rewardAmount = preview.rewardAmount;
  if (rewardAmount > preview.pool.accruedLiabilityBound) {
    throw new Error("Claim exceeds accrued reward liability.");
  }
  const principalAmount = position.stakedAmount;
  const pool = {
    ...before,
    ...preview.pool,
    totalStaked: before.totalStaked - principalAmount,
    accruedLiabilityBound: preview.pool.accruedLiabilityBound - rewardAmount,
  };
  const stakeUnit = toUnit(
    config.stakingAsset.policyId,
    config.stakingAsset.tokenNameHex,
  );
  const rewardUnit = toUnit(
    config.rewardAsset.policyId,
    config.rewardAsset.tokenNameHex,
  );
  const deductions: Record<string, bigint> = {};
  deductions[stakeUnit] = principalAmount;
  deductions[rewardUnit] = (deductions[rewardUnit] ?? 0n) + rewardAmount;
  const poolAssets = { ...poolUtxo.assets };
  const payoutAssets: Record<string, bigint> = {
    lovelace: positionUtxo.assets.lovelace ?? 0n,
  };
  for (const [unit, amount] of Object.entries(deductions)) {
    poolAssets[unit] = (poolAssets[unit] ?? 0n) - amount;
    if (poolAssets[unit] < 0n) {
      throw new Error("Pool is underfunded for closure.");
    }
    if (poolAssets[unit] === 0n) delete poolAssets[unit];
    if (amount > 0n) payoutAssets[unit] = amount;
  }
  const remaining = before.periodFinishSeconds > time
    ? before.periodFinishSeconds - time
    : 0n;
  if (
    (poolAssets[stakeUnit] ?? 0n) < pool.totalStaked ||
    (poolAssets[rewardUnit] ?? 0n) <
      pool.accruedLiabilityBound + remaining * pool.rewardRate +
        (stakeUnit === rewardUnit ? pool.totalStaked : 0n)
  ) {
    throw new Error("Closure would consume principal or reward reserves.");
  }
  const network = getAddressDetails(scripts.poolAddress).networkId === 1
    ? "Mainnet"
    : "Preview";
  const payoutAddress = positionPayoutAddress(position, network);
  const poolDatum = encodePoolDatum(pool);
  const spendRedeemer = Data.to(
    new Constr(action === "exit" ? 3 : 4, [position.positionName]),
  );
  const burnRedeemer = Data.to(new Constr(2, [position.positionName]));
  const completed = await stakingTransaction(lucid, scripts)
    .collectFrom([poolUtxo, positionUtxo], spendRedeemer)
    .mintAssets({ [positionUnit]: -1n }, burnRedeemer)
    .addSignerKey(walletOwnerKey(position.owner))
    .validFrom(lowerBoundMs).validTo(lowerBoundMs + 50_000)
    .pay.ToContract(
      scripts.poolAddress,
      { kind: "inline", value: poolDatum },
      poolAssets,
    )
    .pay.ToAddress(payoutAddress, payoutAssets)
    .complete();
  return {
    completed,
    pool,
    poolDatum,
    principalAmount,
    rewardAmount,
    positionUnit,
    payoutAddress,
  };
}

export function exit(
  lucid: LucidEvolution,
  config: StakingConfig,
  scripts: StakingScripts,
  poolUtxo: UTxO,
  positionUtxo: UTxO,
  lowerBoundMs: number,
) {
  return buildPositionClosure(
    lucid,
    config,
    scripts,
    poolUtxo,
    positionUtxo,
    lowerBoundMs,
    "exit",
  );
}

export function closeEmptyPosition(
  lucid: LucidEvolution,
  config: StakingConfig,
  scripts: StakingScripts,
  poolUtxo: UTxO,
  positionUtxo: UTxO,
  lowerBoundMs: number,
) {
  return buildPositionClosure(
    lucid,
    config,
    scripts,
    poolUtxo,
    positionUtxo,
    lowerBoundMs,
    "close-empty",
  );
}
