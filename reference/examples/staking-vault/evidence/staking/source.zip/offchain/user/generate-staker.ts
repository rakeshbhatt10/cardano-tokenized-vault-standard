import {
  Emulator,
  generateSeedPhrase,
  Lucid,
} from "npm:@lucid-evolution/lucid@0.4.29";

const path = Deno.args[0] ?? ".env";
const original = await Deno.readTextFile(path);
const read = (key: string) => {
  const lines = original.split(/\r?\n/).filter((line) =>
    new RegExp(`^${key}=`).test(line)
  );
  if (lines.length > 1) throw new Error(`Duplicate ${key}.`);
  return lines[0]?.slice(lines[0].indexOf("=") + 1).trim().replace(
    /^"|"$/g,
    "",
  ) ?? "";
};
if (read("STAKER_MNEMONIC") || read("STAKER_ADDRESS")) {
  throw new Error(
    "Staker already configured; refusing to overwrite its wallet.",
  );
}
const network = read("NETWORK") || "Preview";
if (network !== "Mainnet" && network !== "Preview" && network !== "Preprod") {
  throw new Error("Invalid NETWORK.");
}
const mnemonic = generateSeedPhrase();
const lucid = await Lucid(new Emulator([]), network);
lucid.selectWallet.fromSeed(mnemonic);
const address = await lucid.wallet().address();
let updated = original;
for (
  const [key, value] of [
    ["STAKER_MNEMONIC", `"${mnemonic}"`],
    ["STAKER_ADDRESS", address],
    [
      "STAKER_STATE_PATH",
      read("STAKER_STATE_PATH") || "offchain/staker-state.json",
    ],
  ]
) {
  const pattern = new RegExp(`^${key}=.*$`, "m");
  updated = pattern.test(updated)
    ? updated.replace(pattern, `${key}=${value}`)
    : `${updated.trimEnd()}\n${key}=${value}\n`;
}
if (await Deno.readTextFile(path) !== original) {
  throw new Error("Environment file changed during generation.");
}
await Deno.chmod(path, 0o600);
await Deno.writeTextFile(path, updated);
console.log(`Staker wallet saved privately to ${path}; network ${network}`);
console.log("Staker address:", address);
