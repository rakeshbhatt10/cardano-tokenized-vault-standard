/** Withdraw all principal, claim all rewards, burn the position NFT and return its ADA. */
import { loadStakerContext } from "./wallet.ts";
import { withStateLock } from "../shared/journal.ts";
import {
  ensurePositionClosureSubmitted,
  preparePositionClosure,
  refreshPositionClosureState,
} from "./flows/position-closure.ts";
export { exit as buildExitAll } from "./builders/position-closure.ts";

export async function main() {
  const context = await loadStakerContext();
  await withStateLock(context.path, async () => {
    const session = await preparePositionClosure(context, "exit");
    if (!session) return;
    await ensurePositionClosureSubmitted(session);
    await refreshPositionClosureState(session);
  });
}

if (import.meta.main) await main();
