import { stakingTransaction } from "../../shared/staking-transaction.ts";
import {
  fromText,
  getAddressDetails,
  type LucidEvolution,
  toUnit,
  type UTxO,
} from "npm:@lucid-evolution/lucid@0.4.29";
import {
  type PoolRewards,
  type PositionRewards,
  previewClaim,
} from "../../shared/rewards.ts";
import {
  decodePoolDatum,
  decodePositionDatum,
  encodePoolDatum,
  encodePositionDatum,
  positionPayoutAddress,
  walletOwnerKey,
} from "../../shared/datum.ts";
import { type StakingConfig } from "../../shared/types.ts";
import { type StakingScripts } from "../../shared/scripts.ts";
import { claimRedeemer } from "../../shared/redeemers.ts";

/** Estimate a claim with the same time convention planned for on-chain checks. */
export function previewGetReward(
  pool: PoolRewards,
  position: PositionRewards,
  validityLowerBoundMs: bigint,
) {
  if (validityLowerBoundMs < 0n) {
    throw new Error("Invalid validity lower bound.");
  }
  return previewClaim(pool, position, validityLowerBoundMs / 1000n);
}

/** Build Claim: checkpoint and pay computed rewards, preserving all principal. */
export async function getReward(
  lucid: LucidEvolution,
  config: StakingConfig,
  scripts: StakingScripts,
  poolUtxo: UTxO,
  positionUtxo: UTxO,
  lowerBoundMs: number,
) {
  if (
    !Number.isSafeInteger(lowerBoundMs) || lowerBoundMs < 0 ||
    lowerBoundMs % 1000 !== 0
  ) throw new Error("Use whole-second validity lower bound milliseconds.");
  const poolUnit = toUnit(scripts.poolPolicyId, fromText("POOL"));
  if (
    poolUtxo.address !== scripts.poolAddress ||
    poolUtxo.assets[poolUnit] !== 1n || !poolUtxo.datum
  ) throw new Error("Expected authenticated pool state.");
  if (positionUtxo.address !== scripts.poolAddress || !positionUtxo.datum) {
    throw new Error("Expected inline position state.");
  }
  const before = decodePoolDatum(poolUtxo.datum);
  const previous = decodePositionDatum(
    positionUtxo.datum,
    scripts.positionSchemaVersion,
  );
  const owner =
    getAddressDetails(await lucid.wallet().address()).paymentCredential;
  const positionUnit = toUnit(scripts.poolPolicyId, previous.positionName);
  if (
    owner?.type !== "Key" || owner.hash !== walletOwnerKey(previous.owner) ||
    previous.poolId !== scripts.poolPolicyId ||
    positionUtxo.assets[positionUnit] !== 1n
  ) throw new Error("Position is not owned by the selected wallet/pool.");
  if (
    previous.stakedAmount > before.totalStaked ||
    previous.rewardPerTokenPaid > before.rewardPerTokenStored
  ) throw new Error("Invalid position accounting.");
  const preview = previewClaim({
    totalStaked: before.totalStaked,
    periodFinishSeconds: before.periodFinishSeconds,
    rewardRate: before.rewardRate,
    lastUpdateSeconds: before.lastUpdateSeconds,
    rewardPerTokenStored: before.rewardPerTokenStored,
    accruedLiabilityBound: before.accruedLiabilityBound,
  }, {
    stakedAmount: previous.stakedAmount,
    rewardPerTokenPaid: previous.rewardPerTokenPaid,
    pendingRewards: previous.pendingRewards,
  }, BigInt(lowerBoundMs / 1000));
  const rewardAmount = preview.rewardAmount;
  if (rewardAmount > preview.pool.accruedLiabilityBound) {
    throw new Error("Claim exceeds accrued reward liability.");
  }
  const pool = {
    ...before,
    ...preview.pool,
    accruedLiabilityBound: preview.pool.accruedLiabilityBound - rewardAmount,
  };
  const position = { ...previous, ...preview.position, pendingRewards: 0n };
  const rewardUnit = toUnit(
    config.rewardAsset.policyId,
    config.rewardAsset.tokenNameHex,
  );
  const stakeUnit = toUnit(
    config.stakingAsset.policyId,
    config.stakingAsset.tokenNameHex,
  );
  const assets = {
    ...poolUtxo.assets,
    [rewardUnit]: (poolUtxo.assets[rewardUnit] ?? 0n) - rewardAmount,
  };
  const time = BigInt(lowerBoundMs / 1000);
  const remaining = before.periodFinishSeconds > time
    ? before.periodFinishSeconds - time
    : 0n;
  if (
    assets[rewardUnit] <
      pool.accruedLiabilityBound + remaining * before.rewardRate +
        (rewardUnit === stakeUnit ? pool.totalStaked : 0n)
  ) {
    throw new Error(
      "Insufficient reserves for claim and remaining obligations.",
    );
  }
  if ((assets[stakeUnit] ?? 0n) < pool.totalStaked) {
    throw new Error("Claim would consume staked principal.");
  }
  if (assets[rewardUnit] === 0n) delete assets[rewardUnit];
  const network = getAddressDetails(scripts.poolAddress).networkId === 1
    ? "Mainnet"
    : "Preview";
  const payoutAddress = positionPayoutAddress(previous, network);
  const poolDatum = encodePoolDatum(pool);
  const positionDatum = encodePositionDatum(
    position,
    scripts.positionSchemaVersion,
  );
  const action = claimRedeemer(previous.positionName);
  let tx = stakingTransaction(lucid, scripts).collectFrom([
    poolUtxo,
    positionUtxo,
  ], action)
    .addSignerKey(
      walletOwnerKey(previous.owner),
    )
    .validFrom(lowerBoundMs).validTo(lowerBoundMs + 50_000)
    .pay.ToContract(
      scripts.poolAddress,
      { kind: "inline", value: poolDatum },
      assets,
    )
    .pay.ToContract(scripts.poolAddress, {
      kind: "inline",
      value: positionDatum,
    }, positionUtxo.assets);
  if (rewardAmount > 0n) {
    tx = tx.pay.ToAddress(payoutAddress, { [rewardUnit]: rewardAmount });
  }
  const completed = await tx.complete();
  return {
    completed,
    rewardAmount,
    pool,
    position,
    poolDatum,
    positionDatum,
    positionUnit,
    payoutAddress,
  };
}
export { getReward as claim };
