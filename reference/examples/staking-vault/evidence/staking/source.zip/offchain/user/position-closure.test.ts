import {
  fromText,
  getAddressDetails,
  toUnit,
} from "npm:@lucid-evolution/lucid@0.4.29";
import { testInitializePool } from "../testing/single-staking-fixture.ts";
import { notifyRewards } from "../owner/builders/notify-rewards.ts";
import { stake } from "./builders/stake.ts";
import { withdraw } from "./builders/withdraw.ts";
import { buildExitAll } from "./exit-all.ts";
import { buildCloseEmptyPosition } from "./close-empty-position.ts";
import { decodePoolDatum } from "../shared/datum.ts";
import { loadDeployedTestTokens } from "../shared/deployed-test-tokens.ts";
import { readStakerState, saveStakerState, type StakerState } from "./state.ts";
import {
  preparePositionClosure,
  refreshPositionClosureState,
} from "./flows/position-closure.ts";

Deno.test("exit-all pays rewards/principal, burns the NFT and clears active position tracking", async () => {
  const { lucid, emulator, config, scripts, poolUtxo } =
    await testInitializePool(false);
  const now = () => Math.floor(emulator.now() / 1000) * 1000;
  const send = async (
    completed: Awaited<ReturnType<typeof stake>>["completed"],
  ) => {
    const signed = await completed.sign.withWallet().complete();
    const hash = await signed.submit();
    emulator.awaitBlock(1);
    return hash;
  };
  const poolUnit = toUnit(scripts.poolPolicyId, fromText("POOL"));
  const read = async (unit: string) =>
    (await lucid.utxosAtWithUnit(scripts.poolAddress, unit))[0];
  const stakeUnit = toUnit(
    config.stakingAsset.policyId,
    config.stakingAsset.tokenNameHex,
  );
  const rewardUnit = toUnit(
    config.rewardAsset.policyId,
    config.rewardAsset.tokenNameHex,
  );
  const balance = async (unit: string) =>
    (await lucid.wallet().getUtxos()).reduce(
      (sum, u) => sum + (u.assets[unit] ?? 0n),
      0n,
    );
  const notification = await notifyRewards(
    lucid,
    config,
    scripts,
    poolUtxo,
    70_000_000n,
    604_800n,
    now(),
  );
  await send(notification.completed);
  const deposit = await stake(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    100_000_000n,
    now(),
  );
  await send(deposit.completed);
  emulator.awaitSlot(60);
  const principalBefore = await balance(stakeUnit);
  const rewardsBefore = await balance(rewardUnit);
  const built = await buildExitAll(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    await read(deposit.positionUnit),
    now(),
  );
  if (built.rewardAmount <= 0n || built.principalAmount !== 100_000_000n) {
    throw new Error("Incorrect exit amounts.");
  }
  const hash = await send(built.completed);
  if (
    await balance(stakeUnit) !== principalBefore + built.principalAmount ||
    await balance(rewardUnit) !== rewardsBefore + built.rewardAmount
  ) throw new Error("Exit payout mismatch.");
  if (
    (await lucid.utxosAtWithUnit(scripts.poolAddress, built.positionUnit))
      .length !== 0
  ) throw new Error("Position NFT survived exit.");
  const pool = await read(poolUnit);
  if (decodePoolDatum(pool.datum!).totalStaked !== 0n) {
    throw new Error("Pool principal not decremented.");
  }
  const owner =
    getAddressDetails(await lucid.wallet().address()).paymentCredential;
  if (owner?.type !== "Key") throw new Error("Expected key.");
  const tokens = await loadDeployedTestTokens();
  const directory = await Deno.makeTempDir({
    dir: "/private/tmp",
    prefix: "exit-journal-",
  });
  const context = {
    lucid,
    tokens,
    network: tokens.network,
    owner: owner.hash,
    path: `${directory}/state.json`,
    deploymentPath: "unused",
    blueprintPath: "plutus.json",
  };
  const state: StakerState = {
    owner: owner.hash,
    poolPolicyId: scripts.poolPolicyId,
    positionUnit: built.positionUnit,
    positionRef: { txHash: "old", outputIndex: 0 },
    amount: "100000000",
    expectedStakedAmount: "100000000",
    pendingClosure: {
      action: "exit",
      txHash: hash,
      positionUnit: built.positionUnit,
      principalAmount: built.principalAmount.toString(),
      rewardAmount: built.rewardAmount.toString(),
    },
  };
  try {
    await saveStakerState(context.path, state);
    await refreshPositionClosureState({
      context,
      state,
      config,
      scripts,
      action: "exit",
      positionUnit: built.positionUnit,
      poolUnit,
    });
    const saved = await readStakerState(context.path, owner.hash);
    if (
      saved?.positionUnit || saved?.positionRef || saved?.pendingClosure ||
      saved?.expectedStakedAmount
    ) throw new Error("Closed position still marked active.");
    const archived = JSON.parse(
      await Deno.readTextFile(`${context.path}.last-exit.json`),
    );
    if (archived.pendingClosure.txHash !== hash) {
      throw new Error("Closure history missing.");
    }
    if (await preparePositionClosure(context, "exit") !== undefined) {
      throw new Error("Rerun must skip a closed position.");
    }
    const next = await stake(
      lucid,
      config,
      scripts,
      await read(poolUnit),
      1_000_000n,
      now(),
    );
    await send(next.completed);
    if (next.positionUnit === built.positionUnit) {
      throw new Error("New stake reused the burned marker.");
    }
  } finally {
    await Deno.remove(directory, { recursive: true });
  }
});

Deno.test("close-empty-position rejects stake, then burns the settled position after withdrawal", async () => {
  const { lucid, emulator, config, scripts, poolUtxo } =
    await testInitializePool(false);
  const now = () => Math.floor(emulator.now() / 1000) * 1000;
  const send = async (
    completed: Awaited<ReturnType<typeof stake>>["completed"],
  ) => {
    await (await completed.sign.withWallet().complete()).submit();
    emulator.awaitBlock(1);
  };
  const poolUnit = toUnit(scripts.poolPolicyId, fromText("POOL"));
  const read = async (unit: string) =>
    (await lucid.utxosAtWithUnit(scripts.poolAddress, unit))[0];
  const deposit = await stake(
    lucid,
    config,
    scripts,
    poolUtxo,
    10_000_000n,
    now(),
  );
  await send(deposit.completed);
  let rejected = false;
  try {
    await buildCloseEmptyPosition(
      lucid,
      config,
      scripts,
      await read(poolUnit),
      await read(deposit.positionUnit),
      now(),
    );
  } catch (error) {
    if (!(error instanceof Error) || !error.message.includes("zero stake")) {
      throw error;
    }
    rejected = true;
  }
  if (!rejected) throw new Error("Nonempty position was closed.");
  const withdrawn = await withdraw(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    await read(deposit.positionUnit),
    10_000_000n,
    now(),
  );
  await send(withdrawn.completed);
  const closed = await buildCloseEmptyPosition(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    await read(deposit.positionUnit),
    now(),
  );
  if (closed.principalAmount !== 0n || closed.rewardAmount !== 0n) {
    throw new Error("Empty closure paid assets.");
  }
  await send(closed.completed);
  if (
    (await lucid.utxosAtWithUnit(scripts.poolAddress, closed.positionUnit))
      .length
  ) throw new Error("Position NFT survived empty closure.");
});

Deno.test("pending closure blocks stake/withdraw/claim and cannot switch closure actions", async () => {
  const { prepareStaking } = await import("./stake-all.ts");
  const { prepareWithdrawal } = await import("./unstake-all.ts");
  const { prepareClaim } = await import("./claim-all.ts");
  const { lucid, scripts } = await testInitializePool(false);
  const tokens = await loadDeployedTestTokens();
  const owner =
    getAddressDetails(await lucid.wallet().address()).paymentCredential;
  if (owner?.type !== "Key") throw new Error("Expected key.");
  const directory = await Deno.makeTempDir({
    dir: "/private/tmp",
    prefix: "closure-lock-",
  });
  const context = {
    lucid,
    tokens,
    network: tokens.network,
    owner: owner.hash,
    path: `${directory}/state.json`,
    deploymentPath: "must-not-be-read",
    blueprintPath: "plutus.json",
  };
  const state: StakerState = {
    owner: owner.hash,
    poolPolicyId: scripts.poolPolicyId,
    positionUnit: scripts.poolPolicyId + "aa",
    pendingClosure: {
      action: "exit",
      txHash: "ab".repeat(32),
      positionUnit: scripts.poolPolicyId + "aa",
      principalAmount: "1",
      rewardAmount: "0",
    },
  };
  try {
    await saveStakerState(context.path, state);
    for (
      const operation of [
        () => prepareStaking(context),
        () => prepareWithdrawal(context),
        () => prepareClaim(context),
      ]
    ) {
      let blocked = false;
      try {
        await operation();
      } catch (error) {
        if (
          !(error instanceof Error) ||
          !error.message.includes("Resume exit-all.ts")
        ) throw error;
        blocked = true;
      }
      if (!blocked) throw new Error("Operation overlapped pending closure.");
    }
    let blocked = false;
    try {
      await preparePositionClosure(context, "close-empty");
    } catch (error) {
      if (
        !(error instanceof Error) ||
        !error.message.includes("original position closure")
      ) throw error;
      blocked = true;
    }
    if (!blocked) throw new Error("Pending Exit became CloseEmptyPosition.");
  } finally {
    await Deno.remove(directory, { recursive: true });
  }
});
