import { loadSelectedPool, poolAssets } from "../shared/pool-registry.ts";
import {
  Blockfrost,
  getAddressDetails,
  Lucid,
} from "npm:@lucid-evolution/lucid@0.4.29";
import { loadDeployedTestTokens } from "../shared/deployed-test-tokens.ts";
function required(key: string) {
  const value = Deno.env.get(key)?.trim();
  if (!value) throw new Error(`Set ${key}.`);
  return value;
}

/** Connect the separate staker wallet and verify its configured address. */
export async function loadStakerContext() {
  const network = Deno.env.get("NETWORK") ?? "Mainnet";
  const selected = await loadSelectedPool();
  const tokens = selected
    ? poolAssets(selected)
    : await loadDeployedTestTokens();
  if (network !== tokens.network) {
    throw new Error("The deployed Test1/Test2 assets are Mainnet assets.");
  }
  const lucid = await Lucid(
    new Blockfrost(
      "https://cardano-mainnet.blockfrost.io/api/v0",
      required("BLOCKFROST_API_KEY"),
    ),
    network,
  );
  lucid.selectWallet.fromSeed(required("STAKER_MNEMONIC"));
  const address = await lucid.wallet().address();
  if (address !== required("STAKER_ADDRESS")) {
    throw new Error("Staker mnemonic/address mismatch.");
  }
  const owner = getAddressDetails(address).paymentCredential;
  if (owner?.type !== "Key") throw new Error("Expected a staker payment key.");
  console.log("Staker address:", address);
  return {
    lucid,
    network: tokens.network,
    tokens,
    owner: owner.hash,
    path: selected?.stakerStatePath ?? Deno.env.get("STAKER_STATE_PATH") ??
      "offchain/staker-state.json",
    deploymentPath: selected?.statePath ?? Deno.env.get("STAKING_STATE_PATH") ??
      "offchain/single-staking-state.json",
    blueprintPath: selected?.blueprintPath ?? Deno.env.get("BLUEPRINT_PATH") ??
      "plutus.json",
  };
}
export type StakerContext = Awaited<ReturnType<typeof loadStakerContext>>;
