/** Claim all earned Test2 for the saved staker position, preserving staked Test1. */
import {
  fromText,
  type LucidEvolution,
  toUnit,
  type UTxO,
} from "npm:@lucid-evolution/lucid@0.4.29";
import { loadPoolDeployment } from "../shared/pool-deployment.ts";
import { confirmTransaction, findStateUtxo } from "../shared/transactions.ts";
import { loadStakerContext, type StakerContext } from "./wallet.ts";
import {
  readStakerState,
  requireNoPendingClosure,
  saveStakerState,
} from "./state.ts";
import { withStateLock } from "../shared/journal.ts";
import { getReward } from "./builders/claim.ts";
import { type StakingScripts } from "../shared/scripts.ts";
import { type StakingConfig } from "../shared/types.ts";

/** The existing builder computes the reward; callers never supply a claim amount. */
export async function buildClaimAll(
  lucid: LucidEvolution,
  config: StakingConfig,
  scripts: StakingScripts,
  poolUtxo: UTxO,
  positionUtxo: UTxO,
  lowerBoundMs: number,
) {
  const built = await getReward(
    lucid,
    config,
    scripts,
    poolUtxo,
    positionUtxo,
    lowerBoundMs,
  );
  // Avoid paying transaction fees solely to checkpoint a position with no rewards.
  return built.rewardAmount === 0n ? undefined : built;
}

/** Restore the original pool and position, then reconcile any pending claim first. */
export async function prepareClaim(context: StakerContext) {
  const state = await readStakerState(context.path, context.owner);
  requireNoPendingClosure(state);
  if (!state?.positionUnit) {
    throw new Error("No saved staking position. Stake first.");
  }
  if (state.txHash) {
    throw new Error("Resume stake-all.ts before starting a claim.");
  }
  if (state.pendingWithdrawal) {
    throw new Error("Resume unstake-all.ts before starting a claim.");
  }
  const { config, scripts } = await loadPoolDeployment(
    context.deploymentPath,
    context.network,
    context.blueprintPath,
  );
  if (state.poolPolicyId !== scripts.poolPolicyId) {
    throw new Error("Staker journal belongs to another pool.");
  }
  if (state.pendingClaim) {
    await confirmTransaction(context.lucid, state.pendingClaim.txHash);
  }
  return {
    context,
    state,
    config,
    scripts,
    positionUnit: state.positionUnit,
    poolUnit: toUnit(scripts.poolPolicyId, fromText("POOL")),
  };
}
export type ClaimSession = Awaited<ReturnType<typeof prepareClaim>>;

function findState(session: ClaimSession, unit: string) {
  return findStateUtxo(
    session.context.lucid,
    session.scripts.poolAddress,
    unit,
  );
}

/** Sign and journal before submission; a resumed claim must not submit a second payout. */
export async function ensureClaimSubmitted(session: ClaimSession) {
  const { context: { lucid, path }, state, config, scripts } = session;
  if (state.pendingClaim) return;
  const [poolUtxo, positionUtxo] = await Promise.all([
    findState(session, session.poolUnit),
    findState(session, session.positionUnit),
  ]);
  const apiKey = Deno.env.get("BLOCKFROST_API_KEY");
  if (!apiKey) throw new Error("Set BLOCKFROST_API_KEY.");
  const response = await fetch(
    "https://cardano-mainnet.blockfrost.io/api/v0/blocks/latest",
    {
      headers: { project_id: apiKey },
      signal: AbortSignal.timeout(30_000),
    },
  );
  if (!response.ok) {
    throw new Error(`Network time lookup HTTP ${response.status}.`);
  }
  const tip = await response.json();
  if (!Number.isSafeInteger(tip.time) || tip.time < 0) {
    throw new Error("Invalid network block time.");
  }
  const built = await buildClaimAll(
    lucid,
    config,
    scripts,
    poolUtxo,
    positionUtxo,
    tip.time * 1000,
  );
  if (!built) {
    console.log("No earned Test2 to claim yet.");
    return;
  }
  console.log(
    "Earned Test2 base units at validated claim time:",
    built.rewardAmount.toString(),
  );
  const signed = await built.completed.sign.withWallet().complete();
  state.pendingClaim = {
    txHash: signed.toHash(),
    rewardAmount: built.rewardAmount.toString(),
    expectedPositionDatum: built.positionDatum,
  };
  await saveStakerState(path, state);
  await signed.submit();
  console.log("Claim transaction:", state.pendingClaim.txHash);
  console.log("Reward payout address:", built.payoutAddress);
  await confirmTransaction(lucid, state.pendingClaim.txHash);
}

/** Verify the claimed checkpoint and unchanged principal, archive and clear pending progress. */
export async function refreshClaimState(session: ClaimSession) {
  const { context: { path }, state } = session;
  const pending = state.pendingClaim;
  if (!pending) return;
  // Confirmation can precede the provider's position index update.
  let positionUtxo = await findState(session, session.positionUnit);
  for (
    let attempt = 0;
    positionUtxo.datum !== pending.expectedPositionDatum && attempt < 11;
    attempt++
  ) {
    await new Promise((resolve) => setTimeout(resolve, 5000));
    positionUtxo = await findState(session, session.positionUnit);
  }
  const poolUtxo = await findState(session, session.poolUnit);
  // Checking the complete datum also verifies owner, zero pending rewards and paid accumulator.
  if (positionUtxo.datum !== pending.expectedPositionDatum) {
    throw new Error(
      "Claim position is not indexed or does not match; resume with the same journal.",
    );
  }
  state.positionRef = {
    txHash: positionUtxo.txHash,
    outputIndex: positionUtxo.outputIndex,
  };
  state.poolRef = {
    txHash: poolUtxo.txHash,
    outputIndex: poolUtxo.outputIndex,
  };
  await Deno.writeTextFile(
    `${path}.last-claim.json`,
    JSON.stringify(state, null, 2),
  );
  delete state.pendingClaim;
  await saveStakerState(path, state);
  console.log("Confirmed claim:", pending.txHash);
  console.log("Claimed Test2 base units:", pending.rewardAmount);
}

/** Claims use the same local lock as deposits and withdrawals. */
export async function main() {
  const context = await loadStakerContext();
  await withStateLock(context.path, async () => {
    const session = await prepareClaim(context);
    await ensureClaimSubmitted(session);
    await refreshClaimState(session);
  });
}

if (import.meta.main) await main();
