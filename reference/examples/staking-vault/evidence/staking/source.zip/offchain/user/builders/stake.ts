import { stakingTransaction } from "../../shared/staking-transaction.ts";
import { openPositionRedeemer } from "../../shared/redeemers.ts";
import {
  CML,
  Constr,
  Data,
  fromHex,
  fromText,
  getAddressDetails,
  type LucidEvolution,
  toUnit,
  type UTxO,
} from "npm:@lucid-evolution/lucid@0.4.29";
import { checkpointPool, checkpointPosition } from "../../shared/rewards.ts";
import {
  decodePoolDatum,
  decodePositionDatum,
  encodePoolDatum,
  encodePositionDatum,
  type PositionState,
  walletOwnerKey,
} from "../../shared/datum.ts";
import { type StakingConfig } from "../../shared/types.ts";
import { type StakingScripts } from "../../shared/scripts.ts";

/** Identical to blake2b_256(serialise_data(OutputReference)) in Aiken. */
export function positionTokenName(
  utxo: Pick<UTxO, "txHash" | "outputIndex">,
): string {
  const data = Data.to(new Constr(0, [utxo.txHash, BigInt(utxo.outputIndex)]));
  return CML.hash_plutus_data(CML.PlutusData.from_cbor_bytes(fromHex(data)))
    .to_hex();
}

/** Build a first deposit (mint marker) or top-up (spend existing marker). */
export async function stake(
  lucid: LucidEvolution,
  config: StakingConfig,
  scripts: StakingScripts,
  poolUtxo: UTxO,
  amount: bigint,
  lowerBoundMs: number,
  options: { positionUtxo?: UTxO; creationUtxo?: UTxO } = {},
) {
  if (amount <= 0n) throw new Error("Stake must be positive base units.");
  if (
    !Number.isSafeInteger(lowerBoundMs) || lowerBoundMs < 0 ||
    lowerBoundMs % 1000 !== 0
  ) throw new Error("Use whole-second validity lower bound milliseconds.");
  const poolUnit = toUnit(scripts.poolPolicyId, fromText("POOL"));
  if (
    poolUtxo.address !== scripts.poolAddress ||
    poolUtxo.assets[poolUnit] !== 1n || !poolUtxo.datum
  ) throw new Error("Expected authenticated pool UTxO.");
  const before = decodePoolDatum(poolUtxo.datum);
  if (before.isPaused) throw new Error("Staking is paused.");
  const checkpoint = checkpointPool({
    totalStaked: before.totalStaked,
    periodFinishSeconds: before.periodFinishSeconds,
    rewardRate: before.rewardRate,
    lastUpdateSeconds: before.lastUpdateSeconds,
    rewardPerTokenStored: before.rewardPerTokenStored,
    accruedLiabilityBound: before.accruedLiabilityBound,
  }, BigInt(lowerBoundMs / 1000));
  const pool = {
    ...before,
    ...checkpoint,
    totalStaked: before.totalStaked + amount,
  };
  const address = await lucid.wallet().address();
  const addressDetails = getAddressDetails(address);
  const credential = addressDetails.paymentCredential;
  if (credential?.type !== "Key") {
    throw new Error("Expected a staking wallet key.");
  }
  const owner = credential.hash;
  let position: PositionState;
  let creation: UTxO | undefined;
  const previous = options.positionUtxo;
  if (previous) {
    if (options.creationUtxo) {
      throw new Error("A top-up does not consume a creation reference.");
    }
    if (!previous.datum || previous.address !== scripts.poolAddress) {
      throw new Error("Missing position state.");
    }
    const old = decodePositionDatum(
      previous.datum,
      scripts.positionSchemaVersion,
    );
    if (
      old.poolId !== scripts.poolPolicyId ||
      walletOwnerKey(old.owner) !== owner ||
      previous.assets[toUnit(old.poolId, old.positionName)] !== 1n
    ) throw new Error("Position is not owned by this wallet/pool.");
    if (old.rewardPerTokenPaid > before.rewardPerTokenStored) {
      throw new Error("Invalid position checkpoint.");
    }
    position = {
      ...old,
      ...checkpointPosition({
        stakedAmount: old.stakedAmount,
        pendingRewards: old.pendingRewards,
        rewardPerTokenPaid: old.rewardPerTokenPaid,
      }, pool.rewardPerTokenStored),
      stakedAmount: old.stakedAmount + amount,
    };
  } else {
    const walletUtxos = await lucid.wallet().getUtxos();
    creation = options.creationUtxo ??
      walletUtxos.find((u) =>
        !u.scriptRef &&
        !Object.keys(u.assets).some((unit) =>
          unit.startsWith(scripts.poolPolicyId)
        )
      );
    if (
      !creation || creation.address !== address ||
      !walletUtxos.some((u) =>
        u.txHash === creation!.txHash && u.outputIndex === creation!.outputIndex
      )
    ) {
      throw new Error(
        "Need an available creation UTxO owned by the selected wallet.",
      );
    }
    // Preserve the selected wallet's full immutable payout address.
    if (
      addressDetails.type !== "Base" && addressDetails.type !== "Enterprise"
    ) {
      throw new Error("Use a base or enterprise staking wallet address.");
    }
    const stakeCredential = addressDetails.stakeCredential;
    const stakingPart = stakeCredential
      ? new Constr(0, [
        new Constr(0, [
          new Constr(stakeCredential.type === "Key" ? 0 : 1, [
            stakeCredential.hash,
          ]),
        ]),
      ])
      : new Constr(1, []);
    const payoutAddress = new Constr(0, [new Constr(0, [owner]), stakingPart]);
    position = {
      poolId: scripts.poolPolicyId,
      positionName: positionTokenName(creation),
      owner: { kind: "WalletOwner", paymentKeyHash: owner },
      payoutAddress,
      stakedAmount: amount,
      rewardPerTokenPaid: pool.rewardPerTokenStored,
      pendingRewards: 0n,
    };
  }
  const positionUnit = toUnit(scripts.poolPolicyId, position.positionName);
  const ref = creation
    ? new Constr(0, [creation.txHash, BigInt(creation.outputIndex)])
    : undefined;
  const action = Data.to(
    new Constr(0, [
      amount,
      position.positionName,
      ref ? new Constr(0, [ref]) : new Constr(1, []),
    ]),
  );
  const stakeUnit = toUnit(
    config.stakingAsset.policyId,
    config.stakingAsset.tokenNameHex,
  );
  const poolAssets = {
    ...poolUtxo.assets,
    [stakeUnit]: (poolUtxo.assets[stakeUnit] ?? 0n) + amount,
  };
  const poolDatum = encodePoolDatum(pool);
  const positionDatum = encodePositionDatum(
    position,
    scripts.positionSchemaVersion,
  );
  let tx = stakingTransaction(lucid, scripts).collectFrom([poolUtxo], action)
    .addSignerKey(owner).validFrom(lowerBoundMs).validTo(lowerBoundMs + 50_000);
  if (creation && ref) {
    tx = tx.collectFrom([creation])
      .mintAssets(
        { [positionUnit]: 1n },
        openPositionRedeemer(
          ref,
          position.owner,
          scripts.positionSchemaVersion,
        ),
      );
  } else if (previous) tx = tx.collectFrom([previous], action);
  const completed = await tx
    .pay.ToContract(
      scripts.poolAddress,
      { kind: "inline", value: poolDatum },
      poolAssets,
    )
    .pay.ToContract(scripts.poolAddress, {
      kind: "inline",
      value: positionDatum,
    }, previous ? previous.assets : { [positionUnit]: 1n })
    .complete();
  return { completed, pool, position, poolDatum, positionDatum, positionUnit };
}
