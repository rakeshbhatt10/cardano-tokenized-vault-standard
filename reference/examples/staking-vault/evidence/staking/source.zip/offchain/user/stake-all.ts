import {
  fromText,
  type LucidEvolution,
  toUnit,
  type UTxO,
} from "npm:@lucid-evolution/lucid@0.4.29";
import { decodePositionDatum, walletOwnerKey } from "../shared/datum.ts";
import { loadPoolDeployment } from "../shared/pool-deployment.ts";
import { type StakingScripts } from "../shared/scripts.ts";
import { stake } from "./builders/stake.ts";
import { type StakingConfig } from "../shared/types.ts";

import { withStateLock } from "../shared/journal.ts";

import { confirmTransaction, findStateUtxo } from "../shared/transactions.ts";
import { loadStakerContext, type StakerContext } from "./wallet.ts";
import {
  readStakerState,
  requireNoPendingClosure,
  saveStakerState,
  type StakerState,
} from "./state.ts";
import { walletTokenBalance } from "../shared/transactions.ts";

/** Build a full-balance deposit; an unfunded wallet is intentionally a no-op. */
export async function buildStakeAll(
  lucid: LucidEvolution,
  config: StakingConfig,
  scripts: StakingScripts,
  poolUtxo: UTxO,
  lowerBoundMs: number,
  positionUtxo?: UTxO,
) {
  const unit = toUnit(
    config.stakingAsset.policyId,
    config.stakingAsset.tokenNameHex,
  );
  const amount = await walletTokenBalance(lucid, unit);
  if (amount === 0n) return undefined;
  const built = await stake(
    lucid,
    config,
    scripts,
    poolUtxo,
    amount,
    lowerBoundMs,
    { positionUtxo },
  );
  return { ...built, amount };
}

/**
 * Resume a pending submission before considering another deposit. An unfunded
 * wallet can exit here without requiring an existing pool deployment.
 */
export async function prepareStaking(context: StakerContext) {
  const { lucid, path, owner, tokens } = context;
  const saved = await readStakerState(path, owner);
  requireNoPendingClosure(saved);
  if (saved?.pendingClaim) {
    throw new Error("Resume claim-all.ts before starting another deposit.");
  }
  if (saved?.pendingWithdrawal) {
    throw new Error("Resume unstake-all.ts before starting another deposit.");
  }
  if (saved?.txHash) await confirmTransaction(lucid, saved.txHash);

  const amount = await walletTokenBalance(lucid, tokens.stakingUnit);
  console.log("Available staking-token base units:", amount.toString());
  if (amount === 0n && !saved?.txHash) {
    console.log(
      "Nothing to stake yet. Transfer the configured staking token and ADA to this staker address first.",
    );
    return undefined;
  }

  const { config, scripts } = await loadPoolDeployment(
    context.deploymentPath,
    context.network,
    context.blueprintPath,
  );
  if (saved && saved.poolPolicyId !== scripts.poolPolicyId) {
    throw new Error("Use a separate STAKER_STATE_PATH for a different pool.");
  }
  const state: StakerState = saved ?? {
    owner,
    poolPolicyId: scripts.poolPolicyId,
  };
  return {
    context,
    config,
    scripts,
    state,
    poolUnit: toUnit(scripts.poolPolicyId, fromText("POOL")),
  };
}
export type StakingSession = NonNullable<
  Awaited<ReturnType<typeof prepareStaking>>
>;

/** Require exactly one script output carrying the pool or position identity NFT. */
async function findStakingState(session: StakingSession, unit: string) {
  return await findStateUtxo(
    session.context.lucid,
    session.scripts.poolAddress,
    unit,
  );
}

/** Create a new position or top up the saved position with the entire Test1 balance. */
export async function ensureStakeSubmitted(session: StakingSession) {
  const { context: { lucid, path }, config, scripts, state, poolUnit } =
    session;
  // prepareStaking already confirmed a saved hash; never deposit again on recovery.
  if (state.txHash) return;
  const poolUtxo = await findStakingState(session, poolUnit);
  const positionUtxo = state.positionUnit
    ? await findStakingState(session, state.positionUnit)
    : undefined;
  // Anchor validity to the network, rather than a possibly skewed host clock.
  const apiKey = Deno.env.get("BLOCKFROST_API_KEY");
  if (!apiKey) throw new Error("Set BLOCKFROST_API_KEY.");
  const response = await fetch(
    "https://cardano-mainnet.blockfrost.io/api/v0/blocks/latest",
    {
      headers: { project_id: apiKey },
      signal: AbortSignal.timeout(30_000),
    },
  );
  if (!response.ok) {
    throw new Error(`Network time lookup HTTP ${response.status}.`);
  }
  const tip = await response.json();
  if (!Number.isSafeInteger(tip.time) || tip.time < 0) {
    throw new Error("Invalid network block time.");
  }
  const built = await buildStakeAll(
    lucid,
    config,
    scripts,
    poolUtxo,
    tip.time * 1000,
    positionUtxo,
  );
  if (!built) {
    console.log("No staking tokens available to stake.");
    return;
  }
  const signed = await built.completed.sign.withWallet().complete();
  state.txHash = signed.toHash();
  state.positionUnit = built.positionUnit;
  state.amount = built.amount.toString();
  state.expectedStakedAmount = built.position.stakedAmount.toString();
  // Save before submission so ambiguous failures cannot trigger duplicate deposits.
  await saveStakerState(path, state);
  await signed.submit();
  console.log("Stake transaction:", state.txHash);
  await confirmTransaction(lucid, state.txHash);
}

/** Verify the observed position, cache current references and clear pending progress. */
export async function refreshStakerState(session: StakingSession) {
  const { context: { owner, path }, scripts, state, poolUnit } = session;
  if (!state.positionUnit || !state.txHash) return;
  const positionUtxo = await findStakingState(session, state.positionUnit);
  const position = decodePositionDatum(
    positionUtxo.datum!,
    scripts.positionSchemaVersion,
  );
  if (
    walletOwnerKey(position.owner) !== owner ||
    position.poolId !== scripts.poolPolicyId ||
    position.stakedAmount.toString() !== state.expectedStakedAmount
  ) {
    throw new Error(
      "Position update is not indexed or does not match the submitted stake; retry with the same journal.",
    );
  }
  const poolUtxo = await findStakingState(session, poolUnit);
  state.positionRef = {
    txHash: positionUtxo.txHash,
    outputIndex: positionUtxo.outputIndex,
  };
  state.poolRef = {
    txHash: poolUtxo.txHash,
    outputIndex: poolUtxo.outputIndex,
  };
  console.log(
    "Confirmed stake:",
    state.txHash,
    "Total position base units:",
    position.stakedAmount.toString(),
  );
  // Archive the submitted hash before clearing the pending flag in the journal.
  await Deno.writeTextFile(
    `${path}.last-tx.json`,
    JSON.stringify(state, null, 2),
  );
  delete state.txHash;
  await saveStakerState(path, state);
}

/** Stakes all currently available Test1; Test2 and excess ADA remain in the wallet. */
export async function main() {
  const context = await loadStakerContext();
  await withStateLock(context.path, async () => {
    const session = await prepareStaking(context);
    if (!session) return;
    await ensureStakeSubmitted(session);
    await refreshStakerState(session);
  });
}

if (import.meta.main) await main();
