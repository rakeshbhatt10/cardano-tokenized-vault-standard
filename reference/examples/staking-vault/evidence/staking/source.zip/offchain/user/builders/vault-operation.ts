import {
  CML,
  Constr,
  credentialToAddress,
  Data,
  fromHex,
  getAddressDetails,
  type LucidEvolution,
  type SpendingValidator,
  toUnit,
  type TxBuilder,
  type UTxO,
  validatorToScriptHash,
} from "npm:@lucid-evolution/lucid@0.4.29";
import {
  decodeFactoryRegistration,
  decodeVaultAuthorization,
  encodeStakingOperation,
} from "../../shared/authorization.ts";
import {
  decodePoolDatum,
  decodePositionDatum,
  encodePoolDatum,
  encodePositionDatum,
  type PositionOwner,
  type PositionState,
} from "../../shared/datum.ts";
import { checkpointPool, checkpointPosition } from "../../shared/rewards.ts";
import { openPositionRedeemer } from "../../shared/redeemers.ts";
import { attachStakingProgram } from "../../shared/staking-transaction.ts";
import type { StakingConfig } from "../../shared/types.ts";
import type { StakingScripts } from "../../shared/scripts.ts";
import { positionTokenName } from "./stake.ts";

export type VaultOwner = Extract<PositionOwner, { kind: "VaultOwner" }>;
export interface VaultOperationInputs {
  owner: VaultOwner;
  authorizationCbor: string;
  poolInput: UTxO;
  stateInput: UTxO;
  configReference: UTxO;
  controller: { script: SpendingValidator } | { reference: UTxO };
  positionInput?: UTxO;
  creationInput?: UTxO;
  certificateReference?: UTxO;
  positionLovelace?: bigint;
  lowerBoundMs: number;
}
function hashData(cbor: string) {
  return CML.hash_plutus_data(CML.PlutusData.from_cbor_bytes(fromHex(cbor)))
    .to_hex();
}

/** Append an unsigned staking/controller component. The caller supplies the State
 * continuation at the declared index, share mint/burn, receiver/fee outputs and
 * funding before completing/evaluating. No wallet owner/signing/submission flow. */
export function composeVaultOperation(
  lucid: LucidEvolution,
  config: StakingConfig,
  scripts: StakingScripts,
  input: VaultOperationInputs,
  existing?: TxBuilder,
) {
  if (
    scripts.interfaceVersion !== "factory-v1" || !config.vaultSupported ||
    !config.factoryPolicy || config.initiallyLocked
  ) throw new Error("Require the unlocked factory-admitted pool profile.");
  const auth = decodeVaultAuthorization(input.authorizationCbor);
  if (auth.kind !== "staking") {
    throw new Error("Maintenance cannot authorize staking.");
  }
  const owner = input.owner;
  if (
    owner.controllerScriptHash !== owner.statePolicyId ||
    owner.stateAssetName !== "5354415445"
  ) throw new Error("Unsupported vault identity profile.");
  if (
    !Number.isSafeInteger(input.lowerBoundMs) || input.lowerBoundMs < 0 ||
    input.lowerBoundMs % 1000
  ) throw new Error("Use whole-second validity lower bound milliseconds.");
  const network = getAddressDetails(scripts.poolAddress).networkId === 1
    ? "Mainnet"
    : "Preview";
  const custody = credentialToAddress(network, {
    type: "Script",
    hash: owner.controllerScriptHash,
  });
  const payout = new Constr(0, [
    new Constr(1, [owner.controllerScriptHash]),
    new Constr(1, []),
  ]);
  const poolUnit = toUnit(scripts.poolPolicyId, "504f4f4c");
  if (
    auth.poolId !== scripts.poolPolicyId ||
    input.poolInput.address !== scripts.poolAddress ||
    input.poolInput.assets[poolUnit] !== 1n || !input.poolInput.datum
  ) throw new Error("Wrong pool input/authorization.");
  const stateUnit = toUnit(owner.statePolicyId, owner.stateAssetName);
  if (
    input.stateInput.address !== custody ||
    input.stateInput.assets[stateUnit] !== 1n || !input.stateInput.datum
  ) throw new Error("Expected consumed genuine controller State.");
  if (
    !input.configReference.datum ||
    input.configReference.assets[toUnit(owner.statePolicyId, "4944")] !== 1n
  ) throw new Error("Expected authenticated Config reference.");
  const before = decodePoolDatum(input.poolInput.datum);
  const entering = auth.operation === "stake";
  if (before.isLocked || (entering && before.isPaused)) {
    throw new Error("Pool unavailable for this operation.");
  }
  const stakeUnit = toUnit(
    config.stakingAsset.policyId,
    config.stakingAsset.tokenNameHex,
  );
  const rewardUnit = toUnit(
    config.rewardAsset.policyId,
    config.rewardAsset.tokenNameHex,
  );
  if (stakeUnit === rewardUnit) {
    throw new Error(
      "The registered CTVS profile requires distinct principal/reward assets.",
    );
  }
  const checkpoint = {
    ...before,
    ...checkpointPool(before, BigInt(input.lowerBoundMs / 1000)),
  };
  let previous: PositionState;
  const creation = auth.creationRef;
  const marker = toUnit(scripts.poolPolicyId, auth.positionName);
  if (creation) {
    if (
      !entering || input.positionInput || !input.creationInput ||
      !input.certificateReference?.datum
    ) {
      throw new Error(
        "First stake requires seed and factory certificate, with no prior position.",
      );
    }
    if (
      input.creationInput.txHash !== creation.txId ||
      BigInt(input.creationInput.outputIndex) !== creation.index ||
      positionTokenName(input.creationInput) !== auth.positionName
    ) throw new Error("Wrong position creation seed/name.");
    if (
      getAddressDetails(input.creationInput.address).paymentCredential?.type !==
        "Key"
    ) throw new Error("Position creation seed must be key-controlled.");
    if (
      input.certificateReference
        .assets[toUnit(config.factoryPolicy, owner.controllerScriptHash)] !== 1n
    ) {
      throw new Error(
        "Certificate is not authenticated by the pool factory policy.",
      );
    }
    const certificate = decodeFactoryRegistration(
      input.certificateReference.datum,
    );
    if (
      certificate.controller !== owner.controllerScriptHash ||
      certificate.statePolicy !== owner.statePolicyId ||
      certificate.stateName !== owner.stateAssetName ||
      certificate.configHash !== hashData(input.configReference.datum)
    ) throw new Error("Factory certificate identity/Config mismatch.");
    if (input.positionLovelace === undefined || input.positionLovelace <= 0n) {
      throw new Error("Specify new position storage lovelace.");
    }
    previous = {
      poolId: scripts.poolPolicyId,
      positionName: auth.positionName,
      owner,
      payoutAddress: payout,
      stakedAmount: 0n,
      rewardPerTokenPaid: checkpoint.rewardPerTokenStored,
      pendingRewards: 0n,
    };
  } else {
    if (!input.positionInput?.datum || input.creationInput) {
      throw new Error(
        "Existing operation requires the position, not a creation seed.",
      );
    }
    if (
      input.positionInput.address !== scripts.poolAddress ||
      input.positionInput.assets[marker] !== 1n
    ) throw new Error("Wrong position input.");
    previous = decodePositionDatum(input.positionInput.datum, 2);
    if (
      previous.poolId !== scripts.poolPolicyId ||
      previous.positionName !== auth.positionName ||
      (previous.owner.kind !== "VaultOwner" ||
        previous.owner.controllerScriptHash !== owner.controllerScriptHash ||
        previous.owner.statePolicyId !== owner.statePolicyId ||
        previous.owner.stateAssetName !== owner.stateAssetName) ||
      Data.to(previous.payoutAddress) !== Data.to(payout)
    ) throw new Error("Position owner/custody binding mismatch.");
  }
  if (
    previous.stakedAmount > before.totalStaked ||
    (!creation && previous.rewardPerTokenPaid > before.rewardPerTokenStored)
  ) throw new Error("Invalid position accounting.");
  const accrued = {
    ...previous,
    ...checkpointPosition(previous, checkpoint.rewardPerTokenStored),
  };
  if (!entering && auth.amount > previous.stakedAmount) {
    throw new Error("Withdrawal exceeds this position.");
  }
  const claim = entering ? 0n : accrued.pendingRewards;
  if (claim > checkpoint.accruedLiabilityBound) {
    throw new Error("Claim exceeds pool liability.");
  }
  const pool = {
    ...checkpoint,
    totalStaked: before.totalStaked + (entering ? auth.amount : -auth.amount),
    accruedLiabilityBound: checkpoint.accruedLiabilityBound - claim,
  };
  const position = {
    ...accrued,
    stakedAmount: previous.stakedAmount +
      (entering ? auth.amount : -auth.amount),
    pendingRewards: entering ? accrued.pendingRewards : 0n,
  };
  const poolAssets = {
    ...input.poolInput.assets,
    [stakeUnit]: (input.poolInput.assets[stakeUnit] ?? 0n) +
      (entering ? auth.amount : -auth.amount),
    [rewardUnit]: (input.poolInput.assets[rewardUnit] ?? 0n) - claim,
  };
  const remaining =
    before.periodFinishSeconds > BigInt(input.lowerBoundMs / 1000)
      ? before.periodFinishSeconds - BigInt(input.lowerBoundMs / 1000)
      : 0n;
  if (
    poolAssets[stakeUnit] < pool.totalStaked ||
    poolAssets[rewardUnit] <
      pool.accruedLiabilityBound + remaining * before.rewardRate
  ) throw new Error("Insufficient pool backing/reserves.");
  if (!poolAssets[stakeUnit]) delete poolAssets[stakeUnit];
  if (!poolAssets[rewardUnit]) delete poolAssets[rewardUnit];
  const witness = "script" in input.controller
    ? input.controller.script
    : input.controller.reference.scriptRef;
  if (
    !witness || validatorToScriptHash(witness) !== owner.controllerScriptHash
  ) throw new Error("Wrong controller script witness.");
  let tx = attachStakingProgram(existing ?? lucid.newTx(), scripts)
    .collectFrom(
      [input.poolInput],
      encodeStakingOperation(input.authorizationCbor),
    )
    .collectFrom([input.stateInput], input.authorizationCbor)
    .readFrom([input.configReference]);
  tx = "script" in input.controller
    ? tx.attach.SpendingValidator(input.controller.script)
    : tx.readFrom([input.controller.reference]);
  if (creation) {
    tx = tx.collectFrom([input.creationInput!]).readFrom([
      input.certificateReference!,
    ]).mintAssets(
      { [marker]: 1n },
      openPositionRedeemer(
        new Constr(0, [creation.txId, creation.index]),
        owner,
      ),
    );
  } else {tx = tx.collectFrom(
      [input.positionInput!],
      encodeStakingOperation(input.authorizationCbor),
    );}
  tx = tx.validFrom(input.lowerBoundMs).validTo(input.lowerBoundMs + 50_000)
    .pay.ToContract(scripts.poolAddress, {
      kind: "inline",
      value: encodePoolDatum(pool),
    }, poolAssets)
    .pay.ToContract(
      scripts.poolAddress,
      { kind: "inline", value: encodePositionDatum(position) },
      input.positionInput?.assets ??
        { [marker]: 1n, lovelace: input.positionLovelace! },
    );
  return {
    tx,
    pool,
    position,
    rewardAmount: claim,
    principalAmount: auth.amount,
    requiredStateOutputIndex: auth.stateOutput,
    positionUnit: marker,
  };
}
