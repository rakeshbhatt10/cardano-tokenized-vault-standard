import { loadSelectedPool } from "../../shared/pool-registry.ts";
/** Transfer existing Test2 to the pool owner. Never mints or initializes a pool. */
import {
  Blockfrost,
  getAddressDetails,
  Lucid,
  type LucidEvolution,
} from "npm:@lucid-evolution/lucid@0.4.29";
import { loadDeployedTestTokens } from "../../shared/deployed-test-tokens.ts";
import {
  confirmTransaction,
  walletTokenBalance,
} from "../../shared/transactions.ts";
import { withStateLock, writeJsonAtomic } from "../../shared/journal.ts";
import { selectOwnerWallet } from "../wallet.ts";

export function parseRewardTransferAmount(value = "1000000000") {
  if (!/^[1-9][0-9]*$/.test(value)) {
    throw new Error(
      "REWARD_TRANSFER_AMOUNT must be positive integer Test2 base units.",
    );
  }
  return BigInt(value);
}

/** Build a plain native-token transfer from the selected sender; no minting policy needed. */
export async function buildRewardTransfer(
  lucid: LucidEvolution,
  unit: string,
  amount: bigint,
  ownerAddress: string,
) {
  if (amount <= 0n) throw new Error("Transfer amount must be positive.");
  const senderAddress = await lucid.wallet().address();
  if (senderAddress === ownerAddress) {
    throw new Error("Sender and owner must be different wallets.");
  }
  if (
    getAddressDetails(senderAddress).networkId !==
      getAddressDetails(ownerAddress).networkId
  ) throw new Error("Sender/owner networks differ.");
  if (await walletTokenBalance(lucid, unit) < amount) {
    throw new Error(
      "Sender has insufficient existing Test2; no tokens will be minted.",
    );
  }
  return await lucid.newTx().pay.ToAddress(ownerAddress, { [unit]: amount })
    .complete();
}

export async function loadRewardTransferContext() {
  const selected = await loadSelectedPool();
  const tokens = await loadDeployedTestTokens();
  if (
    (Deno.env.get("NETWORK") ?? "Mainnet") !== tokens.network ||
    tokens.decimals !== 6
  ) throw new Error("Expected deployed Mainnet Test1/Test2 with six decimals.");
  const apiKey = Deno.env.get("BLOCKFROST_API_KEY")?.trim();
  if (!apiKey) throw new Error("Set BLOCKFROST_API_KEY.");
  const lucid = await Lucid(
    new Blockfrost("https://cardano-mainnet.blockfrost.io/api/v0", apiKey),
    "Mainnet",
  );
  await selectOwnerWallet(lucid);
  const ownerAddress = await lucid.wallet().address();
  const configuredOwner = Deno.env.get("OWNER_ADDRESS")?.trim();
  if (configuredOwner && configuredOwner !== ownerAddress) {
    throw new Error("Owner mnemonic/address mismatch.");
  }
  const explicitSender = Deno.env.get("REWARD_SENDER_MNEMONIC")?.trim();
  const seed = explicitSender || Deno.env.get("RECIPIENT_MNEMONIC")?.trim();
  if (!seed) {
    throw new Error(
      "Set REWARD_SENDER_MNEMONIC or RECIPIENT_MNEMONIC for the wallet holding Test2.",
    );
  }
  lucid.selectWallet.fromSeed(seed);
  const senderAddress = await lucid.wallet().address();
  const expectedSender = explicitSender
    ? Deno.env.get("REWARD_SENDER_ADDRESS")?.trim()
    : tokens.recipientAddress;
  if (expectedSender && senderAddress !== expectedSender) {
    throw new Error("Reward sender mnemonic/address mismatch.");
  }
  if (senderAddress === ownerAddress) {
    throw new Error("Sender and owner are the same wallet.");
  }
  return {
    lucid,
    tokens,
    ownerAddress,
    senderAddress,
    amount: parseRewardTransferAmount(Deno.env.get("REWARD_TRANSFER_AMOUNT")),
    path: Deno.env.get("REWARD_TRANSFER_STATE_PATH") ??
      (selected
        ? `${selected.statePath}.reward-transfer.json`
        : "offchain/single-staking-state.json.reward-transfer.json"),
  };
}
export type RewardTransferContext = Awaited<
  ReturnType<typeof loadRewardTransferContext>
>;
type TransferState = { identity: string; txHash: string; confirmed: boolean };

/** Read-only readiness check: exact existing token identities, balances and total budget. */
export async function checkRewardTransfer(context: RewardTransferContext) {
  const { lucid, tokens, ownerAddress, senderAddress, amount } = context;
  const [senderUtxos, ownerUtxos] = await Promise.all([
    lucid.wallet().getUtxos(),
    lucid.utxosAt(ownerAddress),
  ]);
  const sum = (utxos: typeof senderUtxos, unit: string) =>
    utxos.reduce((total, u) => total + (u.assets[unit] ?? 0n), 0n);
  console.log(JSON.stringify(
    {
      network: tokens.network,
      stakingUnit: tokens.stakingUnit,
      rewardUnit: tokens.rewardUnit,
      ownerAddress,
      senderAddress,
      transferTest2: Number(amount) / 1e6,
      senderTest2: Number(sum(senderUtxos, tokens.rewardUnit)) / 1e6,
      ownerTest2: Number(sum(ownerUtxos, tokens.rewardUnit)) / 1e6,
      senderLovelace: sum(senderUtxos, "lovelace").toString(),
      ownerLovelace: sum(ownerUtxos, "lovelace").toString(),
      configuredRewardBudgetBaseUnits: Deno.env.get("STAKING_REWARD_AMOUNT") ??
        "70000000",
      durationSeconds: 604800,
      integerRateTest2PerDay: 9.936,
    },
    null,
    2,
  ));
  return sum(senderUtxos, tokens.rewardUnit) >= amount;
}

export async function transferRewardsToOwner(context: RewardTransferContext) {
  await withStateLock(context.path, async () => {
    const identity = JSON.stringify({
      network: context.tokens.network,
      unit: context.tokens.rewardUnit,
      from: context.senderAddress,
      to: context.ownerAddress,
      amount: context.amount.toString(),
    });
    let state: TransferState | undefined;
    try {
      state = JSON.parse(await Deno.readTextFile(context.path));
    } catch (error) {
      if (!(error instanceof Deno.errors.NotFound)) throw error;
    }
    if (state && state.identity !== identity) {
      throw new Error(
        "Transfer journal settings differ; use original settings or a separate REWARD_TRANSFER_STATE_PATH.",
      );
    }
    if (!state) {
      const completed = await buildRewardTransfer(
        context.lucid,
        context.tokens.rewardUnit,
        context.amount,
        context.ownerAddress,
      );
      const signed = await completed.sign.withWallet().complete();
      state = { identity, txHash: signed.toHash(), confirmed: false };
      await writeJsonAtomic(context.path, state);
      await signed.submit();
    }
    if (!state.confirmed) {
      await confirmTransaction(context.lucid, state.txHash);
      state.confirmed = true;
      await writeJsonAtomic(context.path, state);
    }
    console.log("Confirmed Test2 transfer:", state.txHash);
    const ownerUtxos = await context.lucid.utxosAt(context.ownerAddress);
    console.log(
      "Current owner Test2 base units:",
      ownerUtxos.reduce(
        (sum, u) => sum + (u.assets[context.tokens.rewardUnit] ?? 0n),
        0n,
      ).toString(),
    );
  });
}

export async function main() {
  const context = await loadRewardTransferContext();
  const sufficient = await checkRewardTransfer(context);
  if (Deno.args.includes("--check")) {
    if (!sufficient) {
      console.log(
        "Transfer not ready: sender lacks the requested existing Test2 balance.",
      );
    }
    return;
  }
  await transferRewardsToOwner(context);
}
if (import.meta.main) await main();
