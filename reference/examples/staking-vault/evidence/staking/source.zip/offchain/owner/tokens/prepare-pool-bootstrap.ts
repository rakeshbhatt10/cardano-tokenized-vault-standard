/** Create an ADA-only bootstrap output without moving any tokens out of the owner wallet. */
import { loadOwnerPoolContext } from "../wallet.ts";
import { loadSelectedPool } from "../../shared/pool-registry.ts";
import { withStateLock, writeJsonAtomic } from "../../shared/journal.ts";
import { confirmTransaction } from "../../shared/transactions.ts";

export async function main() {
  const pool = await loadSelectedPool();
  if (!pool) throw new Error("Select POOL_ID before preparing its bootstrap.");
  const { lucid } = await loadOwnerPoolContext();
  const path = `${pool.statePath}.bootstrap.json`;
  await withStateLock(path, async () => {
    let state: { txHash: string; confirmed: boolean } | undefined;
    try {
      state = JSON.parse(await Deno.readTextFile(path));
    } catch (error) {
      if (!(error instanceof Deno.errors.NotFound)) throw error;
    }
    if (!state) {
      const utxos = await lucid.wallet().getUtxos();
      if (
        utxos.some((u) =>
          Object.keys(u.assets).every((unit) => unit === "lovelace")
        )
      ) {
        console.log("An ADA-only bootstrap output already exists.");
        return;
      }
      const address = await lucid.wallet().address();
      const completed = await lucid.newTx().pay.ToAddress(address, {
        lovelace: 2_000_000n,
      }).complete();
      const signed = await completed.sign.withWallet().complete();
      state = { txHash: signed.toHash(), confirmed: false };
      await writeJsonAtomic(path, state);
      await signed.submit();
      console.log("Bootstrap preparation submitted:", state.txHash);
    }
    if (!state.confirmed) {
      await confirmTransaction(lucid, state.txHash);
      state.confirmed = true;
      await writeJsonAtomic(path, state);
    }
    console.log("Bootstrap preparation confirmed:", state.txHash);
  });
}
if (import.meta.main) await main();
