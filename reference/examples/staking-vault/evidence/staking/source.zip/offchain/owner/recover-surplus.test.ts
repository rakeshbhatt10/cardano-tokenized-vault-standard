import {
  fromText,
  generateEmulatorAccount,
  toUnit,
} from "npm:@lucid-evolution/lucid@0.4.29";
import { testInitializePool } from "../testing/single-staking-fixture.ts";
import { fundRewards } from "./builders/fund-rewards.ts";
import { getReward } from "../user/builders/claim.ts";
import { notifyRewards } from "./builders/notify-rewards.ts";
import { stake } from "../user/builders/stake.ts";
import {
  buildRecoverSurplus,
  ensureRecoverySubmitted,
  parseRecoverySettings,
  type RecoverySession,
  refreshRecoveryState,
} from "./recover-surplus.ts";
import { decodePoolDatum } from "../shared/datum.ts";

Deno.test("recovery pays real surplus, preserves principal/emissions and protects claims after expiry", async () => {
  const { lucid, emulator, config, scripts, poolUtxo } =
    await testInitializePool(false);
  const now = () => Math.floor(emulator.now() / 1000) * 1000;
  const send = async (
    completed: Awaited<ReturnType<typeof stake>>["completed"],
  ) => {
    const signed = await completed.sign.withWallet().complete();
    const hash = await signed.submit();
    emulator.awaitBlock(1);
    return hash;
  };
  const poolUnit = toUnit(scripts.poolPolicyId, fromText("POOL"));
  const stakeUnit = toUnit(
    config.stakingAsset.policyId,
    config.stakingAsset.tokenNameHex,
  );
  const rewardUnit = toUnit(
    config.rewardAsset.policyId,
    config.rewardAsset.tokenNameHex,
  );
  const read = async () =>
    (await lucid.utxosAtWithUnit(scripts.poolAddress, poolUnit))[0];
  const notified = await notifyRewards(
    lucid,
    config,
    scripts,
    poolUtxo,
    70_000_000n,
    604_800n,
    now(),
  );
  await send(notified.completed);
  const deposit = await stake(
    lucid,
    config,
    scripts,
    await read(),
    100_000_000n,
    now(),
  );
  await send(deposit.completed);
  await send(
    (await fundRewards(lucid, config, scripts, await read(), 30_000_000n))
      .completed,
  );
  const before = await read();
  const balance = async () =>
    (await lucid.wallet().getUtxos()).reduce(
      (sum, u) => sum + (u.assets[rewardUnit] ?? 0n),
      0n,
    );
  const walletBefore = await balance();
  const built = await buildRecoverSurplus(
    lucid,
    config,
    scripts,
    before,
    config.rewardAsset,
    30_000_000n,
    now(),
  );
  const hash = await send(built.completed);
  const after = await read();
  if (
    await balance() !== walletBefore + 30_000_000n ||
    after.assets[rewardUnit] !== before.assets[rewardUnit] - 30_000_000n ||
    after.assets[stakeUnit] !== before.assets[stakeUnit]
  ) throw new Error("Recovery payout or principal mismatch.");
  const pool = decodePoolDatum(after.datum!);
  if (
    pool.rewardRate !== notified.pool.rewardRate ||
    pool.periodFinishSeconds !== notified.pool.periodFinishSeconds ||
    pool.totalStaked !== 100_000_000n
  ) throw new Error("Recovery changed schedule/principal.");
  const directory = await Deno.makeTempDir({
    dir: "/private/tmp",
    prefix: "recover-journal-",
  });
  const context = {
    lucid,
    owner: config.manager,
    asset: config.rewardAsset,
    amount: built.amount,
    path: `${directory}/state.json`,
    deploymentPath: "unused",
    blueprintPath: "plutus.json",
  };
  const session: RecoverySession = {
    context,
    config,
    scripts,
    poolUnit,
    state: {
      owner: config.manager,
      poolPolicyId: scripts.poolPolicyId,
      unit: rewardUnit,
      amount: built.amount.toString(),
      txHash: hash,
      confirmed: false,
      expectedDatum: built.datum,
      remainingBalance: built.remainingBalance.toString(),
    },
  };
  try {
    await refreshRecoveryState(session);
    const saved = JSON.parse(await Deno.readTextFile(context.path));
    if (!saved.confirmed) throw new Error("Recovery journal not confirmed.");
    await ensureRecoverySubmitted(session);
    if ((await read()).txHash !== hash) {
      throw new Error("Rerun recovered twice.");
    }
  } finally {
    await Deno.remove(directory, { recursive: true });
  }
  // Expiry does not turn the stakers' unpaid rewards into manager surplus.
  emulator.awaitSlot(
    Number(pool.periodFinishSeconds - BigInt(now() / 1000)) + 1,
  );
  let rejected = false;
  try {
    await buildRecoverSurplus(
      lucid,
      config,
      scripts,
      await read(),
      config.rewardAsset,
      1_000_000n,
      now(),
    );
  } catch (error) {
    if (!(error instanceof Error) || !error.message.includes("surplus")) {
      throw error;
    }
    rejected = true;
  }
  if (!rejected) {
    throw new Error("Recovery consumed accrued rewards after expiry.");
  }
  const position =
    (await lucid.utxosAtWithUnit(scripts.poolAddress, deposit.positionUnit))[0];
  const claim = await getReward(
    lucid,
    config,
    scripts,
    await read(),
    position,
    now(),
  );
  if (claim.rewardAmount <= 0n) {
    throw new Error("Recovery lost earned rewards.");
  }
  await send(claim.completed);
});

Deno.test("recovery rejects principal, ADA, identity tokens and unauthorized wallets", async () => {
  const { lucid, emulator, config, scripts, poolUtxo } =
    await testInitializePool(false);
  const now = () => Math.floor(emulator.now() / 1000) * 1000;
  const deposited = await stake(
    lucid,
    config,
    scripts,
    poolUtxo,
    10_000_000n,
    now(),
  );
  await (await deposited.completed.sign.withWallet().complete()).submit();
  emulator.awaitBlock(1);
  const poolUnit = toUnit(scripts.poolPolicyId, fromText("POOL"));
  const [pool] = await lucid.utxosAtWithUnit(scripts.poolAddress, poolUnit);
  for (
    const asset of [config.stakingAsset, { policyId: "", tokenNameHex: "" }, {
      policyId: scripts.poolPolicyId,
      tokenNameHex: fromText("POOL"),
    }]
  ) {
    let rejected = false;
    try {
      await buildRecoverSurplus(lucid, config, scripts, pool, asset, 1n, now());
    } catch {
      rejected = true;
    }
    if (!rejected) throw new Error("Protected asset was recoverable.");
  }
  lucid.selectWallet.fromSeed(generateEmulatorAccount({}).seedPhrase);
  let rejected = false;
  try {
    await buildRecoverSurplus(
      lucid,
      config,
      scripts,
      pool,
      config.rewardAsset,
      1n,
      now(),
    );
  } catch (error) {
    if (!(error instanceof Error) || !error.message.includes("manager")) {
      throw error;
    }
    rejected = true;
  }
  if (!rejected) throw new Error("Unauthorized recovery accepted.");
  if (parseRecoverySettings("ab".repeat(28), "", "1").amount !== 1n) {
    throw new Error("Empty native-token name should be supported.");
  }
  for (const amount of [undefined, "0", "-1", "1.5"]) {
    rejected = false;
    try {
      parseRecoverySettings("ab".repeat(28), "41", amount);
    } catch {
      rejected = true;
    }
    if (!rejected) throw new Error("Invalid amount accepted.");
  }
});
