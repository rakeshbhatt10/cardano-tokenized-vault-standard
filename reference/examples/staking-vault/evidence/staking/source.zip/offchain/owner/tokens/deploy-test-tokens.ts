import { writeJsonAtomic } from "../../shared/journal.ts";
import { confirmTransaction } from "../../shared/transactions.ts";
import {
  applyParamsToScript,
  Blockfrost,
  Constr,
  Data,
  fromText,
  getAddressDetails,
  Lucid,
  type MintingPolicy,
  mintingPolicyToId,
  toUnit,
} from "npm:@lucid-evolution/lucid@0.4.29";

function required(name: string): string {
  const value = Deno.env.get(name)?.trim();
  if (!value) throw new Error(`Set ${name}.`);
  return value;
}
function positive(name: string, fallback: string): bigint {
  const value = Deno.env.get(name) ?? fallback;
  if (!/^[1-9][0-9]*$/.test(value)) {
    throw new Error(`${name} must be a positive integer in base units.`);
  }
  return BigInt(value);
}
function balance(
  utxos: { assets: Record<string, bigint> }[],
  unit: string,
): bigint {
  return utxos.reduce((sum, utxo) => sum + (utxo.assets[unit] ?? 0n), 0n);
}
function display(value: bigint, decimals: number): string {
  const digits = value.toString().padStart(decimals + 1, "0");
  return decimals === 0
    ? digits
    : `${digits.slice(0, -decimals)}.${digits.slice(-decimals)}`;
}

/** Fail closed on authentication, rate-limit, network, and malformed responses. */
export async function assetExists(
  baseUrl: string,
  apiKey: string,
  unit: string,
): Promise<boolean> {
  const response = await fetch(`${baseUrl}/assets/${unit}`, {
    headers: { project_id: apiKey },
    signal: AbortSignal.timeout(30_000),
  });
  if (response.status === 404) return false;
  if (!response.ok) {
    throw new Error(
      `Asset lookup failed (${response.status}); refusing to assume absence.`,
    );
  }
  const asset = await response.json();
  if (asset.asset !== unit) {
    throw new Error("Unexpected Blockfrost asset response.");
  }
  return true; // Includes previously issued assets whose current supply is zero.
}

// Cardano policies are attached to mint transactions; no separate deployment is needed.
export async function main(
  options: { tokenNames?: string[]; statePath?: string } = {},
) {
  const network = Deno.env.get("NETWORK") ?? "Preview";
  if (network !== "Preview" && network !== "Preprod" && network !== "Mainnet") {
    throw new Error("NETWORK must be Mainnet, Preview or Preprod.");
  }
  const apiKey = required("BLOCKFROST_API_KEY");
  const baseUrl =
    `https://cardano-${network.toLowerCase()}.blockfrost.io/api/v0`;
  const recipient = required("RECIPIENT_ADDRESS");
  const recipientDetails = getAddressDetails(recipient);
  if (
    recipientDetails.networkId !== (network === "Mainnet" ? 1 : 0) ||
    recipientDetails.paymentCredential?.type !== "Key"
  ) {
    throw new Error(
      `RECIPIENT_ADDRESS must be a ${network} wallet payment address.`,
    );
  }
  const mintAmount = positive("MINT_AMOUNT", "1000000000");
  const transferAmount = positive("TRANSFER_AMOUNT", "100000000");
  const decimals = Number(Deno.env.get("TOKEN_DECIMALS") ?? "6");
  if (!Number.isInteger(decimals) || decimals < 0 || decimals > 18) {
    throw new Error("TOKEN_DECIMALS must be an integer from 0 to 18.");
  }
  const blueprintPath = Deno.env.get("BLUEPRINT_PATH") ?? "plutus.json";
  const blueprint = JSON.parse(await Deno.readTextFile(blueprintPath));
  const validator = blueprint.validators?.find((item: { title: string }) =>
    item.title === "token.token.mint"
  );
  if (
    !validator || blueprint.preamble?.plutusVersion !== "v3" ||
    validator.parameters?.length !== 2
  ) {
    throw new Error(
      "Build the current token.token.mint Plutus V3 validator with owner and token_name parameters first.",
    );
  }
  const lucid = await Lucid(new Blockfrost(baseUrl, apiKey), network);
  const mnemonic = Deno.env.get("OWNER_MNEMONIC")?.trim();
  const privateKeyFile = Deno.env.get("OWNER_PRIVATE_KEY_FILE")?.trim();
  if (mnemonic && privateKeyFile) {
    throw new Error("Set only OWNER_MNEMONIC or OWNER_PRIVATE_KEY_FILE.");
  }
  if (mnemonic) {
    lucid.selectWallet.fromSeed(mnemonic);
  } else {
    const privateKey =
      (await Deno.readTextFile(required("OWNER_PRIVATE_KEY_FILE"))).trim();
    lucid.selectWallet.fromPrivateKey(privateKey);
  }
  const ownerAddress = await lucid.wallet().address();
  const credential = getAddressDetails(ownerAddress).paymentCredential;
  if (credential?.type !== "Key") {
    throw new Error("Owner must use a payment verification key.");
  }
  if (ownerAddress === recipient) {
    throw new Error("Recipient must differ from the owner.");
  }
  const owner = credential.hash;
  const tokens = (options.tokenNames ?? ["Test1", "Test2"]).map((name) => {
    const tokenName = fromText(name);
    const policy: MintingPolicy = {
      type: "PlutusV3",
      script: applyParamsToScript(validator.compiledCode, [owner, tokenName]),
    };
    const policyId = mintingPolicyToId(policy);
    return { name, policy, policyId, unit: toUnit(policyId, tokenName) };
  });

  const statePath = options.statePath ?? Deno.env.get("STATE_PATH") ??
    "offchain/test-tokens-state.json";
  // Prevent concurrent local runs. Remove a stale lock only after checking chain/state.
  const lock = await Deno.open(`${statePath}.lock`, {
    write: true,
    createNew: true,
  });
  try {
    type State = {
      identity: string;
      mintTx?: string;
      transferTx?: string;
      before?: Record<string, string>;
    };
    const identity = JSON.stringify({
      network,
      owner,
      recipient,
      units: tokens.map((t) => t.unit),
      mintAmount: String(mintAmount),
      transferAmount: String(transferAmount),
      decimals,
    });
    let state: State = { identity };
    try {
      state = JSON.parse(await Deno.readTextFile(statePath));
      if (state.identity !== identity) {
        throw new Error(
          "State belongs to a different configuration. Use a separate STATE_PATH.",
        );
      }
    } catch (error) {
      if (!(error instanceof Deno.errors.NotFound)) throw error;
    }
    const save = () => writeJsonAtomic(statePath, state);
    const confirmed = (hash: string) => confirmTransaction(lucid, hash);

    if (state.mintTx) await confirmed(state.mintTx);
    if (!state.transferTx) {
      const existence = await Promise.all(
        tokens.map((t) => assetExists(baseUrl, apiKey, t.unit)),
      );
      const missing = tokens.filter((_, index) => !existence[index]);
      tokens.forEach((t, index) =>
        console.log(
          `${t.name}: ${t.policyId} (${
            existence[index] ? "exists; skipping mint" : "not found"
          })`,
        )
      );
      if (missing.length && !state.mintTx) {
        if (transferAmount > mintAmount) {
          throw new Error("TRANSFER_AMOUNT exceeds the amount to mint.");
        }
        // Preflight existing balances before submitting either token's initial mint.
        const walletUtxos = await lucid.wallet().getUtxos();
        for (const token of tokens.filter((_, index) => existence[index])) {
          if (balance(walletUtxos, token.unit) < transferAmount) {
            throw new Error(
              `Insufficient existing ${token.name}; mint skipped by request.`,
            );
          }
        }
        let tx = lucid.newTx().addSignerKey(owner);
        for (const token of missing) {
          tx = tx.mintAssets(
            { [token.unit]: mintAmount },
            Data.to(new Constr(0, [])),
          )
            .attach.MintingPolicy(token.policy);
        }
        // Unallocated minted assets go to the owner's wallet change output.
        const completed = await tx.complete();
        const signed = await completed.sign.withWallet().complete();
        // Persist the deterministic hash before submission, including ambiguous failures.
        state.mintTx = signed.toHash();
        await save();
        await signed.submit();
        console.log("Mint transaction:", state.mintTx);
        await confirmed(state.mintTx);
      } else if (missing.length) {
        throw new Error(
          "Saved mint confirmed but asset indexing has not caught up. Retry later.",
        );
      }
      const walletUtxos = await lucid.wallet().getUtxos();
      for (const token of tokens) {
        if (balance(walletUtxos, token.unit) < transferAmount) {
          throw new Error(
            `Insufficient ${token.name} in owner wallet; retry after indexing catches up.`,
          );
        }
      }
      const before = await lucid.utxosAt(recipient);
      state.before = Object.fromEntries(
        tokens.map((t) => [t.unit, balance(before, t.unit).toString()]),
      );
      const assets = Object.fromEntries(
        tokens.map((t) => [t.unit, transferAmount]),
      );
      const completed = await lucid.newTx().pay.ToAddress(recipient, assets)
        .complete();
      const signed = await completed.sign.withWallet().complete();
      state.transferTx = signed.toHash();
      await save();
      await signed.submit();
      console.log("Transfer transaction:", state.transferTx);
    }
    await confirmed(state.transferTx);
    // Confirmed transactions and address indexes can become visible at different times.
    for (let attempt = 0; attempt < 12; attempt++) {
      const utxos = await lucid.utxosAt(recipient);
      if (
        tokens.every((t) =>
          balance(utxos, t.unit) >=
            BigInt(state.before![t.unit]) + transferAmount
        )
      ) {
        for (const token of tokens) {
          const amount = balance(utxos, token.unit);
          console.log(
            `${token.name}: recipient balance ${
              display(amount, decimals)
            } (${amount} base units)`,
          );
        }
        console.log(
          "Verified recipient balances. Transfer:",
          state.transferTx,
        );
        return;
      }
      await new Promise((resolve) => setTimeout(resolve, 5000));
    }
    throw new Error(
      "Recipient balances have not reached expected values. Retry with the same state; no second transfer will be sent. Concurrent recipient spending may affect balance verification.",
    );
  } finally {
    lock.close();
    await Deno.remove(`${statePath}.lock`);
  }
}

if (import.meta.main) await main();
