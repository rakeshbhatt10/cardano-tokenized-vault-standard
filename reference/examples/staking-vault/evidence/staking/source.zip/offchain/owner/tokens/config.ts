/** Display metadata. Amounts on-chain remain integers in smallest units. */
export type TokenMetadata = {
  name: string;
  symbol: string;
  decimals: number;
  description: string;
  website?: string;
  logo?: string;
};

export type TokenConfig = {
  /** UTF-8 text to encode as the validator's token_name (at most 32 bytes). */
  tokenName: string;
  metadata: TokenMetadata;
};

/** Example values only. Replace before creating a token. */
export const tokenConfig: TokenConfig = {
  tokenName: "ExampleToken",
  metadata: {
    name: "Example Token",
    symbol: "EXAMPLE",
    decimals: 6,
    description: "Example fungible token on Cardano.",
    // website: "https://your-project.example",
    // logo: "ipfs://your-logo-content-id",
  },
};
