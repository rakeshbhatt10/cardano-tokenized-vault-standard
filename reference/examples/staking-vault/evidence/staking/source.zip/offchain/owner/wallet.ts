import { loadSelectedPool } from "../shared/pool-registry.ts";
import {
  Blockfrost,
  getAddressDetails,
  Lucid,
  type LucidEvolution,
} from "npm:@lucid-evolution/lucid@0.4.29";

/** Select the configured owner signing method without exposing credential values. */
export async function selectOwnerWallet(
  lucid: LucidEvolution,
): Promise<string> {
  const mnemonic = Deno.env.get("OWNER_MNEMONIC")?.trim();
  const keyFile = Deno.env.get("OWNER_PRIVATE_KEY_FILE")?.trim();
  if (mnemonic && keyFile) {
    throw new Error("Choose only one owner signing method.");
  }
  if (mnemonic) lucid.selectWallet.fromSeed(mnemonic);
  else {
    if (!keyFile) {
      throw new Error("Set OWNER_PRIVATE_KEY_FILE or OWNER_MNEMONIC.");
    }
    lucid.selectWallet.fromPrivateKey(
      (await Deno.readTextFile(keyFile)).trim(),
    );
  }
  const credential =
    getAddressDetails(await lucid.wallet().address()).paymentCredential;
  if (credential?.type !== "Key") {
    throw new Error("Expected owner payment key.");
  }
  return credential.hash;
}

/** Connect the Mainnet owner wallet and locate the existing pool manifest. */
export async function loadOwnerPoolContext() {
  if ((Deno.env.get("NETWORK") ?? "Mainnet") !== "Mainnet") {
    throw new Error("Existing Test1/Test2 require Mainnet.");
  }
  const selected = await loadSelectedPool();
  const apiKey = Deno.env.get("BLOCKFROST_API_KEY")?.trim();
  if (!apiKey) throw new Error("Set BLOCKFROST_API_KEY.");
  const lucid = await Lucid(
    new Blockfrost("https://cardano-mainnet.blockfrost.io/api/v0", apiKey),
    "Mainnet",
  );
  const owner = await selectOwnerWallet(lucid);
  return {
    lucid,
    owner,
    deploymentPath: selected?.statePath ?? Deno.env.get("STAKING_STATE_PATH") ??
      "offchain/single-staking-state.json",
    blueprintPath: selected?.blueprintPath ?? Deno.env.get("BLUEPRINT_PATH") ??
      "plutus.json",
  };
}
