import {
  type PoolDeployment,
  readDeployment,
  saveDeployment,
} from "./journal.ts";
import { withStateLock } from "../../shared/journal.ts";

Deno.test("deployment journal restores precision and preserves resume configuration", async () => {
  const directory = await Deno.makeTempDir({
    dir: "/private/tmp",
    prefix: "staking-journal-",
  });
  const path = `${directory}/state.json`;
  try {
    const state: PoolDeployment = {
      network: "Mainnet",
      identity: "original-settings",
      config: {
        bootstrapRef: { txHash: "ab".repeat(32), outputIndex: 3n },
        manager: "11".repeat(28),
        rewardsDistributor: "11".repeat(28),
        stakingAsset: { policyId: "22".repeat(28), tokenNameHex: "41" },
        rewardAsset: { policyId: "33".repeat(28), tokenNameHex: "42" },
        initiallyLocked: false,
      },
      poolPolicyId: "44".repeat(28),
      poolAddress: "test-address",
      poolTokenName: "POOL",
      poolTokenNameHex: "504f4f4c",
      poolUnit: "44".repeat(28) + "504f4f4c",
      mintTx: "aa".repeat(32),
      notifyTx: "bb".repeat(32),
      poolUtxo: {
        txHash: "bb".repeat(32),
        outputIndex: 0,
        address: "test-address",
        assets: { lovelace: 9007199254740993n },
      },
    };
    if (await readDeployment(path, state.identity) !== undefined) {
      throw new Error("Missing journal must start a fresh deployment.");
    }
    await saveDeployment(path, state);
    const restored = await readDeployment(path, state.identity);
    if (
      restored?.config.bootstrapRef.outputIndex !== 3n ||
      restored.poolUtxo?.assets.lovelace !== 9007199254740993n ||
      restored.notifyTx !== state.notifyTx
    ) throw new Error("Resume data lost precision or transaction history.");
    let rejected = false;
    try {
      await readDeployment(path, "different-settings");
    } catch {
      rejected = true;
    }
    if (!rejected) {
      throw new Error("Mismatched settings must not resume this pool.");
    }
  } finally {
    await Deno.remove(directory, { recursive: true });
  }
});

Deno.test("deployment lock excludes concurrent work and releases after failure", async () => {
  const directory = await Deno.makeTempDir({
    dir: "/private/tmp",
    prefix: "staking-lock-",
  });
  const path = `${directory}/state.json`;
  try {
    let concurrentRejected = false;
    try {
      await withStateLock(path, async () => {
        try {
          await withStateLock(path, async () => {});
        } catch (error) {
          if (!(error instanceof Deno.errors.AlreadyExists)) throw error;
          concurrentRejected = true;
        }
        throw new Error("simulated transaction failure");
      });
    } catch (error) {
      if (
        !(error instanceof Error) ||
        error.message !== "simulated transaction failure"
      ) throw error;
    }
    if (!concurrentRejected) {
      throw new Error("Concurrent deployment was allowed.");
    }
    const result = await withStateLock(
      path,
      () => Promise.resolve("retry allowed"),
    );
    if (result !== "retry allowed") {
      throw new Error("Failure left the lock held.");
    }
  } finally {
    await Deno.remove(directory, { recursive: true });
  }
});
