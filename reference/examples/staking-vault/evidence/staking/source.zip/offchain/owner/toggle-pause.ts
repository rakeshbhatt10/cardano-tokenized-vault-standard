/** Set the desired pause state using the manager's owner wallet. */
import { createPoolToggleFlow } from "./flows/pool-toggle.ts";
import { withStateLock } from "../shared/journal.ts";
export { togglePause as buildTogglePause } from "./builders/pool-toggle.ts";

const flow = createPoolToggleFlow("pause");
export const parsePauseState = flow.parseDesired;
export const loadPauseContext = flow.loadContext;
export const preparePause = flow.prepare;
export const ensurePauseSubmitted = flow.ensureSubmitted;
export const refreshPauseState = flow.refresh;
export type PauseContext = Awaited<ReturnType<typeof loadPauseContext>>;
export type PauseSession = Awaited<ReturnType<typeof preparePause>>;

export async function main() {
  const context = await loadPauseContext();
  await withStateLock(context.deploymentPath, async () => {
    const session = await preparePause(context);
    await ensurePauseSubmitted(session);
    await refreshPauseState(session);
  });
}

if (import.meta.main) await main();
