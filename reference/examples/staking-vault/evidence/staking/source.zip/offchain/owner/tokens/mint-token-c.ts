/** Issue tokenC once to the owner; never transfers or mints Test1/Test2. */
import {
  applyParamsToScript,
  Constr,
  Data,
  fromText,
  type MintingPolicy,
  mintingPolicyToId,
  toUnit,
} from "npm:@lucid-evolution/lucid@0.4.29";
import { loadOwnerPoolContext } from "../wallet.ts";
import { loadSelectedPool } from "../../shared/pool-registry.ts";
import { confirmTransaction } from "../../shared/transactions.ts";
import { withStateLock, writeJsonAtomic } from "../../shared/journal.ts";

export async function main() {
  const selected = await loadSelectedPool();
  if (selected?.id !== "tokenc-test2") {
    throw new Error("Select POOL_ID=tokenc-test2.");
  }
  const { lucid, owner, blueprintPath } = await loadOwnerPoolContext();
  const blueprint = JSON.parse(await Deno.readTextFile(blueprintPath));
  const validator = blueprint.validators.find((v: { title: string }) =>
    v.title === "token.token.mint"
  );
  if (
    !validator || validator.parameters?.length !== 2 ||
    blueprint.preamble.plutusVersion !== "v3"
  ) throw new Error("Expected owner/token-name minting policy.");
  const policy: MintingPolicy = {
    type: "PlutusV3",
    script: applyParamsToScript(validator.compiledCode, [
      owner,
      fromText("tokenC"),
    ]),
  };
  const policyId = mintingPolicyToId(policy);
  const unit = toUnit(policyId, fromText("tokenC"));
  if (
    policyId !== selected.stakingAsset.policyId ||
    fromText("tokenC") !== selected.stakingAsset.tokenNameHex
  ) throw new Error("Derived tokenC identity differs from registry.");
  const path = selected.tokenManifestPath;
  await withStateLock(path, async () => {
    let state: {
      policyId: string;
      unit: string;
      mintTx: string;
      confirmed: boolean;
      amountBaseUnits: string;
      ownerAddress: string;
      owner: string;
      decimals: number;
      tokenName: string;
      tokenNameHex: string;
    } | undefined;
    try {
      state = JSON.parse(await Deno.readTextFile(path));
    } catch (error) {
      if (!(error instanceof Deno.errors.NotFound)) throw error;
    }
    if (state && (state.policyId !== policyId || state.owner !== owner)) {
      throw new Error("tokenC journal identity mismatch.");
    }
    if (!state) {
      const response = await fetch(
        `https://cardano-mainnet.blockfrost.io/api/v0/assets/${unit}`,
        {
          headers: { project_id: Deno.env.get("BLOCKFROST_API_KEY")! },
          signal: AbortSignal.timeout(30000),
        },
      );
      if (response.status !== 404) {
        throw new Error(
          `Refusing initial issuance: asset lookup HTTP ${response.status}.`,
        );
      }
      const ownerAddress = await lucid.wallet().address();
      const completed = await lucid.newTx().mintAssets({
        [unit]: 1_000_000_000n,
      }, Data.to(new Constr(0, []))).attach.MintingPolicy(policy).addSignerKey(
        owner,
      ).pay.ToAddress(ownerAddress, { [unit]: 1_000_000_000n }).complete({
        setCollateral: 2_000_000n,
      });
      const signed = await completed.sign.withWallet().complete();
      state = {
        policyId,
        unit,
        mintTx: signed.toHash(),
        confirmed: false,
        amountBaseUnits: "1000000000",
        ownerAddress,
        owner,
        decimals: 6,
        tokenName: "tokenC",
        tokenNameHex: fromText("tokenC"),
      };
      await writeJsonAtomic(path, state);
      await signed.submit();
      console.log("tokenC mint submitted:", state.mintTx);
    }
    if (!state.confirmed) {
      await confirmTransaction(lucid, state.mintTx);
      state.confirmed = true;
      await writeJsonAtomic(path, state);
    }
    console.log("tokenC mint confirmed:", state.mintTx, "Policy:", policyId);
  });
}
if (import.meta.main) await main();
