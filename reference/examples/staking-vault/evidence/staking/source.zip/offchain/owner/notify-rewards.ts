/** Phase 2 only: fund/start rewards on the previously initialized pool. */
import { withStateLock } from "../shared/journal.ts";
import { loadDeploymentContext } from "./setup/settings.ts";
import { readDeployment } from "./setup/journal.ts";
import {
  ensureRewardsNotified,
  prepareDeployment,
  refreshPoolState,
} from "./setup/pool.ts";

export async function main() {
  const context = await loadDeploymentContext();
  await withStateLock(context.path, async () => {
    const saved = await readDeployment(context.path, context.identity);
    if (!saved?.mintTx) {
      throw new Error(
        "Run initialize-pool.ts successfully before notifying rewards.",
      );
    }
    const session = await prepareDeployment(context);
    await ensureRewardsNotified(session);
    await refreshPoolState(session);
  });
}
if (import.meta.main) await main();
