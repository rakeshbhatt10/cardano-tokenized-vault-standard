import { loadSelectedPool, poolAssets } from "../../shared/pool-registry.ts";
import { selectOwnerWallet } from "../wallet.ts";
import { Blockfrost, Lucid } from "npm:@lucid-evolution/lucid@0.4.29";
import {
  INITIAL_REWARD_AMOUNT,
  INITIAL_REWARD_DURATION,
} from "../../shared/schedule.ts";
import { loadDeployedTestTokens } from "../../shared/deployed-test-tokens.ts";
import { stringify } from "../../shared/journal.ts";

function required(name: string) {
  const value = Deno.env.get(name)?.trim();
  if (!value) throw new Error(`Set ${name}.`);
  return value;
}

/** Validate environment and connect the owner wallet; submits no transactions. */
export async function loadDeploymentContext() {
  // Validate optional staker settings before submitting any owner transactions.
  const runStake = Deno.args.includes("--stake-after-notify") ||
    Deno.env.get("START_STAKING_AFTER_NOTIFY") === "true";
  if (runStake) {
    required("STAKER_MNEMONIC");
    required("STAKER_ADDRESS");
  }
  // Read the previously minted identities; reject other networks or substitute tokens.
  const selected = await loadSelectedPool();
  if (selected && !selected.deploy) {
    throw new Error("Pool is disabled for deployment.");
  }
  const tokens = selected
    ? poolAssets(selected)
    : await loadDeployedTestTokens();
  const durationSeconds = selected
    ? BigInt(selected.durationSeconds)
    : INITIAL_REWARD_DURATION;
  if ((Deno.env.get("NETWORK") ?? "Mainnet") !== tokens.network) {
    throw new Error("Existing Test1/Test2 identities require Mainnet.");
  }
  if (!selected && Deno.env.get("INITIALLY_LOCKED") === "true") {
    throw new Error("Set INITIALLY_LOCKED=false for the requested pool.");
  }
  const vaultSetting = Deno.env.get("VAULT_SUPPORTED");
  if (
    vaultSetting !== undefined && vaultSetting !== "true" &&
    vaultSetting !== "false"
  ) {
    throw new Error("VAULT_SUPPORTED must be true or false.");
  }
  const vaultSupported = selected?.vaultSupported ?? (vaultSetting === "true");
  if (vaultSupported && selected?.initiallyLocked) {
    throw new Error(
      "Vault-supported pools cannot start with withdrawals locked.",
    );
  }
  const factoryPolicy = selected && Object.hasOwn(selected, "factoryPolicy")
    ? selected.factoryPolicy!
    : Deno.env.get("FACTORY_POLICY_ID")?.trim() ?? null;
  if (
    vaultSupported
      ? !/^[0-9a-f]{56}$/.test(factoryPolicy ?? "")
      : factoryPolicy !== null
  ) {
    throw new Error(
      "Vault-supported pools require an explicit 28-byte FACTORY_POLICY_ID; wallet-only pools require no factory policy.",
    );
  }
  const blueprintPath = selected?.blueprintPath ??
    Deno.env.get("BLUEPRINT_PATH") ?? "plutus.json";
  const blueprint = JSON.parse(await Deno.readTextFile(blueprintPath));
  const validatorParameterCount = blueprint.validators?.find((
    v: { title: string },
  ) => v.title === "single_staking.single_staking.mint")?.parameters?.length;
  if (![6, 7, 8].includes(validatorParameterCount)) {
    throw new Error("Unsupported staking initialization blueprint.");
  }
  if (
    (validatorParameterCount === 6 && vaultSupported) ||
    (validatorParameterCount < 8 && factoryPolicy !== null)
  ) {
    throw new Error(
      "Legacy pool blueprint cannot express the requested vault/factory settings.",
    );
  }
  // This is the TOTAL seven-day budget in base units, not a daily amount.
  // Default: 70 Test2 (six decimals); integer per-second division rounds emissions down.
  const rewardText = selected?.rewardAmountBaseUnits ??
    Deno.env.get("STAKING_REWARD_AMOUNT") ??
    INITIAL_REWARD_AMOUNT.toString();
  if (!/^[1-9][0-9]*$/.test(rewardText)) {
    throw new Error("STAKING_REWARD_AMOUNT must be positive base units.");
  }
  const reward = BigInt(rewardText);
  if (reward < durationSeconds) {
    throw new Error("Reward budget rounds to a zero per-second rate.");
  }
  // The owner wallet supplies pool ADA, fees and the actual Test2 reward budget.
  // The optional staking step switches to STAKER_MNEMONIC in stake-all.ts.
  const apiKey = required("BLOCKFROST_API_KEY");
  const baseUrl = "https://cardano-mainnet.blockfrost.io/api/v0";
  const lucid = await Lucid(new Blockfrost(baseUrl, apiKey), "Mainnet");
  const manager = await selectOwnerWallet(lucid);
  // Aiken allows separate roles; this CLI signs both steps using the same owner wallet.
  const distributor = Deno.env.get("REWARDS_DISTRIBUTOR_KEY_HASH")?.trim() ||
    manager;
  if (distributor !== manager) {
    throw new Error(
      "This CLI requires the manager to also sign reward notification.",
    );
  }
  // Persist settings so a retry cannot silently initialize a different pool/schedule.
  const identity = stringify({
    network: tokens.network,
    manager,
    distributor,
    stakingAsset: tokens.stakingAsset,
    rewardAsset: tokens.rewardAsset,
    initiallyLocked: selected?.initiallyLocked ?? false,
    ...(validatorParameterCount >= 7 ? { vaultSupported } : {}),
    ...(validatorParameterCount === 8 ? { factoryPolicy } : {}),
    reward,
    duration: durationSeconds,
  });
  const path = selected?.statePath ?? Deno.env.get("STAKING_STATE_PATH") ??
    "offchain/single-staking-state.json";
  return {
    lucid,
    tokens,
    reward,
    durationSeconds,
    initiallyLocked: selected?.initiallyLocked ?? false,
    vaultSupported,
    factoryPolicy,
    apiKey,
    baseUrl,
    manager,
    distributor,
    identity,
    path,
    runStake,
    poolName: selected?.name ??
      (Deno.env.get("POOL_NAME")?.trim() || "Staking pool"),
    blueprintPath,
    validatorParameterCount,
  };
}
export type DeploymentContext = Awaited<
  ReturnType<typeof loadDeploymentContext>
>;
