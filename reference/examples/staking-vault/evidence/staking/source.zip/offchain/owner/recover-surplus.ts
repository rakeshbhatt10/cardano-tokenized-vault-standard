import { writeJsonAtomic } from "../shared/journal.ts";
/** One journal per intentional manager surplus recovery; never changes the emission schedule. */
import { fromText, toUnit } from "npm:@lucid-evolution/lucid@0.4.29";
import { loadOwnerPoolContext } from "./wallet.ts";
import { loadPoolDeployment } from "../shared/pool-deployment.ts";
import { confirmTransaction, findStateUtxo } from "../shared/transactions.ts";
import { withStateLock } from "../shared/journal.ts";
import { recoverSurplus } from "./builders/recover-surplus.ts";
export { recoverSurplus as buildRecoverSurplus } from "./builders/recover-surplus.ts";

type RecoveryState = {
  owner: string;
  poolPolicyId: string;
  unit: string;
  amount: string;
  txHash: string;
  confirmed: boolean;
  expectedDatum: string;
  remainingBalance: string;
};

export function parseRecoverySettings(
  policyId: string | undefined,
  tokenNameHex: string | undefined,
  amount: string | undefined,
) {
  if (
    !policyId || !/^[0-9a-f]{56}$/.test(policyId) ||
    tokenNameHex === undefined || !/^(?:[0-9a-f]{2}){0,32}$/.test(tokenNameHex)
  ) {
    throw new Error(
      "Set RECOVER_POLICY_ID and RECOVER_TOKEN_NAME_HEX for a native token; ADA cannot be recovered.",
    );
  }
  if (!amount || !/^[1-9][0-9]*$/.test(amount)) {
    throw new Error("Set RECOVER_AMOUNT to positive integer base units.");
  }
  return { asset: { policyId, tokenNameHex }, amount: BigInt(amount) };
}

export async function loadRecoveryContext() {
  const settings = parseRecoverySettings(
    Deno.env.get("RECOVER_POLICY_ID"),
    Deno.env.get("RECOVER_TOKEN_NAME_HEX"),
    Deno.env.get("RECOVER_AMOUNT"),
  );
  const owner = await loadOwnerPoolContext();
  return {
    ...owner,
    ...settings,
    path: Deno.env.get("RECOVER_STATE_PATH") ??
      `${owner.deploymentPath}.recover-surplus.json`,
  };
}
export type RecoveryContext = Awaited<ReturnType<typeof loadRecoveryContext>>;

export async function prepareRecovery(context: RecoveryContext) {
  const { config, scripts } = await loadPoolDeployment(
    context.deploymentPath,
    "Mainnet",
    context.blueprintPath,
  );
  if (context.owner !== config.manager) {
    throw new Error("OWNER wallet must be the pool manager.");
  }
  if (context.asset.policyId === scripts.poolPolicyId) {
    throw new Error("Pool identity tokens cannot be recovered.");
  }
  const unit = toUnit(context.asset.policyId, context.asset.tokenNameHex);
  let state: RecoveryState | undefined;
  try {
    state = JSON.parse(await Deno.readTextFile(context.path));
  } catch (error) {
    if (!(error instanceof Deno.errors.NotFound)) throw error;
  }
  if (
    state &&
    (state.owner !== context.owner ||
      state.poolPolicyId !== scripts.poolPolicyId || state.unit !== unit ||
      state.amount !== context.amount.toString())
  ) {
    throw new Error(
      "Recovery journal differs; resume original settings or choose a new RECOVER_STATE_PATH.",
    );
  }
  return {
    context,
    config,
    scripts,
    state,
    poolUnit: toUnit(scripts.poolPolicyId, fromText("POOL")),
  };
}
export type RecoverySession = Awaited<ReturnType<typeof prepareRecovery>>;

async function saveRecoveryState(session: RecoverySession) {
  await writeJsonAtomic(session.context.path, session.state);
}

export async function ensureRecoverySubmitted(session: RecoverySession) {
  const { context, config, scripts } = session;
  if (session.state) {
    if (!session.state.confirmed) {
      await confirmTransaction(context.lucid, session.state.txHash);
    }
    return;
  }
  const pool = await findStateUtxo(
    context.lucid,
    scripts.poolAddress,
    session.poolUnit,
  );
  const built = await recoverSurplus(
    context.lucid,
    config,
    scripts,
    pool,
    context.asset,
    context.amount,
    Math.floor(Date.now() / 1000) * 1000 - 5000,
  );
  const signed = await built.completed.sign.withWallet().complete();
  session.state = {
    owner: context.owner,
    poolPolicyId: scripts.poolPolicyId,
    unit: built.unit,
    amount: context.amount.toString(),
    txHash: signed.toHash(),
    confirmed: false,
    expectedDatum: built.datum,
    remainingBalance: built.remainingBalance.toString(),
  };
  await saveRecoveryState(session);
  await signed.submit();
  console.log("RecoverSurplus transaction:", session.state.txHash);
  await confirmTransaction(context.lucid, session.state.txHash);
}

export async function refreshRecoveryState(session: RecoverySession) {
  const { context, scripts, state } = session;
  if (!state) throw new Error("Recovery transaction missing.");
  const pool = await findStateUtxo(
    context.lucid,
    scripts.poolAddress,
    session.poolUnit,
  );
  if (
    pool.txHash === state.txHash &&
    (pool.datum !== state.expectedDatum ||
      (pool.assets[state.unit] ?? 0n).toString() !== state.remainingBalance)
  ) {
    throw new Error(
      "Recovery output does not match the submitted transaction.",
    );
  }
  // Confirmation authenticates the recovery; a subsequent valid pool transition may exist.
  state.confirmed = true;
  await saveRecoveryState(session);
  console.log("Confirmed recovery:", state.txHash, "Base units:", state.amount);
}

export async function main() {
  const context = await loadRecoveryContext();
  await withStateLock(context.deploymentPath, async () => {
    const session = await prepareRecovery(context);
    await ensureRecoverySubmitted(session);
    await refreshRecoveryState(session);
  });
}
if (import.meta.main) await main();
