import { writeJsonAtomic } from "../shared/journal.ts";
/** Add Test2 reserves without changing the pool's reward schedule. */
import { fromText, toUnit } from "npm:@lucid-evolution/lucid@0.4.29";
import { loadOwnerPoolContext } from "./wallet.ts";
import { loadPoolDeployment } from "../shared/pool-deployment.ts";
import { confirmTransaction, findStateUtxo } from "../shared/transactions.ts";
import { withStateLock } from "../shared/journal.ts";
import { fundRewards } from "./builders/fund-rewards.ts";
export { fundRewards as buildFundRewards } from "./builders/fund-rewards.ts";

type FundingState = {
  owner: string;
  poolPolicyId: string;
  amount: string;
  txHash: string;
  expectedDatum: string;
  expectedRewardBalance: string;
  confirmed: boolean;
  poolRef?: { txHash: string; outputIndex: number };
};

export function parseFundingAmount(value: string | undefined): bigint {
  if (!value || !/^[1-9][0-9]*$/.test(value)) {
    throw new Error(
      "Set FUND_REWARDS_AMOUNT to positive integer Test2 base units.",
    );
  }
  return BigInt(value);
}

/** Funding uses the owner wallet, which must match the pool's distributor parameter. */
export async function loadFundingContext() {
  const amount = parseFundingAmount(Deno.env.get("FUND_REWARDS_AMOUNT"));
  const context = await loadOwnerPoolContext();
  return {
    ...context,
    amount,
    path: Deno.env.get("FUND_REWARDS_STATE_PATH") ??
      `${context.deploymentPath}.fund-rewards.json`,
  };
}
export type FundingContext = Awaited<ReturnType<typeof loadFundingContext>>;

/** Restore the existing pool; never select a new bootstrap or create a pool here. */
export async function prepareFunding(context: FundingContext) {
  const { config, scripts } = await loadPoolDeployment(
    context.deploymentPath,
    "Mainnet",
    context.blueprintPath,
  );
  if (config.rewardsDistributor !== context.owner) {
    throw new Error("OWNER wallet must be the pool rewards distributor.");
  }
  let state: FundingState | undefined;
  try {
    state = JSON.parse(await Deno.readTextFile(context.path));
  } catch (error) {
    if (!(error instanceof Deno.errors.NotFound)) throw error;
  }
  if (
    state &&
    (state.owner !== context.owner ||
      state.poolPolicyId !== scripts.poolPolicyId ||
      state.amount !== context.amount.toString())
  ) {
    throw new Error(
      "Funding journal settings differ; use original settings or a new FUND_REWARDS_STATE_PATH.",
    );
  }
  return {
    context,
    config,
    scripts,
    state,
    poolUnit: toUnit(scripts.poolPolicyId, fromText("POOL")),
  };
}
export type FundingSession = Awaited<ReturnType<typeof prepareFunding>>;

async function saveFundingState(session: FundingSession) {
  await writeJsonAtomic(session.context.path, session.state);
}

/** A journal identifies one funding operation; reruns confirm instead of adding again. */
export async function ensureFundingSubmitted(session: FundingSession) {
  const { context, config, scripts } = session;
  if (session.state) {
    if (!session.state.confirmed) {
      await confirmTransaction(context.lucid, session.state.txHash);
    }
    return;
  }
  const poolUtxo = await findStateUtxo(
    context.lucid,
    scripts.poolAddress,
    session.poolUnit,
  );
  const built = await fundRewards(
    context.lucid,
    config,
    scripts,
    poolUtxo,
    context.amount,
  );
  const signed = await built.completed.sign.withWallet().complete();
  session.state = {
    owner: context.owner,
    poolPolicyId: scripts.poolPolicyId,
    amount: context.amount.toString(),
    txHash: signed.toHash(),
    expectedDatum: built.datum,
    expectedRewardBalance: built.rewardBalance.toString(),
    confirmed: false,
  };
  await saveFundingState(session);
  await signed.submit();
  console.log("FundRewards transaction:", session.state.txHash);
  await confirmTransaction(context.lucid, session.state.txHash);
}

/** Cache current state after confirmation; later valid pool transitions may already exist. */
export async function refreshFundingState(session: FundingSession) {
  const { context, state, scripts } = session;
  if (!state) throw new Error("Funding transaction missing.");
  const pool = await findStateUtxo(
    context.lucid,
    scripts.poolAddress,
    session.poolUnit,
  );
  const rewardUnit = toUnit(
    session.config.rewardAsset.policyId,
    session.config.rewardAsset.tokenNameHex,
  );
  if (
    pool.txHash === state.txHash &&
    (pool.datum !== state.expectedDatum ||
      (pool.assets[rewardUnit] ?? 0n).toString() !==
        state.expectedRewardBalance)
  ) {
    throw new Error("Funding output differs from the expected top-up.");
  }
  if (!state.confirmed && pool.txHash !== state.txHash) {
    // Confirmation is authoritative; the authenticated pool may have advanced after funding.
    console.log(
      "Funding confirmed; current pool output belongs to a later/indexed transition.",
    );
  }
  state.confirmed = true;
  state.poolRef = { txHash: pool.txHash, outputIndex: pool.outputIndex };
  await saveFundingState(session);
  console.log(
    "Confirmed funding:",
    state.txHash,
    "Test2 base units:",
    state.amount,
  );
}

export async function main() {
  const context = await loadFundingContext();
  // Same owner lock as deployment/notification. Separate journal tracks this top-up.
  await withStateLock(context.deploymentPath, async () => {
    const session = await prepareFunding(context);
    await ensureFundingSubmitted(session);
    await refreshFundingState(session);
  });
}

if (import.meta.main) await main();
