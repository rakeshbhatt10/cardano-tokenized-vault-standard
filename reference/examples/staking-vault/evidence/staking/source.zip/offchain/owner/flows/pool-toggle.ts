import { writeJsonAtomic } from "../../shared/journal.ts";
/** Shared manager control flow: desired-state checks, journal recovery and confirmation. */
import { fromText, toUnit } from "npm:@lucid-evolution/lucid@0.4.29";
import { loadOwnerPoolContext } from "../wallet.ts";
import { loadPoolDeployment } from "../../shared/pool-deployment.ts";
import { decodePoolDatum } from "../../shared/datum.ts";
import {
  confirmTransaction,
  findStateUtxo,
} from "../../shared/transactions.ts";
import { togglePoolFlag } from "../builders/pool-toggle.ts";

const controls = {
  pause: {
    env: "POOL_PAUSED",
    pathEnv: "PAUSE_STATE_PATH",
    suffix: "pause",
    field: "isPaused",
  },
  "withdraw-lock": {
    env: "WITHDRAW_LOCKED",
    pathEnv: "WITHDRAW_LOCK_STATE_PATH",
    suffix: "withdraw-lock",
    field: "isLocked",
  },
} as const;

/** Each CLI binds one known control; shared code owns identical transaction/recovery rules. */
export function createPoolToggleFlow(name: keyof typeof controls) {
  const control = controls[name];
  type ToggleState = {
    control: "pause" | "withdraw-lock";
    owner: string;
    poolPolicyId: string;
    desired: boolean;
    txHash: string;
    confirmed: boolean;
  };

  function parseDesired(value: string | undefined): boolean {
    if (value !== "true" && value !== "false") {
      throw new Error(`Set ${control.env} to true or false.`);
    }
    return value === "true";
  }

  async function loadContext() {
    const desired = parseDesired(Deno.env.get(control.env));
    const context = await loadOwnerPoolContext();
    return {
      ...context,
      desired,
      path: Deno.env.get(control.pathEnv) ??
        `${context.deploymentPath}.${control.suffix}.json`,
    };
  }
  type ToggleContext = Awaited<ReturnType<typeof loadContext>>;

  /** Restore the real pool and reconcile an interrupted toggle before building another. */
  async function prepare(context: ToggleContext) {
    const { config, scripts } = await loadPoolDeployment(
      context.deploymentPath,
      "Mainnet",
      context.blueprintPath,
    );
    if (context.owner !== config.manager) {
      throw new Error("OWNER wallet must be the pool manager.");
    }
    let state: ToggleState | undefined;
    try {
      state = JSON.parse(await Deno.readTextFile(context.path));
    } catch (error) {
      if (!(error instanceof Deno.errors.NotFound)) throw error;
    }
    // Upgrade pause journals written before withdrawal-lock control was added.
    if (state && !state.control) state.control = "pause";
    if (
      state &&
      (state.control !== name || state.owner !== context.owner ||
        state.poolPolicyId !== scripts.poolPolicyId)
    ) {
      throw new Error(
        "Control journal belongs to another action/manager/pool.",
      );
    }
    if (state && !state.confirmed) {
      if (state.desired !== context.desired) {
        throw new Error(
          `Resume the pending operation with its original ${control.env} setting first.`,
        );
      }
      await confirmTransaction(context.lucid, state.txHash);
    }
    return {
      context,
      config,
      scripts,
      state,
      poolUnit: toUnit(scripts.poolPolicyId, fromText("POOL")),
    };
  }
  type ToggleSession = Awaited<ReturnType<typeof prepare>>;

  async function saveState(session: ToggleSession) {
    await writeJsonAtomic(session.context.path, session.state);
  }

  /** Skip an already-achieved state, including reruns after the previous toggle completed. */
  async function ensureSubmitted(session: ToggleSession) {
    const { context, config, scripts } = session;
    if (session.state && !session.state.confirmed) return;
    const pool = await findStateUtxo(
      context.lucid,
      scripts.poolAddress,
      session.poolUnit,
    );
    if (decodePoolDatum(pool.datum!)[control.field] === context.desired) {
      console.log("Pool already has requested control state:", context.desired);
      return;
    }
    const built = await togglePoolFlag(
      context.lucid,
      config,
      scripts,
      pool,
      name,
    );
    const signed = await built.completed.sign.withWallet().complete();
    session.state = {
      control: name,
      owner: context.owner,
      poolPolicyId: scripts.poolPolicyId,
      desired: context.desired,
      txHash: signed.toHash(),
      confirmed: false,
    };
    await saveState(session);
    await signed.submit();
    console.log("Pool control transaction:", session.state.txHash);
    await confirmTransaction(context.lucid, session.state.txHash);
  }

  /** Re-query authenticated state after confirmation/indexing and persist the completed operation. */
  async function refresh(session: ToggleSession) {
    const { context, state, scripts } = session;
    for (let attempt = 0; attempt < 12; attempt++) {
      const pool = await findStateUtxo(
        context.lucid,
        scripts.poolAddress,
        session.poolUnit,
      );
      if (decodePoolDatum(pool.datum!)[control.field] === context.desired) {
        if (state && !state.confirmed) {
          state.confirmed = true;
          await saveState(session);
        }
        console.log(control.env + ":", context.desired);
        return;
      }
      await new Promise((resolve) => setTimeout(resolve, 5000));
    }
    throw new Error(
      "Requested control state is not indexed or has changed; inspect the saved transaction before retrying.",
    );
  }

  return { parseDesired, loadContext, prepare, ensureSubmitted, refresh };
}
