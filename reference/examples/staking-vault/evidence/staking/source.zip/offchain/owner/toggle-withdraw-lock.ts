/** Set the desired withdraw-lock state using the manager's owner wallet. */
import { createPoolToggleFlow } from "./flows/pool-toggle.ts";
import { withStateLock } from "../shared/journal.ts";
export { toggleWithdrawLock as buildToggleWithdrawLock } from "./builders/pool-toggle.ts";

const flow = createPoolToggleFlow("withdraw-lock");
export const parseWithdrawLockState = flow.parseDesired;
export const loadWithdrawLockContext = flow.loadContext;
export const prepareWithdrawLock = flow.prepare;
export const ensureWithdrawLockSubmitted = flow.ensureSubmitted;
export const refreshWithdrawLockState = flow.refresh;
export type WithdrawLockContext = Awaited<
  ReturnType<typeof loadWithdrawLockContext>
>;
export type WithdrawLockSession = Awaited<
  ReturnType<typeof prepareWithdrawLock>
>;

export async function main() {
  const context = await loadWithdrawLockContext();
  await withStateLock(context.deploymentPath, async () => {
    const session = await prepareWithdrawLock(context);
    await ensureWithdrawLockSubmitted(session);
    await refreshWithdrawLockState(session);
  });
}

if (import.meta.main) await main();
