import { stakingTransaction } from "../../shared/staking-transaction.ts";
import {
  fromText,
  type LucidEvolution,
  toUnit,
  type UTxO,
} from "npm:@lucid-evolution/lucid@0.4.29";
import { encodePoolDatum } from "../../shared/datum.ts";
import { initializePoolRedeemer } from "../../shared/redeemers.ts";
import { notifyRewards } from "../builders/notify-rewards.ts";
import {
  prepareSingleStaking,
  type StakingScripts,
} from "../../shared/scripts.ts";
import { type StakingConfig } from "../../shared/types.ts";
import {
  type PoolDeployment,
  readDeployment,
  saveDeployment,
} from "./journal.ts";
import type { DeploymentContext } from "./settings.ts";

// The name is shared by all pools; their parameterized policy IDs distinguish them.
export const POOL_TOKEN_NAME = fromText("POOL");

/**
 * Encode StakingDatum.Pool(PoolDatum) in the exact field order declared in Aiken.
 * Constr(0, ...) is the Pool variant; its nested Constr(0, ...) is the record.
 * Initialization has no stake or reward schedule. NotifyRewards sets the schedule later.
 * Aiken booleans use constructors: False = 0, True = 1.
 */
export function initialPoolDatum(initiallyLocked: boolean): string {
  return encodePoolDatum({
    totalStaked: 0n,
    rewardDurationSeconds: 0n,
    periodFinishSeconds: 0n,
    rewardRate: 0n,
    lastUpdateSeconds: 0n,
    rewardPerTokenStored: 0n,
    accruedLiabilityBound: 0n,
    isPaused: false,
    isLocked: initiallyLocked,
  });
}

/**
 * Build an unsigned initialization transaction. The caller completes/signs/submits it.
 * Consume the parameterized bootstrap UTxO once, mint one POOL NFT, and send it
 * with an inline initial datum to the script address. Stake/reward tokens are not minted.
 */
export function initializationBuilder(
  lucid: LucidEvolution,
  config: StakingConfig,
  bootstrap: UTxO,
  scripts: StakingScripts,
) {
  if (
    bootstrap.txHash !== config.bootstrapRef.txHash ||
    BigInt(bootstrap.outputIndex) !== config.bootstrapRef.outputIndex
  ) {
    throw new Error(
      "Bootstrap UTxO does not match the applied script parameter.",
    );
  }
  const poolUnit = toUnit(scripts.poolPolicyId, POOL_TOKEN_NAME);
  return stakingTransaction(lucid, scripts)
    .collectFrom([bootstrap]) // Consume the exact one-time initialization reference.
    .addSignerKey(config.manager)
    .mintAssets({ [poolUnit]: 1n }, initializePoolRedeemer())
    .pay.ToContract(
      scripts.poolAddress,
      { kind: "inline", value: initialPoolDatum(config.initiallyLocked) },
      { [poolUnit]: 1n }, // Lucid adds the required minimum ADA.
    );
}

export async function prepareDeployment(context: DeploymentContext) {
  const { lucid, tokens, manager, distributor, identity } = context;
  const state = await readDeployment(context.path, identity);
  const walletUtxos = await lucid.wallet().getUtxos();
  // Reuse the original reference on retries, even after it has been consumed.
  // Choosing another bootstrap would produce a different policy ID and a new pool.
  const originalConfig = state?.config;
  const bootstrap = originalConfig
    ? walletUtxos.find((u) =>
      u.txHash === originalConfig.bootstrapRef.txHash &&
      BigInt(u.outputIndex) === originalConfig.bootstrapRef.outputIndex
    )
    : walletUtxos.find((u) =>
      !u.scriptRef && Object.keys(u.assets).every((unit) => unit === "lovelace")
    );
  let config: StakingConfig;
  if (originalConfig) config = originalConfig;
  else {
    if (!bootstrap) {
      throw new Error("Manager needs an available ADA-only bootstrap UTxO.");
    }
    config = {
      bootstrapRef: {
        txHash: bootstrap.txHash,
        outputIndex: BigInt(bootstrap.outputIndex),
      },
      manager,
      rewardsDistributor: distributor,
      stakingAsset: tokens.stakingAsset,
      rewardAsset: tokens.rewardAsset,
      initiallyLocked: context.initiallyLocked,
      ...(context.validatorParameterCount >= 7
        ? { vaultSupported: context.vaultSupported }
        : {}),
      ...(context.validatorParameterCount === 8
        ? { factoryPolicy: context.factoryPolicy }
        : {}),
    };
  }
  // Apply version-matched parameters to the shared mint/spend script.
  // The derived policy identifies POOL; the derived address holds its state UTxO.
  const scripts = await prepareSingleStaking(
    config,
    "Mainnet",
    context.blueprintPath,
  );
  const poolUnit = toUnit(scripts.poolPolicyId, POOL_TOKEN_NAME);
  if (
    state &&
    (state.poolPolicyId !== scripts.poolPolicyId ||
      state.poolAddress !== scripts.poolAddress)
  ) {
    throw new Error(
      "Blueprint no longer matches this pool's original script.",
    );
  }
  const deployment: PoolDeployment = state ?? {
    network: "Mainnet",
    poolName: context.poolName,
    protocolVersion: scripts.interfaceVersion,
    positionSchemaVersion: scripts.positionSchemaVersion,
    supportedOwnerModes:
      scripts.interfaceVersion === "factory-v1" && config.vaultSupported
        ? ["wallet", "vault"]
        : ["wallet"],
    withdrawalLockPolicy: config.vaultSupported
      ? "permanently-unlocked"
      : "manager-controlled",
    identity,
    config,
    poolPolicyId: scripts.poolPolicyId,
    poolAddress: scripts.poolAddress,
    poolTokenName: "POOL",
    poolTokenNameHex: POOL_TOKEN_NAME,
    poolUnit,
  };

  const session = {
    context,
    state: deployment,
    config,
    scripts,
    bootstrap,
    walletUtxos,
  };
  await saveDeployment(context.path, deployment);
  if (!deployment.notifyTx) {
    const balance = walletUtxos.reduce(
      (sum, u) => sum + (u.assets[tokens.rewardUnit] ?? 0n),
      0n,
    );
    if (balance < context.reward) {
      throw new Error(
        `Manager needs ${context.reward} Test2 base units; available ${balance}.`,
      );
    }
  }
  return session;
}
export type DeploymentSession = Awaited<ReturnType<typeof prepareDeployment>>;

async function confirmTransaction(lucid: LucidEvolution, hash: string) {
  if (!await lucid.awaitTx(hash)) {
    throw new Error(
      `Confirmation missing: ${hash}. Resume with the same journal.`,
    );
  }
}
async function findPool(session: DeploymentSession, hash?: string) {
  const { context: { lucid }, scripts, state } = session;
  const poolUnit = state.poolUnit;
  for (let attempt = 0; attempt < 12; attempt++) {
    const outputs = await lucid.utxosAtWithUnit(
      scripts.poolAddress,
      poolUnit,
    );
    if (outputs.length > 1) {
      throw new Error("Multiple pool identity outputs.");
    }
    if (
      outputs.length === 1 && outputs[0].assets[poolUnit] === 1n &&
      (!hash || outputs[0].txHash === hash) &&
      (!state.notifyTx ||
        outputs[0].datum !== initialPoolDatum(session.config.initiallyLocked))
    ) return outputs[0];
    await new Promise((resolve) => setTimeout(resolve, 5000));
  }
  throw new Error("Pool output not indexed. Resume with the same journal.");
}

export async function ensurePoolInitialized(session: DeploymentSession) {
  const { context, state, config, scripts, bootstrap } = session;
  const { lucid, baseUrl, apiKey } = context;
  const poolUnit = state.poolUnit;
  // Resume a saved transaction rather than creating another identity.
  if (state.mintTx) {
    await confirmTransaction(lucid, state.mintTx);
    return;
  }
  const response = await fetch(`${baseUrl}/assets/${poolUnit}`, {
    headers: { project_id: apiKey },
    signal: AbortSignal.timeout(30_000),
  });
  if (response.ok) {
    if ((await response.json()).asset !== poolUnit) {
      throw new Error("Unexpected pool lookup response.");
    }
    return; // Already minted: do not initialize it again.
  }
  if (response.status !== 404) {
    throw new Error(
      `Pool lookup HTTP ${response.status}; refusing to assume absence.`,
    );
  }
  if (!bootstrap) {
    throw new Error(
      "Saved bootstrap already spent; inspect chain history before recovery.",
    );
  }
  const completed = await initializationBuilder(
    lucid,
    config,
    bootstrap,
    scripts,
  ).complete({ setCollateral: 2_000_000n });
  const signed = await completed.sign.withWallet().complete();
  // Persist before submit, including cases where submission returns an ambiguous error.
  state.mintTx = signed.toHash();
  await saveDeployment(context.path, state);
  await signed.submit();
  console.log("Pool initialization:", state.mintTx);
  await confirmTransaction(lucid, state.mintTx);
}

export async function ensureRewardsNotified(session: DeploymentSession) {
  const { context, state, config, scripts } = session;
  const { lucid, reward } = context;
  if (state.notifyTx) {
    await confirmTransaction(lucid, state.notifyTx);
    return;
  }
  const poolUtxo = await findPool(session, state.mintTx);
  if (poolUtxo.datum !== initialPoolDatum(session.config.initiallyLocked)) {
    throw new Error(
      "Pool is not in the initial unlocked state; refusing duplicate notification.",
    );
  }
  // Keep the original output for history and save it before notification consumes it.
  state.initialPoolUtxo = poolUtxo;
  state.poolUtxo = poolUtxo;
  await saveDeployment(context.path, state);
  // Use the provider's block time: this host clock may be ahead of the network.
  // The contract still validates the finite 50-second interval independently.
  const tipResponse = await fetch(`${context.baseUrl}/blocks/latest`, {
    headers: { project_id: context.apiKey },
    signal: AbortSignal.timeout(30_000),
  });
  if (!tipResponse.ok) {
    throw new Error(`Network time lookup HTTP ${tipResponse.status}.`);
  }
  const tip = await tipResponse.json();
  if (!Number.isSafeInteger(tip.time) || tip.time < 0) {
    throw new Error("Invalid network block time.");
  }
  const built = await notifyRewards(
    lucid,
    config,
    scripts,
    poolUtxo,
    reward,
    context.durationSeconds,
    tip.time * 1000,
  );
  const signed = await built.completed.sign.withWallet().complete();
  // A retry confirms this hash instead of adding the reward budget a second time.
  state.notifyTx = signed.toHash();
  state.notifiedDatum = built.datum;
  await saveDeployment(context.path, state);
  await signed.submit();
  console.log("NotifyRewards:", state.notifyTx);
  await confirmTransaction(lucid, state.notifyTx);
}

export async function refreshPoolState(session: DeploymentSession) {
  const { context, state, scripts } = session;
  // Current pool may have advanced after a prior run; authenticate identity anew.
  const pool = await findPool(session);
  if (pool.txHash === state.notifyTx && pool.datum !== state.notifiedDatum) {
    throw new Error(
      "Reward notification output differs from the expected schedule.",
    );
  }
  // State updates replace UTxOs. Cache the current reference, not the spent original.
  state.poolUtxo = pool;
  if (!state.notifyTx) state.initialPoolUtxo ??= pool;
  await saveDeployment(context.path, state);
  console.log("Pool ready:", scripts.poolPolicyId, scripts.poolAddress);
  console.log(
    state.notifyTx
      ? "Reward notification confirmed; current pool state:"
      : "Pool initialized; current pool state:",
    `${pool.txHash}#${pool.outputIndex}`,
  );
}
