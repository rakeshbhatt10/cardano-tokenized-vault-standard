import { stakingTransaction } from "../../shared/staking-transaction.ts";
import {
  Constr,
  Data,
  fromText,
  type LucidEvolution,
  toUnit,
  type UTxO,
} from "npm:@lucid-evolution/lucid@0.4.29";
import { previewNotifyRewards } from "../../shared/rewards.ts";
import { decodePoolDatum, encodePoolDatum } from "../../shared/datum.ts";
import { type StakingConfig } from "../../shared/types.ts";
import { type StakingScripts } from "../../shared/scripts.ts";

/** Build the NotifyRewards spend. Caller signs, journals, submits and confirms. */
export async function notifyRewards(
  lucid: LucidEvolution,
  config: StakingConfig,
  scripts: StakingScripts,
  poolUtxo: UTxO,
  reward: bigint,
  durationSeconds: bigint,
  lowerBoundMs: number,
) {
  if (
    !Number.isSafeInteger(lowerBoundMs) || lowerBoundMs < 0 ||
    lowerBoundMs % 1000 !== 0
  ) {
    throw new Error(
      "Use a nonnegative whole-second validity lower bound in milliseconds.",
    );
  }
  const poolUnit = toUnit(scripts.poolPolicyId, fromText("POOL"));
  if (
    poolUtxo.address !== scripts.poolAddress ||
    poolUtxo.assets[poolUnit] !== 1n || !poolUtxo.datum
  ) {
    throw new Error("Expected an authenticated inline pool state UTxO.");
  }
  const before = decodePoolDatum(poolUtxo.datum);
  const accounting = previewNotifyRewards(
    {
      totalStaked: before.totalStaked,
      periodFinishSeconds: before.periodFinishSeconds,
      rewardRate: before.rewardRate,
      lastUpdateSeconds: before.lastUpdateSeconds,
      rewardPerTokenStored: before.rewardPerTokenStored,
      accruedLiabilityBound: before.accruedLiabilityBound,
    },
    reward,
    durationSeconds,
    BigInt(lowerBoundMs / 1000),
  );
  const after = { ...before, ...accounting };
  const rewardUnit = toUnit(
    config.rewardAsset.policyId,
    config.rewardAsset.tokenNameHex,
  );
  const stakeUnit = toUnit(
    config.stakingAsset.policyId,
    config.stakingAsset.tokenNameHex,
  );
  // Add actual reward tokens; never count same-asset principal as reward reserves.
  const assets = {
    ...poolUtxo.assets,
    [rewardUnit]: (poolUtxo.assets[rewardUnit] ?? 0n) + reward,
  };
  const required = after.accruedLiabilityBound +
    after.rewardRate * durationSeconds +
    (rewardUnit === stakeUnit ? after.totalStaked : 0n);
  if (assets[rewardUnit] < required) {
    throw new Error(
      "Insufficient reward backing for the schedule and accrued claims.",
    );
  }
  const datum = encodePoolDatum(after);
  const completed = await stakingTransaction(lucid, scripts)
    .collectFrom([poolUtxo], Data.to(new Constr(5, [reward, durationSeconds])))
    .addSignerKey(config.rewardsDistributor)
    .validFrom(lowerBoundMs)
    .validTo(lowerBoundMs + 50_000)
    .pay.ToContract(
      scripts.poolAddress,
      { kind: "inline", value: datum },
      assets,
    )
    .complete({ setCollateral: 2_000_000n });
  return { completed, datum, pool: after };
}
