import {
  Emulator,
  fromText,
  generateEmulatorAccount,
  Lucid,
  toUnit,
} from "npm:@lucid-evolution/lucid@0.4.29";
import {
  buildRewardTransfer,
  parseRewardTransferAmount,
} from "./transfer-rewards-to-owner.ts";

Deno.test("existing reward transfer sends 1000 tokens and preserves other assets", async () => {
  const rewardUnit = toUnit("ab".repeat(28), fromText("Test2"));
  const stakeUnit = toUnit("cd".repeat(28), fromText("Test1"));
  const sender = generateEmulatorAccount({
    lovelace: 50_000_000n,
    [rewardUnit]: 1_500_000_000n,
    [stakeUnit]: 77_000_000n,
  });
  const owner = generateEmulatorAccount({ lovelace: 20_000_000n });
  const emulator = new Emulator([sender, owner]);
  const lucid = await Lucid(emulator, "Custom");
  lucid.selectWallet.fromSeed(sender.seedPhrase);
  const completed = await buildRewardTransfer(
    lucid,
    rewardUnit,
    parseRewardTransferAmount(),
    owner.address,
  );
  await (await completed.sign.withWallet().complete()).submit();
  emulator.awaitBlock(1);
  const balance = async (address: string, unit: string) =>
    (await lucid.utxosAt(address)).reduce(
      (sum, u) => sum + (u.assets[unit] ?? 0n),
      0n,
    );
  if (
    await balance(owner.address, rewardUnit) !== 1_000_000_000n ||
    await balance(sender.address, rewardUnit) !== 500_000_000n ||
    await balance(sender.address, stakeUnit) !== 77_000_000n
  ) throw new Error("Existing-token transfer changed incorrect balances.");
  let rejected = false;
  try {
    await buildRewardTransfer(lucid, rewardUnit, 1_000_000_000n, owner.address);
  } catch (error) {
    if (!(error instanceof Error) || !error.message.includes("insufficient")) {
      throw error;
    }
    rejected = true;
  }
  if (!rejected) throw new Error("Transfer accepted insufficient tokens.");
});

Deno.test("reward transfer rejects malformed amounts", () => {
  if (parseRewardTransferAmount() !== 1_000_000_000n) {
    throw new Error("Default is not 1000 Test2.");
  }
  for (const value of ["", "0", "-1", "1.5", "1e9"]) {
    let rejected = false;
    try {
      parseRewardTransferAmount(value);
    } catch {
      rejected = true;
    }
    if (!rejected) throw new Error("Invalid transfer amount accepted.");
  }
});
