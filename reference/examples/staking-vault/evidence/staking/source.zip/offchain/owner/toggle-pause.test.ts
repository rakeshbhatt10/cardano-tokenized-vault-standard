import {
  fromText,
  generateEmulatorAccount,
  toUnit,
} from "npm:@lucid-evolution/lucid@0.4.29";
import { testInitializePool } from "../testing/single-staking-fixture.ts";
import { getReward } from "../user/builders/claim.ts";
import { notifyRewards } from "./builders/notify-rewards.ts";
import { stake } from "../user/builders/stake.ts";
import { withdraw } from "../user/builders/withdraw.ts";
import {
  buildTogglePause,
  ensurePauseSubmitted,
  parsePauseState,
  type PauseSession,
  refreshPauseState,
} from "./toggle-pause.ts";
import { decodePoolDatum } from "../shared/datum.ts";

Deno.test("manager pause blocks deposits, permits withdrawal/claim and unpause restores deposits", async () => {
  const { lucid, emulator, config, scripts, poolUtxo } =
    await testInitializePool(false);
  const now = () => Math.floor(emulator.now() / 1000) * 1000;
  const send = async (
    completed: Awaited<ReturnType<typeof stake>>["completed"],
  ) => {
    const signed = await completed.sign.withWallet().complete();
    const hash = await signed.submit();
    emulator.awaitBlock(1);
    return hash;
  };
  const poolUnit = toUnit(scripts.poolPolicyId, fromText("POOL"));
  const read = async (unit: string) =>
    (await lucid.utxosAtWithUnit(scripts.poolAddress, unit))[0];
  const notified = await notifyRewards(
    lucid,
    config,
    scripts,
    poolUtxo,
    70_000_000n,
    604_800n,
    now(),
  );
  await send(notified.completed);
  const deposit = await stake(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    10_000_000n,
    now(),
  );
  await send(deposit.completed);
  const before = await read(poolUnit);
  const paused = await buildTogglePause(lucid, config, scripts, before);
  const hash = await send(paused.completed);
  const after = await read(poolUnit);
  const oldDatum = decodePoolDatum(before.datum!);
  const newDatum = decodePoolDatum(after.datum!);
  if (
    !newDatum.isPaused ||
    JSON.stringify(
        { ...newDatum, isPaused: false },
        (_, value) => typeof value === "bigint" ? value.toString() : value,
      ) !==
      JSON.stringify(
        oldDatum,
        (_, value) => typeof value === "bigint" ? value.toString() : value,
      )
  ) throw new Error("Pause changed other datum fields.");
  for (const [unit, amount] of Object.entries(before.assets)) {
    if (after.assets[unit] !== amount) {
      throw new Error("Pause changed pool assets.");
    }
  }
  let blocked = false;
  try {
    await stake(lucid, config, scripts, after, 1_000_000n, now(), {
      positionUtxo: await read(deposit.positionUnit),
    });
  } catch (error) {
    if (
      !(error instanceof Error) ||
      !error.message.toLowerCase().includes("paused")
    ) throw error;
    blocked = true;
  }
  if (!blocked) throw new Error("Deposit allowed while paused.");
  const directory = await Deno.makeTempDir({
    dir: "/private/tmp",
    prefix: "pause-journal-",
  });
  const context = {
    lucid,
    owner: config.manager,
    desired: true,
    path: `${directory}/state.json`,
    deploymentPath: "unused",
    blueprintPath: "plutus.json",
  };
  const session: PauseSession = {
    context,
    config,
    scripts,
    poolUnit,
    state: {
      control: "pause",
      owner: config.manager,
      poolPolicyId: scripts.poolPolicyId,
      desired: true,
      txHash: hash,
      confirmed: false,
    },
  };
  try {
    await refreshPauseState(session);
    const saved = JSON.parse(await Deno.readTextFile(context.path));
    if (!saved.confirmed) throw new Error("Pause confirmation not persisted.");
    await ensurePauseSubmitted(session);
    if ((await read(poolUnit)).txHash !== hash) {
      throw new Error("Rerun toggled back.");
    }
  } finally {
    await Deno.remove(directory, { recursive: true });
  }
  const withdrawn = await withdraw(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    await read(deposit.positionUnit),
    10_000_000n,
    now(),
  );
  await send(withdrawn.completed);
  const claim = await getReward(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    await read(deposit.positionUnit),
    now(),
  );
  if (claim.rewardAmount <= 0n) {
    throw new Error("Expected accrued rewards while paused.");
  }
  await send(claim.completed);
  const unpaused = await buildTogglePause(
    lucid,
    config,
    scripts,
    await read(poolUnit),
  );
  await send(unpaused.completed);
  if (decodePoolDatum((await read(poolUnit)).datum!).isPaused) {
    throw new Error("Unpause failed.");
  }
  const topup = await stake(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    1_000_000n,
    now(),
    { positionUtxo: await read(deposit.positionUnit) },
  );
  await send(topup.completed);
});

Deno.test("pause builder rejects another wallet and CLI requires an explicit boolean", async () => {
  const { lucid, config, scripts, poolUtxo } = await testInitializePool(false);
  lucid.selectWallet.fromSeed(generateEmulatorAccount({}).seedPhrase);
  let rejected = false;
  try {
    await buildTogglePause(lucid, config, scripts, poolUtxo);
  } catch (error) {
    if (!(error instanceof Error) || !error.message.includes("manager")) {
      throw error;
    }
    rejected = true;
  }
  if (!rejected) throw new Error("Another wallet could toggle pause.");
  if (!parsePauseState("true") || parsePauseState("false")) {
    throw new Error("Incorrect boolean parsing.");
  }
  for (const value of [undefined, "", "yes", "1", "TRUE"]) {
    rejected = false;
    try {
      parsePauseState(value);
    } catch {
      rejected = true;
    }
    if (!rejected) throw new Error("Ambiguous desired pause state accepted.");
  }
});
