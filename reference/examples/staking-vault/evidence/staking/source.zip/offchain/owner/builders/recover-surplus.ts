import { stakingTransaction } from "../../shared/staking-transaction.ts";
import {
  Constr,
  Data,
  fromText,
  getAddressDetails,
  type LucidEvolution,
  toUnit,
  type UTxO,
} from "npm:@lucid-evolution/lucid@0.4.29";
import { decodePoolDatum, encodePoolDatum } from "../../shared/datum.ts";
import { checkpointPool } from "../../shared/rewards.ts";
import type { AssetClass, StakingConfig } from "../../shared/types.ts";
import type { StakingScripts } from "../../shared/scripts.ts";

/** Checkpoint liabilities before calculating native-token surplus; never recover ADA/NFTs. */
export async function recoverSurplus(
  lucid: LucidEvolution,
  config: StakingConfig,
  scripts: StakingScripts,
  poolUtxo: UTxO,
  asset: AssetClass,
  amount: bigint,
  lowerBoundMs: number,
) {
  if (amount <= 0n) {
    throw new Error("Recovery amount must be positive base units.");
  }
  if (
    !/^[0-9a-f]{56}$/.test(asset.policyId) ||
    !/^(?:[0-9a-f]{2}){0,32}$/.test(asset.tokenNameHex) ||
    asset.policyId === scripts.poolPolicyId
  ) {
    throw new Error(
      "Recover only native tokens outside the pool identity policy; ADA is protected.",
    );
  }
  if (
    !Number.isSafeInteger(lowerBoundMs) || lowerBoundMs < 0 ||
    lowerBoundMs % 1000 !== 0
  ) throw new Error("Use whole-second validity lower bound milliseconds.");
  const poolUnit = toUnit(scripts.poolPolicyId, fromText("POOL"));
  if (
    poolUtxo.address !== scripts.poolAddress ||
    poolUtxo.assets[poolUnit] !== 1n || !poolUtxo.datum
  ) throw new Error("Expected authenticated inline pool state.");
  const payoutAddress = await lucid.wallet().address();
  const owner = getAddressDetails(payoutAddress).paymentCredential;
  if (owner?.type !== "Key" || owner.hash !== config.manager) {
    throw new Error("Recovery requires the manager wallet.");
  }
  const before = decodePoolDatum(poolUtxo.datum);
  const time = BigInt(lowerBoundMs / 1000);
  // Pass accounting fields only: checkpointPool validates each numeric input.
  const checkpoint = checkpointPool({
    totalStaked: before.totalStaked,
    periodFinishSeconds: before.periodFinishSeconds,
    rewardRate: before.rewardRate,
    lastUpdateSeconds: before.lastUpdateSeconds,
    rewardPerTokenStored: before.rewardPerTokenStored,
    accruedLiabilityBound: before.accruedLiabilityBound,
  }, time);
  const pool = { ...before, ...checkpoint };
  const unit = toUnit(asset.policyId, asset.tokenNameHex);
  const stakeUnit = toUnit(
    config.stakingAsset.policyId,
    config.stakingAsset.tokenNameHex,
  );
  const rewardUnit = toUnit(
    config.rewardAsset.policyId,
    config.rewardAsset.tokenNameHex,
  );
  const remaining = before.periodFinishSeconds > time
    ? before.periodFinishSeconds - time
    : 0n;
  const rewardReserve = pool.accruedLiabilityBound +
    remaining * pool.rewardRate;
  const protectedAmount = (unit === stakeUnit ? pool.totalStaked : 0n) +
    (unit === rewardUnit ? rewardReserve : 0n);
  const available = (poolUtxo.assets[unit] ?? 0n) - protectedAmount;
  if (amount > available) {
    throw new Error(
      `Recovery exceeds surplus; available ${
        available > 0n ? available : 0n
      } base units.`,
    );
  }
  const assets = {
    ...poolUtxo.assets,
    [unit]: (poolUtxo.assets[unit] ?? 0n) - amount,
  };
  if (assets[unit] === 0n) delete assets[unit];
  if (
    (assets[stakeUnit] ?? 0n) < pool.totalStaked ||
    (assets[rewardUnit] ?? 0n) <
      rewardReserve + (stakeUnit === rewardUnit ? pool.totalStaked : 0n)
  ) throw new Error("Pool principal/reward obligations are underfunded.");
  const datum = encodePoolDatum(pool);
  const redeemer = Data.to(
    new Constr(9, [
      new Constr(0, [asset.policyId, asset.tokenNameHex]),
      amount,
    ]),
  );
  const completed = await stakingTransaction(lucid, scripts).collectFrom([
    poolUtxo,
  ], redeemer)
    .addSignerKey(
      config.manager,
    )
    .validFrom(lowerBoundMs).validTo(lowerBoundMs + 50_000)
    .pay.ToContract(
      scripts.poolAddress,
      { kind: "inline", value: datum },
      assets,
    )
    .pay.ToAddress(payoutAddress, { [unit]: amount }).complete();
  return {
    completed,
    datum,
    pool,
    unit,
    amount,
    available,
    payoutAddress,
    remainingBalance: assets[unit] ?? 0n,
  };
}
