import { rejects } from "node:assert";
import {
  fromText,
  generateEmulatorAccount,
  toUnit,
} from "npm:@lucid-evolution/lucid@0.4.29";
import { testInitializePool } from "../testing/single-staking-fixture.ts";
import { getReward } from "../user/builders/claim.ts";
import { notifyRewards } from "./builders/notify-rewards.ts";
import { stake } from "../user/builders/stake.ts";
import { withdraw } from "../user/builders/withdraw.ts";
import {
  buildToggleWithdrawLock,
  ensureWithdrawLockSubmitted,
  parseWithdrawLockState,
  refreshWithdrawLockState,
  type WithdrawLockSession,
} from "./toggle-withdraw-lock.ts";
import { decodePoolDatum, encodePoolDatum } from "../shared/datum.ts";

Deno.test("manager can lock/unlock early; expiry permits withdrawals without toggling again", async () => {
  const { lucid, emulator, config, scripts, poolUtxo } =
    await testInitializePool(false);
  const now = () => Math.floor(emulator.now() / 1000) * 1000;
  const send = async (
    completed: Awaited<ReturnType<typeof stake>>["completed"],
  ) => {
    const signed = await completed.sign.withWallet().complete();
    const hash = await signed.submit();
    emulator.awaitBlock(1);
    return hash;
  };
  const poolUnit = toUnit(scripts.poolPolicyId, fromText("POOL"));
  const read = async (unit: string) =>
    (await lucid.utxosAtWithUnit(scripts.poolAddress, unit))[0];
  const notified = await notifyRewards(
    lucid,
    config,
    scripts,
    poolUtxo,
    70_000_000n,
    604_800n,
    now(),
  );
  await send(notified.completed);
  const deposit = await stake(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    10_000_000n,
    now(),
  );
  await send(deposit.completed);
  const before = await read(poolUnit);
  const locked = await buildToggleWithdrawLock(lucid, config, scripts, before);
  const hash = await send(locked.completed);
  const after = await read(poolUnit);
  const afterDatum = decodePoolDatum(after.datum!);
  if (
    !afterDatum.isLocked ||
    encodePoolDatum({ ...afterDatum, isLocked: false }) !== before.datum
  ) throw new Error("Lock changed other pool fields.");
  for (const [unit, amount] of Object.entries(before.assets)) {
    if (after.assets[unit] !== amount) throw new Error("Lock changed assets.");
  }
  let blocked = false;
  try {
    await withdraw(
      lucid,
      config,
      scripts,
      after,
      await read(deposit.positionUnit),
      1_000_000n,
      now(),
    );
  } catch (error) {
    if (!(error instanceof Error) || !error.message.includes("locked")) {
      throw error;
    }
    blocked = true;
  }
  if (!blocked) throw new Error("Early withdrawal bypassed lock.");
  const directory = await Deno.makeTempDir({
    dir: "/private/tmp",
    prefix: "lock-journal-",
  });
  const context = {
    lucid,
    owner: config.manager,
    desired: true,
    path: `${directory}/state.json`,
    deploymentPath: "unused",
    blueprintPath: "plutus.json",
  };
  const session: WithdrawLockSession = {
    context,
    config,
    scripts,
    poolUnit,
    state: {
      control: "withdraw-lock",
      owner: config.manager,
      poolPolicyId: scripts.poolPolicyId,
      desired: true,
      txHash: hash,
      confirmed: false,
    },
  };
  try {
    await refreshWithdrawLockState(session);
    const saved = JSON.parse(await Deno.readTextFile(context.path));
    if (!saved.confirmed || saved.control !== "withdraw-lock") {
      throw new Error("Lock confirmation lost.");
    }
    await ensureWithdrawLockSubmitted(session);
    if ((await read(poolUnit)).txHash !== hash) {
      throw new Error("Rerun toggled lock back.");
    }
  } finally {
    await Deno.remove(directory, { recursive: true });
  }
  // Claim remains available even before the locked principal can be withdrawn.
  const claim = await getReward(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    await read(deposit.positionUnit),
    now(),
  );
  await send(claim.completed);
  const unlocked = await buildToggleWithdrawLock(
    lucid,
    config,
    scripts,
    await read(poolUnit),
  );
  await send(unlocked.completed);
  const partial = await withdraw(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    await read(deposit.positionUnit),
    1_000_000n,
    now(),
  );
  await send(partial.completed);
  const relocked = await buildToggleWithdrawLock(
    lucid,
    config,
    scripts,
    await read(poolUnit),
  );
  await send(relocked.completed);
  emulator.awaitSlot(
    Number(notified.pool.periodFinishSeconds - BigInt(now() / 1000)) + 1,
  );
  const expired = await withdraw(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    await read(deposit.positionUnit),
    9_000_000n,
    now(),
  );
  await send(expired.completed);
  if (!decodePoolDatum((await read(poolUnit)).datum!).isLocked) {
    throw new Error("Expiry should not mutate the lock flag.");
  }
});

Deno.test("withdrawal-lock builder rejects another wallet and requires explicit CLI state", async () => {
  const { lucid, config, scripts, poolUtxo } = await testInitializePool(false);
  lucid.selectWallet.fromSeed(generateEmulatorAccount({}).seedPhrase);
  let rejected = false;
  try {
    await buildToggleWithdrawLock(lucid, config, scripts, poolUtxo);
  } catch (error) {
    if (!(error instanceof Error) || !error.message.includes("manager")) {
      throw error;
    }
    rejected = true;
  }
  if (!rejected) throw new Error("Another wallet could toggle lock.");
  if (!parseWithdrawLockState("true") || parseWithdrawLockState("false")) {
    throw new Error("Invalid desired lock parsing.");
  }
  for (const value of [undefined, "", "1", "yes", "TRUE"]) {
    rejected = false;
    try {
      parseWithdrawLockState(value);
    } catch {
      rejected = true;
    }
    if (!rejected) throw new Error("Invalid lock state accepted.");
  }
});

Deno.test("vault-supported pool rejects manager lock toggle in compiled script", async () => {
  const { lucid, config, scripts, poolUtxo } = await testInitializePool(
    false,
    true,
  );
  // The existing builder attempts the toggle; on-chain evaluation must reject it.
  await rejects(() =>
    buildToggleWithdrawLock(lucid, config, scripts, poolUtxo)
  );
});
