import { loadSelectedPool, poolAssets } from "../../shared/pool-registry.ts";
/** Fund the configured staker once with 100 existing staking tokens and 10 ADA. */
import { loadOwnerPoolContext } from "../wallet.ts";
import { loadDeployedTestTokens } from "../../shared/deployed-test-tokens.ts";
import {
  confirmTransaction,
  walletTokenBalance,
} from "../../shared/transactions.ts";
import { withStateLock, writeJsonAtomic } from "../../shared/journal.ts";

export async function main() {
  const { lucid } = await loadOwnerPoolContext();
  const selected = await loadSelectedPool();
  const tokens = selected
    ? poolAssets(selected)
    : await loadDeployedTestTokens();
  const to = Deno.env.get("STAKER_ADDRESS")?.trim();
  if (!to) throw new Error("Set STAKER_ADDRESS.");
  if (to === await lucid.wallet().address()) {
    throw new Error("Staker must differ from owner.");
  }
  const path = selected
    ? `${selected.stakerStatePath}.funding.json`
    : "offchain/staker-state.json.funding.json";
  await withStateLock(path, async () => {
    const identity = JSON.stringify({
      from: await lucid.wallet().address(),
      to,
      unit: tokens.stakingUnit,
      amount: "100000000",
      lovelace: "10000000",
    });
    let state:
      | { identity: string; txHash: string; confirmed: boolean }
      | undefined;
    try {
      state = JSON.parse(await Deno.readTextFile(path));
    } catch (error) {
      if (!(error instanceof Deno.errors.NotFound)) throw error;
    }
    if (state && state.identity !== identity) {
      throw new Error("Funding journal settings differ.");
    }
    if (!state) {
      if (await walletTokenBalance(lucid, tokens.stakingUnit) < 100_000_000n) {
        throw new Error("Owner lacks 100 staking tokens.");
      }
      // Separate ADA-only output remains available for Plutus collateral.
      const completed = await lucid.newTx()
        .pay.ToAddress(to, {
          lovelace: 5_000_000n,
          [tokens.stakingUnit]: 100_000_000n,
        })
        .pay.ToAddress(to, { lovelace: 5_000_000n }).complete();
      const signed = await completed.sign.withWallet().complete();
      state = { identity, txHash: signed.toHash(), confirmed: false };
      await writeJsonAtomic(path, state);
      await signed.submit();
      console.log("Staker funding submitted:", state.txHash);
    }
    if (!state.confirmed) {
      await confirmTransaction(lucid, state.txHash);
      state.confirmed = true;
      await writeJsonAtomic(path, state);
    }
    console.log("Staker funding confirmed:", state.txHash);
  });
}
if (import.meta.main) await main();
