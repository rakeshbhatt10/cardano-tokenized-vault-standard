import { stakingTransaction } from "../../shared/staking-transaction.ts";
/** Reserve-only reward funding. Schedule/checkpoint fields are kept byte-for-byte. */
import {
  Constr,
  Data,
  fromText,
  getAddressDetails,
  type LucidEvolution,
  toUnit,
  type UTxO,
} from "npm:@lucid-evolution/lucid@0.4.29";
import { decodePoolDatum } from "../../shared/datum.ts";
import type { StakingScripts } from "../../shared/scripts.ts";
import type { StakingConfig } from "../../shared/types.ts";

export async function fundRewards(
  lucid: LucidEvolution,
  config: StakingConfig,
  scripts: StakingScripts,
  poolUtxo: UTxO,
  amount: bigint,
) {
  if (amount <= 0n) {
    throw new Error("Funding amount must be positive reward base units.");
  }
  const poolUnit = toUnit(scripts.poolPolicyId, fromText("POOL"));
  if (
    poolUtxo.address !== scripts.poolAddress ||
    poolUtxo.assets[poolUnit] !== 1n || !poolUtxo.datum
  ) {
    throw new Error("Expected authenticated inline pool state.");
  }
  const owner =
    getAddressDetails(await lucid.wallet().address()).paymentCredential;
  if (owner?.type !== "Key" || owner.hash !== config.rewardsDistributor) {
    throw new Error("Funding requires the rewards distributor wallet.");
  }
  const pool = decodePoolDatum(poolUtxo.datum);
  const rewardUnit = toUnit(
    config.rewardAsset.policyId,
    config.rewardAsset.tokenNameHex,
  );
  const assets = {
    ...poolUtxo.assets,
    [rewardUnit]: (poolUtxo.assets[rewardUnit] ?? 0n) + amount,
  };
  const completed = await stakingTransaction(lucid, scripts)
    .collectFrom([poolUtxo], Data.to(new Constr(6, [amount])))
    .addSignerKey(config.rewardsDistributor)
    .pay.ToContract(scripts.poolAddress, {
      kind: "inline",
      value: poolUtxo.datum,
    }, assets)
    .complete();
  return {
    completed,
    pool,
    datum: poolUtxo.datum,
    rewardUnit,
    rewardBalance: assets[rewardUnit],
    amount,
  };
}
