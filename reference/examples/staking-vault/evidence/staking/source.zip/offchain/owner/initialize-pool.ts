/** Phase 1 only: create the named pool identity/state. No rewards are notified or staked. */
import { withStateLock } from "../shared/journal.ts";
import { loadDeploymentContext } from "./setup/settings.ts";
import {
  ensurePoolInitialized,
  prepareDeployment,
  refreshPoolState,
} from "./setup/pool.ts";

export async function main() {
  const context = await loadDeploymentContext();
  await withStateLock(context.path, async () => {
    const session = await prepareDeployment(context);
    await ensurePoolInitialized(session);
    await refreshPoolState(session);
  });
}
if (import.meta.main) await main();
