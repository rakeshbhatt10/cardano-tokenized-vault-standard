import { assetExists } from "./deploy-test-tokens.ts";

Deno.test("existence checks skip zero-supply assets and fail closed on provider errors", async () => {
  const original = globalThis.fetch;
  const unit = "test-unit";
  try {
    for (
      const [status, body, expected] of [
        [200, { asset: unit, quantity: "0" }, true],
        [404, { error: "Not Found" }, false],
        [401, {}, "error"],
        [429, {}, "error"],
        [500, {}, "error"],
        [200, { asset: "wrong-unit" }, "error"],
      ] as const
    ) {
      globalThis.fetch = () =>
        Promise.resolve(new Response(JSON.stringify(body), { status }));
      let result: boolean | string;
      try {
        result = await assetExists("https://example.invalid", "test", unit);
      } catch {
        result = "error";
      }
      if (result !== expected) {
        throw new Error(`Unexpected result for ${status}: ${result}`);
      }
    }
    globalThis.fetch = () => Promise.reject(new Error("network unavailable"));
    let rejected = false;
    try {
      await assetExists("https://example.invalid", "test", unit);
    } catch {
      rejected = true;
    }
    if (!rejected) throw new Error("Network failure must not permit minting.");
  } finally {
    globalThis.fetch = original;
  }
});
