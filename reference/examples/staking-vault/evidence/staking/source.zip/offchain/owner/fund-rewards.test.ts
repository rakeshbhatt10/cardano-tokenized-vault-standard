import {
  fromText,
  generateEmulatorAccount,
  toUnit,
} from "npm:@lucid-evolution/lucid@0.4.29";
import { testInitializePool } from "../testing/single-staking-fixture.ts";
import {
  buildFundRewards,
  type FundingSession,
  parseFundingAmount,
  refreshFundingState,
} from "./fund-rewards.ts";
import { getReward } from "../user/builders/claim.ts";
import { notifyRewards } from "./builders/notify-rewards.ts";
import { stake } from "../user/builders/stake.ts";

Deno.test("FundRewards adds actual Test2 without checkpointing or changing the schedule", async () => {
  const { lucid, emulator, config, scripts, poolUtxo } =
    await testInitializePool(false);
  const now = () => Math.floor(emulator.now() / 1000) * 1000;
  const send = async (
    completed: Awaited<ReturnType<typeof stake>>["completed"],
  ) => {
    const signed = await completed.sign.withWallet().complete();
    const hash = await signed.submit();
    emulator.awaitBlock(1);
    return hash;
  };
  const poolUnit = toUnit(scripts.poolPolicyId, fromText("POOL"));
  const rewardUnit = toUnit(
    config.rewardAsset.policyId,
    config.rewardAsset.tokenNameHex,
  );
  const stakeUnit = toUnit(
    config.stakingAsset.policyId,
    config.stakingAsset.tokenNameHex,
  );
  const read = async (unit: string) =>
    (await lucid.utxosAtWithUnit(scripts.poolAddress, unit))[0];
  const notified = await notifyRewards(
    lucid,
    config,
    scripts,
    poolUtxo,
    70_000_000n,
    604_800n,
    now(),
  );
  await send(notified.completed);
  const stakeTime = now();
  const deposit = await stake(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    100_000_000n,
    stakeTime,
  );
  await send(deposit.completed);
  emulator.awaitSlot(60);
  const before = await read(poolUnit);
  const balance = async () =>
    (await lucid.wallet().getUtxos()).reduce(
      (sum, u) => sum + (u.assets[rewardUnit] ?? 0n),
      0n,
    );
  const walletBefore = await balance();
  const built = await buildFundRewards(
    lucid,
    config,
    scripts,
    before,
    30_000_000n,
  );
  const hash = await send(built.completed);
  const after = await read(poolUnit);
  if (
    after.datum !== before.datum ||
    after.assets[rewardUnit] !== before.assets[rewardUnit] + 30_000_000n ||
    await balance() !== walletBefore - 30_000_000n ||
    after.assets[stakeUnit] !== before.assets[stakeUnit]
  ) {
    throw new Error(
      "Funding changed accounting/principal or failed to transfer rewards.",
    );
  }
  const directory = await Deno.makeTempDir({
    dir: "/private/tmp",
    prefix: "funding-journal-",
  });
  const context = {
    lucid,
    owner: config.rewardsDistributor,
    amount: 30_000_000n,
    path: `${directory}/state.json`,
    deploymentPath: "unused",
    blueprintPath: "plutus.json",
  };
  const session: FundingSession = {
    context,
    config,
    scripts,
    poolUnit,
    state: {
      owner: context.owner,
      poolPolicyId: scripts.poolPolicyId,
      amount: "30000000",
      txHash: hash,
      expectedDatum: built.datum,
      expectedRewardBalance: built.rewardBalance.toString(),
      confirmed: false,
    },
  };
  try {
    await refreshFundingState(session);
    const saved = JSON.parse(await Deno.readTextFile(context.path));
    if (
      !saved.confirmed || saved.txHash !== hash || saved.poolRef.txHash !== hash
    ) throw new Error("Funding confirmation journal missing.");
  } finally {
    await Deno.remove(directory, { recursive: true });
  }
  const claimTime = now();
  const claim = await getReward(
    lucid,
    config,
    scripts,
    after,
    await read(deposit.positionUnit),
    claimTime,
  );
  if (
    claim.rewardAmount !==
      BigInt((claimTime - stakeTime) / 1000) * notified.pool.rewardRate
  ) throw new Error("Funding changed earned emission rate.");
  await send(claim.completed);
});

Deno.test("funding is allowed before notification and rejects zero or another wallet", async () => {
  const { lucid, emulator, config, scripts, poolUtxo } =
    await testInitializePool(true);
  const built = await buildFundRewards(
    lucid,
    config,
    scripts,
    poolUtxo,
    30_000_000n,
  );
  await (await built.completed.sign.withWallet().complete()).submit();
  emulator.awaitBlock(1);
  const poolUnit = toUnit(scripts.poolPolicyId, fromText("POOL"));
  const [current] = await lucid.utxosAtWithUnit(scripts.poolAddress, poolUnit);
  if (current.datum !== poolUtxo.datum || built.pool.rewardRate !== 0n) {
    throw new Error("Funding started a schedule.");
  }
  let rejected = false;
  try {
    await buildFundRewards(lucid, config, scripts, current, 0n);
  } catch (error) {
    if (!(error instanceof Error) || !error.message.includes("positive")) {
      throw error;
    }
    rejected = true;
  }
  if (!rejected) throw new Error("Zero funding accepted.");
  lucid.selectWallet.fromSeed(generateEmulatorAccount({}).seedPhrase);
  rejected = false;
  try {
    await buildFundRewards(lucid, config, scripts, current, 1n);
  } catch (error) {
    if (!(error instanceof Error) || !error.message.includes("distributor")) {
      throw error;
    }
    rejected = true;
  }
  if (!rejected) {
    throw new Error("Another wallet funded without distributor authorization.");
  }
});

Deno.test("funding amount must be explicit positive base units", () => {
  if (parseFundingAmount("30000000") !== 30_000_000n) {
    throw new Error("Invalid amount parsing.");
  }
  for (const value of [undefined, "", "0", "-1", "1.5", "1e6", " 10"]) {
    let rejected = false;
    try {
      parseFundingAmount(value);
    } catch {
      rejected = true;
    }
    if (!rejected) throw new Error("Invalid funding amount accepted.");
  }
});
