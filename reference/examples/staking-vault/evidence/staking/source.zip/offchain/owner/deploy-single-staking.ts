/** Initialize the pool, notify rewards, then optionally switch to the staker wallet. */
import { withStateLock } from "../shared/journal.ts";
import { loadDeploymentContext } from "./setup/settings.ts";
import {
  ensurePoolInitialized,
  ensureRewardsNotified,
  prepareDeployment,
  refreshPoolState,
} from "./setup/pool.ts";
import { main as stakeAll } from "../user/stake-all.ts";
export async function main() {
  const context = await loadDeploymentContext();
  await withStateLock(context.path, async () => {
    const session = await prepareDeployment(context);
    await ensurePoolInitialized(session);
    await ensureRewardsNotified(session);
    await refreshPoolState(session);
  });
  if (context.runStake) await stakeAll();
}
if (import.meta.main) await main();
