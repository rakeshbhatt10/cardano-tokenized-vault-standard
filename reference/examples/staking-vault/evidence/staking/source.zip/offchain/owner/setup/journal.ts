import { writeJsonAtomic } from "../../shared/journal.ts";
import type { UTxO } from "npm:@lucid-evolution/lucid@0.4.29";
import type { StakingConfig } from "../../shared/types.ts";

/** Local progress journal, not a source of truth for current on-chain balances. */
export type PoolDeployment = {
  network: "Mainnet";
  protocolVersion?: "wallet-v1" | "owner-v2" | "factory-v1";
  positionSchemaVersion?: 1 | 2;
  supportedOwnerModes?: ("wallet" | "vault")[];
  withdrawalLockPolicy?: "manager-controlled" | "permanently-unlocked";
  poolName?: string; // Local display name; the policy ID/NFT define on-chain identity.
  identity: string; // Configuration fingerprint: retries must use the same settings.
  config: StakingConfig; // Original parameters needed to reproduce the script hash.
  poolPolicyId: string;
  poolAddress: string;
  poolTokenName: string;
  poolTokenNameHex: string;
  poolUnit: string;
  mintTx?: string; // Saved before submission, including an ambiguous submission failure.
  notifyTx?: string; // Prevents funding/restarting the schedule again on a retry.
  notifiedDatum?: string;
  initialPoolUtxo?: UTxO; // Historical initialization output; NotifyRewards spends it.
  poolUtxo?: UTxO; // Latest observed output; always re-query before spending.
};

// Disk JSON contains decimal strings; the rest of the application uses bigint.
type StoredUtxo = Omit<UTxO, "assets"> & { assets: Record<string, string> };
type StoredDeployment =
  & Omit<PoolDeployment, "config" | "initialPoolUtxo" | "poolUtxo">
  & {
    config: Omit<StakingConfig, "bootstrapRef"> & {
      bootstrapRef: { txHash: string; outputIndex: string };
    };
    initialPoolUtxo?: StoredUtxo;
    poolUtxo?: StoredUtxo;
  };
function restoreUtxo(utxo: StoredUtxo | undefined): UTxO | undefined {
  if (!utxo) return undefined;
  return {
    ...utxo,
    assets: Object.fromEntries(
      Object.entries(utxo.assets).map((
        [unit, amount],
      ) => [unit, BigInt(amount)]),
    ),
  };
}

export async function readDeployment(
  path: string,
  identity: string,
): Promise<PoolDeployment | undefined> {
  try {
    const state: StoredDeployment = JSON.parse(await Deno.readTextFile(path));
    if (!state || state.identity !== identity) {
      throw new Error(
        "Deployment settings differ from the saved pool. Use original settings to resume or another STAKING_STATE_PATH for a new pool.",
      );
    }
    return {
      ...state,
      config: {
        ...state.config,
        bootstrapRef: {
          ...state.config.bootstrapRef,
          outputIndex: BigInt(state.config.bootstrapRef.outputIndex),
        },
      },
      initialPoolUtxo: restoreUtxo(state.initialPoolUtxo),
      poolUtxo: restoreUtxo(state.poolUtxo),
    };
  } catch (error) {
    if (error instanceof Deno.errors.NotFound) return undefined;
    throw error;
  }
}

/** Atomic JSON replacement; hashes must be saved before submission. */
export async function saveDeployment(path: string, state: PoolDeployment) {
  await writeJsonAtomic(path, state);
}
