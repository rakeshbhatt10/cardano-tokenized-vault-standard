import {
  Emulator,
  generateSeedPhrase,
  Lucid,
} from "npm:@lucid-evolution/lucid@0.4.29";

// Generate locally; never print the mnemonic or overwrite an existing wallet.
const path = Deno.args[0] ?? ".env";
const mnemonic = generateSeedPhrase();
// An empty local provider supports derivation without network access.
const lucid = await Lucid(new Emulator([]), "Preview");
lucid.selectWallet.fromSeed(mnemonic);
const address = await lucid.wallet().address();
const content =
  `# Generated locally for Cardano testnet. Keep this file private.
NETWORK=Preview
BLOCKFROST_API_KEY=
OWNER_MNEMONIC="${mnemonic}"
OWNER_ADDRESS=${address}
RECIPIENT_ADDRESS=
MINT_AMOUNT=1000000000
TRANSFER_AMOUNT=100000000
TOKEN_DECIMALS=6
BLUEPRINT_PATH=plutus.json
STATE_PATH=offchain/test-tokens-state.json
`;
const file = await Deno.open(path, {
  write: true,
  createNew: true,
  mode: 0o600,
});
try {
  await file.write(new TextEncoder().encode(content));
} finally {
  file.close();
}
console.log(`Wallet saved privately to ${path}`);
console.log(`Preview/Preprod address: ${address}`);
