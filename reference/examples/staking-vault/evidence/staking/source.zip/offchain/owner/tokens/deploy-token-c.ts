import { main } from "./deploy-test-tokens.ts";

// Keep tokenC's progress separate from the Test1/Test2 transaction journal.
await main({
  tokenNames: ["tokenC"],
  statePath: "offchain/token-c-state.json",
});
