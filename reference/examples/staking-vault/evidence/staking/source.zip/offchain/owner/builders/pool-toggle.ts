import { stakingTransaction } from "../../shared/staking-transaction.ts";
import {
  Constr,
  Data,
  fromText,
  getAddressDetails,
  type LucidEvolution,
  toUnit,
  type UTxO,
} from "npm:@lucid-evolution/lucid@0.4.29";
import { decodePoolDatum, encodePoolDatum } from "../../shared/datum.ts";
import type { StakingScripts } from "../../shared/scripts.ts";
import type { StakingConfig } from "../../shared/types.ts";

/** Build a manager-only toggle; the full input value stays at the pool address. */
export async function togglePoolFlag(
  lucid: LucidEvolution,
  config: StakingConfig,
  scripts: StakingScripts,
  poolUtxo: UTxO,
  control: "pause" | "withdraw-lock",
) {
  const poolUnit = toUnit(scripts.poolPolicyId, fromText("POOL"));
  if (
    poolUtxo.address !== scripts.poolAddress ||
    poolUtxo.assets[poolUnit] !== 1n || !poolUtxo.datum
  ) throw new Error("Expected authenticated inline pool state.");
  const owner =
    getAddressDetails(await lucid.wallet().address()).paymentCredential;
  if (owner?.type !== "Key" || owner.hash !== config.manager) {
    throw new Error("Pool control changes require the manager wallet.");
  }
  const before = decodePoolDatum(poolUtxo.datum);
  const pool = control === "pause"
    ? { ...before, isPaused: !before.isPaused }
    : { ...before, isLocked: !before.isLocked };
  const datum = encodePoolDatum(pool);
  const completed = await stakingTransaction(lucid, scripts)
    .collectFrom(
      [poolUtxo],
      Data.to(new Constr(control === "pause" ? 7 : 8, [])),
    )
    .addSignerKey(config.manager)
    .pay.ToContract(
      scripts.poolAddress,
      { kind: "inline", value: datum },
      poolUtxo.assets,
    )
    .complete();
  return { completed, pool, datum };
}

export function togglePause(
  lucid: LucidEvolution,
  config: StakingConfig,
  scripts: StakingScripts,
  poolUtxo: UTxO,
) {
  return togglePoolFlag(lucid, config, scripts, poolUtxo, "pause");
}

export function toggleWithdrawLock(
  lucid: LucidEvolution,
  config: StakingConfig,
  scripts: StakingScripts,
  poolUtxo: UTxO,
) {
  return togglePoolFlag(lucid, config, scripts, poolUtxo, "withdraw-lock");
}
