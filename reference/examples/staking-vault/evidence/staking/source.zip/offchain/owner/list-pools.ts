/** Local registry inventory; no signing or network access. */
import { loadPools } from "../shared/pool-registry.ts";
export async function main() {
  for (const pool of await loadPools()) {
    let saved:
      | { mintTx?: string; notifyTx?: string; poolPolicyId?: string }
      | undefined;
    try {
      saved = JSON.parse(await Deno.readTextFile(pool.statePath));
    } catch (error) {
      if (!(error instanceof Deno.errors.NotFound)) throw error;
    }
    console.log(JSON.stringify({
      id: pool.id,
      name: pool.name,
      deploy: pool.deploy,
      status: saved?.notifyTx
        ? "notification transaction recorded"
        : saved?.mintTx
        ? "initialization transaction recorded"
        : "planned",
      poolPolicyId: saved?.poolPolicyId ?? null,
      statePath: pool.statePath,
      stakerStatePath: pool.stakerStatePath,
      deploymentDirectory: pool.deploymentDirectory,
    }));
  }
}
if (import.meta.main) await main();
