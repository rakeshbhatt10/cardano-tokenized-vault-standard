import {
  Emulator,
  generateSeedPhrase,
  Lucid,
} from "npm:@lucid-evolution/lucid@0.4.29";

const path = Deno.args[0] ?? ".env";
const original = await Deno.readTextFile(path);
// Never replace an existing recipient wallet or address.
for (const key of ["RECIPIENT_ADDRESS", "RECIPIENT_MNEMONIC"]) {
  const entries = original.split(/\r?\n/).filter((line) =>
    new RegExp(`^\\s*(?:export\\s+)?${key}\\s*=`).test(line)
  );
  if (entries.length > 1) {
    throw new Error(`Duplicate ${key}; resolve before generating.`);
  }
  if (
    entries.some((line) => {
      const value = line.slice(line.indexOf("=") + 1).trim();
      return value !== "" && value !== '""' && value !== "''";
    })
  ) throw new Error(`${key} is already configured; refusing to overwrite.`);
}
const mnemonic = generateSeedPhrase();
const lucid = await Lucid(new Emulator([]), "Preview");
lucid.selectWallet.fromSeed(mnemonic);
const address = await lucid.wallet().address();
let updated = original;
for (
  const [key, value] of [
    ["RECIPIENT_ADDRESS", address],
    ["RECIPIENT_MNEMONIC", `"${mnemonic}"`],
  ]
) {
  const pattern = new RegExp(`^\\s*(?:export\\s+)?${key}\\s*=.*$`, "m");
  updated = pattern.test(updated)
    ? updated.replace(pattern, `${key}=${value}`)
    : `${updated.trimEnd()}\n${key}=${value}\n`;
}
// Check for edits made while the wallet was being derived.
if (await Deno.readTextFile(path) !== original) {
  throw new Error("Environment file changed; retry without concurrent edits.");
}
await Deno.chmod(path, 0o600);
await Deno.writeTextFile(path, updated);
console.log(`Recipient wallet saved privately to ${path}`);
console.log(`Preview/Preprod recipient address: ${address}`);
