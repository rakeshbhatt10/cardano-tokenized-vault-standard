/** LOCAL EMULATOR ONLY. Exports unsigned bytes/metrics, never fixture keys/signatures. */
import { CML } from "npm:@lucid-evolution/lucid@0.4.29";
import { testInitializePool } from "./single-staking-fixture.ts";

function budgets(cbor: string) {
  const tx = CML.Transaction.from_cbor_hex(cbor);
  const flat = tx.witness_set().redeemers()?.to_flat_format();
  const rows = [];
  for (let i = 0; flat && i < flat.len(); i++) {
    const r = flat.get(i), units = r.ex_units();
    rows.push({
      purposeTag: r.tag(),
      index: r.index().toString(),
      memory: units.mem().toString(),
      steps: units.steps().toString(),
    });
  }
  return rows;
}
async function sha256(bytes: Uint8Array) {
  const digest = await crypto.subtle.digest("SHA-256", new Uint8Array(bytes));
  return Array.from(
    new Uint8Array(digest),
    (b) => b.toString(16).padStart(2, "0"),
  ).join("");
}
const blueprintSha256 = await sha256(await Deno.readFile("plutus.json"));
const f = await testInitializePool(false, true);
if (!f.referencePublication) {
  throw new Error("Missing actual reference publication.");
}
const directory = Deno.args[0] ?? "integration/mixed-owner-v1";
await Deno.mkdir(directory, { recursive: true });
await Deno.writeTextFile(
  `${directory}/reference-publication.unsigned.cbor`,
  f.referencePublication.unsignedCbor + "\n",
);
await Deno.writeTextFile(
  `${directory}/pool-initialization.unsigned.cbor`,
  f.initializationUnsignedCbor + "\n",
);
await Deno.writeTextFile(
  `${directory}/emulator-evidence.json`,
  JSON.stringify(
    {
      schema: "FRAC-STAKING-EMULATOR-EVIDENCE-1",
      synthetic: true,
      blueprintSha256,
      productionFactoryPolicy: null,
      fixtureFactoryPolicy: f.config.factoryPolicy,
      referencePublication: {
        unsignedBytes: f.referencePublication.unsignedCbor.length / 2,
        signedBytesMeasuredInEmulator: f.referencePublication.signedBytes,
        scriptBytes: f.referencePublication.scriptBytes,
      },
      initialization: {
        unsignedBytes: f.initializationUnsignedCbor.length / 2,
        signedBytesMeasuredInEmulator: f.initializationSignedBytes,
        declaredExecutionUnits: budgets(f.initializationUnsignedCbor),
        localEvaluationPassed: true,
      },
      maxTransactionBytes: 16384,
      signedArtifactsExported: false,
      privateKeysExported: false,
      externalFactoryIssuanceTested: false,
      fullVaultLifecycleTested: false,
      networkAcceptance: false,
      deploymentReady: false,
      executionEnabled: false,
    },
    null,
    2,
  ) + "\n",
);
console.log(
  "Exported unsigned synthetic publication/initialization evidence only.",
);
