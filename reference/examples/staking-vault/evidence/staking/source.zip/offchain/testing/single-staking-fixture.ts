import {
  Emulator,
  generateEmulatorAccount,
  getAddressDetails,
  Lucid,
  toUnit,
} from "npm:@lucid-evolution/lucid@0.4.29";
import { loadDeployedTestTokens } from "../shared/deployed-test-tokens.ts";
import {
  initializationBuilder,
  initialPoolDatum,
  POOL_TOKEN_NAME,
} from "../owner/setup/pool.ts";
import { initializePoolRedeemer } from "../shared/redeemers.ts";
import {
  prepareSingleStaking,
  type StakingScripts,
} from "../shared/scripts.ts";
import { type StakingConfig } from "../shared/types.ts";
/** Local ledger test; does not read .env, use real keys, or contact Mainnet. */
export async function testInitializePool(
  initiallyLocked = true,
  vaultSupported = false,
  blueprintPath = "plutus.json",
) {
  const deployedTokens = await loadDeployedTestTokens();
  const manager = generateEmulatorAccount({
    lovelace: 200_000_000n,
    [deployedTokens.rewardUnit]: 1_000_000_000n,
    [deployedTokens.stakingUnit]: 2_000_000_000n,
  });
  const emulator = new Emulator([manager]);
  emulator.time = Math.floor(emulator.time / 1000) * 1000;
  const lucid = await Lucid(emulator, "Custom");
  lucid.selectWallet.fromSeed(manager.seedPhrase);
  const ownerAddress = await lucid.wallet().address();
  const credential = getAddressDetails(ownerAddress).paymentCredential;
  if (credential?.type !== "Key") {
    throw new Error("Expected a manager payment key.");
  }

  // Split first so the bootstrap and collateral can use separate UTxOs.
  const split = await lucid.newTx()
    .pay.ToAddress(ownerAddress, { lovelace: 20_000_000n })
    .pay.ToAddress(ownerAddress, { lovelace: 20_000_000n })
    .complete();
  await (await split.sign.withWallet().complete()).submit();
  emulator.awaitBlock(1);
  const utxos = await lucid.wallet().getUtxos();
  const bootstrap = utxos.find((utxo) =>
    !utxo.scriptRef &&
    Object.keys(utxo.assets).every((unit) => unit === "lovelace")
  );
  if (!bootstrap) throw new Error("No available manager bootstrap UTxO.");

  const blueprint = JSON.parse(await Deno.readTextFile(blueprintPath));
  const legacy =
    blueprint.validators.find((v: { title: string }) =>
      v.title === "single_staking.single_staking.mint"
    ).parameters.length === 6;
  if (legacy && vaultSupported) {
    throw new Error("Legacy pools cannot support vaults.");
  }
  const config: StakingConfig = {
    bootstrapRef: {
      txHash: bootstrap.txHash,
      outputIndex: BigInt(bootstrap.outputIndex),
    },
    manager: credential.hash,
    rewardsDistributor: credential.hash,
    stakingAsset: deployedTokens.stakingAsset,
    rewardAsset: deployedTokens.rewardAsset,
    initiallyLocked,
    ...(legacy ? {} : { vaultSupported }),
    ...(blueprint.validators.find((v: { title: string }) =>
        v.title === "single_staking.single_staking.mint"
      ).parameters.length === 8
      ? { factoryPolicy: vaultSupported ? "55".repeat(28) : null }
      : {}),
  };
  const scripts: StakingScripts = await prepareSingleStaking(
    config,
    "Custom",
    blueprintPath,
  );
  // Publish the actual reference script under the unchanged ledger size/min-ADA limits.
  // The synthetic reference output is outside the funding wallet's input selection.
  let referencePublication: {
    unsignedCbor: string;
    signedBytes: number;
    scriptBytes: number;
  } | undefined;
  if (scripts.interfaceVersion === "factory-v1") {
    const publication = await lucid.newTx().pay.ToAddressWithData(
      scripts.poolAddress,
      undefined,
      {},
      scripts.spendingValidator,
    ).complete();
    const signedPublication = await publication.sign.withWallet().complete();
    referencePublication = {
      unsignedCbor: publication.toCBOR(),
      signedBytes: signedPublication.toCBOR().length / 2,
      scriptBytes: scripts.spendingValidator.script.length / 2,
    };
    const publicationHash = await signedPublication.submit();
    emulator.awaitBlock(1);
    const references = await lucid.utxosByOutRef([{
      txHash: publicationHash,
      outputIndex: 0,
    }]);
    if (!references[0]?.scriptRef) {
      throw new Error("Missing staking reference script publication.");
    }
    scripts.referenceUtxo = references[0];
  }
  const poolUnit = toUnit(scripts.poolPolicyId, POOL_TOKEN_NAME);

  // Like deploy-test-tokens.ts: check exact identity before minting.
  const existing = await lucid.utxosAtWithUnit(scripts.poolAddress, poolUnit);
  if (existing.length) {
    throw new Error("Unexpected existing pool in a fresh emulator.");
  }
  // Exercise real script evaluation, not only datum construction assertions.
  for (
    const invalid of [
      "missing manager signature",
      "incorrect initial lock",
    ] as const
  ) {
    let rejected = false;
    try {
      let tx = lucid.newTx()
        .collectFrom([bootstrap])
        .mintAssets({ [poolUnit]: 1n }, initializePoolRedeemer())
        .attach.MintingPolicy(scripts.mintingPolicy)
        .pay.ToContract(scripts.poolAddress, {
          kind: "inline",
          value: initialPoolDatum(
            invalid === "incorrect initial lock"
              ? !initiallyLocked
              : initiallyLocked,
          ),
        }, { [poolUnit]: 1n });
      if (invalid !== "missing manager signature") {
        tx = tx.addSignerKey(config.manager);
      }
      const invalidTx = await tx.complete();
      await (await invalidTx.sign.withWallet().complete()).submit();
    } catch {
      rejected = true;
    }
    if (!rejected) {
      throw new Error(`Invalid initialization accepted: ${invalid}`);
    }
  }

  const completed = await initializationBuilder(
    lucid,
    config,
    bootstrap,
    scripts,
  ).complete();
  const signed = await completed.sign.withWallet().complete();
  const mintTx = await signed.submit();
  emulator.awaitBlock(1);
  if (!await lucid.awaitTx(mintTx)) {
    throw new Error("Pool initialization did not confirm.");
  }

  const outputs = await lucid.utxosAtWithUnit(scripts.poolAddress, poolUnit);
  if (outputs.length !== 1 || outputs[0].assets[poolUnit] !== 1n) {
    throw new Error("Expected exactly one pool state with one POOL NFT.");
  }
  if (outputs[0].datum !== initialPoolDatum(initiallyLocked)) {
    throw new Error(
      "Pool datum does not match the zero state and configured lock.",
    );
  }
  if (
    Object.keys(outputs[0].assets).some((unit) =>
      unit !== "lovelace" && unit !== poolUnit
    )
  ) {
    throw new Error("Unexpected initial pool asset.");
  }
  if (
    (await lucid.wallet().getUtxos()).some((utxo) =>
      utxo.txHash === bootstrap.txHash &&
      utxo.outputIndex === bootstrap.outputIndex
    )
  ) throw new Error("Bootstrap UTxO was not consumed.");

  // A second initialization cannot reuse the spent bootstrap.
  let replayRejected = false;
  try {
    const replay = await initializationBuilder(
      lucid,
      config,
      bootstrap,
      scripts,
    ).complete();
    await (await replay.sign.withWallet().complete()).submit();
  } catch {
    replayRejected = true;
  }
  if (!replayRejected) {
    throw new Error("Initialization replay unexpectedly succeeded.");
  }
  return {
    referencePublication,
    initializationUnsignedCbor: completed.toCBOR(),
    initializationSignedBytes: signed.toCBOR().length / 2,
    managerSeed: manager.seedPhrase,
    lucid,
    emulator,
    config,
    scripts,
    poolUtxo: outputs[0],
    mintTx,
    poolPolicyId: scripts.poolPolicyId,
    poolAddress: scripts.poolAddress,
    initiallyLocked,
    vaultSupported,
  };
}
