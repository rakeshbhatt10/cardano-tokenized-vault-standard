/** Composition/arithmetics only: synthetic certificate/State UTxOs are NOT factory
 * issuance or execution of the external controller. No completion/sign/submission. */
import { deepStrictEqual as equal, throws } from "node:assert";
import {
  CML,
  Constr,
  credentialToAddress,
  Data,
  Emulator,
  fromHex,
  Lucid,
  type UTxO,
} from "npm:@lucid-evolution/lucid@0.4.29";
import { prepareSingleStaking } from "../shared/scripts.ts";
import { encodePoolDatum, encodePositionDatum } from "../shared/datum.ts";
import { encodeVaultAuthorization, fromSdk } from "../shared/authorization.ts";
import { type Authorization, tag } from "../shared/authorization-wire.ts";
import { composeVaultOperation } from "../user/builders/vault-operation.ts";
import { positionTokenName } from "../user/builders/stake.ts";

async function fixture() {
  const config = {
    bootstrapRef: { txHash: "aa".repeat(32), outputIndex: 0n },
    manager: "11".repeat(28),
    rewardsDistributor: "11".repeat(28),
    stakingAsset: { policyId: "33".repeat(28), tokenNameHex: "41" },
    rewardAsset: { policyId: "33".repeat(28), tokenNameHex: "42" },
    initiallyLocked: false,
    vaultSupported: true,
    factoryPolicy: "55".repeat(28),
  };
  const scripts = await prepareSingleStaking(config, "Custom");
  const { vaultSupported: _v, factoryPolicy: _f, ...legacyConfig } = config;
  const controller = await prepareSingleStaking(
    legacyConfig,
    "Custom",
    "deployments/mainnet/staking-pool/plutus.json",
  );
  const owner = {
    kind: "VaultOwner" as const,
    controllerScriptHash: controller.poolPolicyId,
    statePolicyId: controller.poolPolicyId,
    stateAssetName: "5354415445",
  };
  const key = credentialToAddress("Custom", {
    type: "Key",
    hash: config.manager,
  });
  const custody = credentialToAddress("Custom", {
    type: "Script",
    hash: owner.controllerScriptHash,
  });
  const lock = credentialToAddress("Custom", {
    type: "Script",
    hash: "44".repeat(28),
  });
  const lucid = await Lucid(new Emulator([]), "Custom");
  lucid.selectWallet.fromAddress(key, []);
  const utxo = (
    hash: string,
    address: string,
    assets: Record<string, bigint>,
    datum: string,
  ): UTxO => ({
    txHash: hash.repeat(32),
    outputIndex: 0,
    address,
    assets,
    datum,
  });
  const creation = utxo(
    "bb",
    key,
    { lovelace: 5_000_000n },
    Data.to(new Constr(0, [])),
  );
  const name = positionTokenName(creation);
  const principal = config.stakingAsset.policyId +
    config.stakingAsset.tokenNameHex;
  const reward = config.rewardAsset.policyId + config.rewardAsset.tokenNameHex;
  const pool = utxo(
    "cc",
    scripts.poolAddress,
    {
      lovelace: 5_000_000n,
      [scripts.poolPolicyId + "504f4f4c"]: 1n,
      [principal]: 300_000_000n,
      [reward]: 1_000_000_000n,
    },
    encodePoolDatum({
      totalStaked: 300_000_000n,
      rewardDurationSeconds: 600n,
      periodFinishSeconds: 600n,
      rewardRate: 1_000_000n,
      lastUpdateSeconds: 100n,
      rewardPerTokenStored: 0n,
      accruedLiabilityBound: 0n,
      isPaused: false,
      isLocked: false,
    }),
  );
  const state = utxo("dd", custody, {
    lovelace: 5_000_000n,
    [owner.statePolicyId + owner.stateAssetName]: 1n,
  }, Data.to(new Constr(0, [])));
  const payout = new Constr(0, [
    new Constr(1, [owner.controllerScriptHash]),
    new Constr(1, []),
  ]);
  const position = utxo(
    "ee",
    scripts.poolAddress,
    { lovelace: 5_000_000n, [scripts.poolPolicyId + name]: 1n },
    encodePositionDatum({
      poolId: scripts.poolPolicyId,
      positionName: name,
      owner,
      payoutAddress: payout,
      stakedAmount: 100_000_000n,
      rewardPerTokenPaid: 0n,
      pendingRewards: 7_000_000n,
    }),
  );
  const cfg = utxo("ef", lock, {
    lovelace: 5_000_000n,
    [owner.statePolicyId + "4944"]: 1n,
  }, Data.to(new Constr(0, [])));
  const configHash = CML.hash_plutus_data(
    CML.PlutusData.from_cbor_bytes(fromHex(cfg.datum!)),
  ).to_hex();
  const certificate = utxo(
    "fa",
    lock,
    {
      lovelace: 5_000_000n,
      [config.factoryPolicy + owner.controllerScriptHash]: 1n,
    },
    Data.to(
      new Constr(0, [
        1n,
        owner.controllerScriptHash,
        owner.statePolicyId,
        owner.stateAssetName,
        "43545653312d4d495845442d464143544f52592d31",
        "66".repeat(32),
        configHash,
      ]),
    ),
  );
  const authorization = (entry: boolean, first = false): Authorization => ({
    kind: "staking",
    version: 1n,
    poolId: scripts.poolPolicyId,
    positionName: name,
    operation: entry ? "stake" : "withdraw_and_claim",
    amount: entry ? 50_000_000n : 20_000_000n,
    creationRef: first ? { txId: creation.txHash, index: 0n } : null,
    stateOutput: 2n,
    base: fromSdk(
      new Constr(0, [
        "43545653",
        2n,
        new Constr(entry ? 0 : 2, [
          new Constr(0, [
            new Constr(0, [new Constr(0, [config.manager]), new Constr(1, [])]),
            new Constr(1, []),
          ]),
          entry ? 50_000_000n : 20_000_000n,
          1n,
          2n,
          3n,
        ]),
      ]),
    ),
    maxRewardInput: 0n,
    minRewardOutput: 0n,
  });
  const input = {
    owner,
    authorizationCbor: encodeVaultAuthorization(authorization(true)),
    poolInput: pool,
    stateInput: state,
    configReference: cfg,
    controller: { script: controller.spendingValidator },
    positionInput: position,
    lowerBoundMs: 160_000,
  };
  return {
    lucid,
    config,
    scripts,
    input,
    authorization,
    creation,
    certificate,
    position,
  };
}

Deno.test("vault component topup preserves earned rewards and unrelated principal", async () => {
  const f = await fixture();
  const built = composeVaultOperation(f.lucid, f.config, f.scripts, f.input);
  equal(built.pool.totalStaked, 350_000_000n);
  equal(built.position.stakedAmount, 150_000_000n);
  equal(built.position.pendingRewards, 27_000_000n);
  equal(built.rewardAmount, 0n);
  equal(built.requiredStateOutputIndex, 2n);
});
Deno.test("vault component exit settles only its position without certificate lookup", async () => {
  const f = await fixture();
  const built = composeVaultOperation(f.lucid, f.config, f.scripts, {
    ...f.input,
    authorizationCbor: encodeVaultAuthorization(f.authorization(false)),
  });
  equal(built.pool.totalStaked, 280_000_000n);
  equal(built.pool.accruedLiabilityBound, 33_000_000n);
  equal(built.position.stakedAmount, 80_000_000n);
  equal(built.position.pendingRewards, 0n);
  equal(built.rewardAmount, 27_000_000n);
});
Deno.test("first vault component requires authenticated certificate and creation seed", async () => {
  const f = await fixture();
  const input = {
    ...f.input,
    positionInput: undefined,
    creationInput: f.creation,
    certificateReference: f.certificate,
    positionLovelace: 5_000_000n,
    authorizationCbor: encodeVaultAuthorization(f.authorization(true, true)),
  };
  const built = composeVaultOperation(f.lucid, f.config, f.scripts, input);
  equal(built.position.stakedAmount, 50_000_000n);
  equal(built.position.pendingRewards, 0n);
  throws(
    () =>
      composeVaultOperation(f.lucid, f.config, f.scripts, {
        ...input,
        certificateReference: undefined,
      }),
    /certificate/,
  );
  throws(
    () =>
      composeVaultOperation(f.lucid, f.config, f.scripts, {
        ...input,
        certificateReference: {
          ...f.certificate,
          assets: { lovelace: 5_000_000n },
        },
      }),
    /not authenticated/,
  );
  throws(
    () =>
      composeVaultOperation(f.lucid, f.config, f.scripts, {
        ...input,
        configReference: { ...f.input.configReference, datum: Data.to(3n) },
      }),
    /Config mismatch/,
  );
});
Deno.test("vault components reject wrong State, pool, operation and over-withdrawal", async () => {
  const f = await fixture();
  throws(
    () =>
      composeVaultOperation(f.lucid, f.config, f.scripts, {
        ...f.input,
        stateInput: { ...f.input.stateInput, assets: { lovelace: 5_000_000n } },
      }),
    /State/,
  );
  const auth = f.authorization(false);
  if (auth.kind !== "staking") throw new Error("fixture");
  throws(
    () =>
      composeVaultOperation(f.lucid, f.config, f.scripts, {
        ...f.input,
        authorizationCbor: encodeVaultAuthorization({
          ...auth,
          amount: 100_000_001n,
        }),
      }),
    /exceeds this position/,
  );
  throws(
    () =>
      composeVaultOperation(f.lucid, f.config, f.scripts, {
        ...f.input,
        authorizationCbor: encodeVaultAuthorization({
          ...auth,
          poolId: "77".repeat(28),
        }),
      }),
    /Wrong pool/,
  );
  const maintenance: Authorization = {
    kind: "maintenance",
    version: 1n,
    base: tag(0, [new Uint8Array([67, 84, 86, 83]), 2n, tag(7, [0n, 2n])]),
  };
  throws(
    () =>
      composeVaultOperation(f.lucid, f.config, f.scripts, {
        ...f.input,
        authorizationCbor: encodeVaultAuthorization(maintenance),
      }),
    /Maintenance/,
  );
});
