import type { StakerState } from "../user/state.ts";
import { buildStakeAll } from "../user/stake-all.ts";
import {
  INITIAL_REWARD_AMOUNT,
  INITIAL_REWARD_DURATION,
} from "../shared/schedule.ts";
import { loadDeployedTestTokens } from "../shared/deployed-test-tokens.ts";
import {
  fromText,
  generateEmulatorAccount,
  getAddressDetails,
  toUnit,
} from "npm:@lucid-evolution/lucid@0.4.29";
import { POOL_TOKEN_NAME } from "../owner/setup/pool.ts";
import { getReward } from "../user/builders/claim.ts";
import { notifyRewards } from "../owner/builders/notify-rewards.ts";
import { stake } from "../user/builders/stake.ts";
import { withdraw } from "../user/builders/withdraw.ts";

import { testInitializePool } from "./single-staking-fixture.ts";
export { testInitializePool } from "./single-staking-fixture.ts";

Deno.test("InitializePool ledger flow with initial lock enabled", async () => {
  await testInitializePool(true);
});
Deno.test("InitializePool ledger flow with initial lock disabled", async () => {
  await testInitializePool(false);
});

Deno.test("initialize unlocked pool then fund and notify seven-day schedule", async () => {
  const { lucid, emulator, config, scripts, poolUtxo } =
    await testInitializePool(false);
  const reward = INITIAL_REWARD_AMOUNT;
  const duration = INITIAL_REWARD_DURATION;
  const lowerMs = Math.floor(emulator.now() / 1000) * 1000;
  const built = await notifyRewards(
    lucid,
    config,
    scripts,
    poolUtxo,
    reward,
    duration,
    lowerMs,
  );
  const signed = await built.completed.sign.withWallet().complete();
  const hash = await signed.submit();
  emulator.awaitBlock(1);
  const unit = toUnit(scripts.poolPolicyId, POOL_TOKEN_NAME);
  const current = await lucid.utxosAtWithUnit(scripts.poolAddress, unit);
  if (
    current.length !== 1 || current[0].txHash !== hash ||
    current[0].datum !== built.datum
  ) throw new Error("Missing updated pool state.");
  if (
    current[0]
      .assets[
        toUnit(config.rewardAsset.policyId, config.rewardAsset.tokenNameHex)
      ] !== reward
  ) {
    throw new Error("Reward funding missing.");
  }
  if (
    built.pool.isLocked || built.pool.rewardDurationSeconds !== duration ||
    built.pool.rewardRate !== reward / duration ||
    built.pool.periodFinishSeconds !== BigInt(lowerMs / 1000) + duration
  ) throw new Error("Invalid seven-day unlocked schedule.");
  if (
    (await lucid.utxosByOutRef([{
      txHash: poolUtxo.txHash,
      outputIndex: poolUtxo.outputIndex,
    }])).length !== 0
  ) throw new Error("Initialization state was not spent.");
});

Deno.test("stake creates position then top-up preserves earned rewards", async () => {
  const { lucid, emulator, config, scripts, poolUtxo } =
    await testInitializePool(false);
  const now = () => Math.floor(emulator.now() / 1000) * 1000;
  const notified = await notifyRewards(
    lucid,
    config,
    scripts,
    poolUtxo,
    INITIAL_REWARD_AMOUNT,
    INITIAL_REWARD_DURATION,
    now(),
  );
  await (await notified.completed.sign.withWallet().complete()).submit();
  emulator.awaitBlock(1);
  const poolUnit = toUnit(scripts.poolPolicyId, POOL_TOKEN_NAME);
  const readPool = async () =>
    (await lucid.utxosAtWithUnit(scripts.poolAddress, poolUnit))[0];
  const firstTime = now();
  const first = await stake(
    lucid,
    config,
    scripts,
    await readPool(),
    100_000_000n,
    firstTime,
  );
  await (await first.completed.sign.withWallet().complete()).submit();
  emulator.awaitBlock(1);
  const positionUtxo =
    (await lucid.utxosAtWithUnit(scripts.poolAddress, first.positionUnit))[0];
  if (
    positionUtxo.assets[first.positionUnit] !== 1n ||
    first.position.stakedAmount !== 100_000_000n ||
    first.position.pendingRewards !== 0n
  ) throw new Error("Invalid new position.");
  const firstPool = await readPool();
  const stakeUnit = toUnit(
    config.stakingAsset.policyId,
    config.stakingAsset.tokenNameHex,
  );
  const rewardUnit = toUnit(
    config.rewardAsset.policyId,
    config.rewardAsset.tokenNameHex,
  );
  if (
    firstPool.assets[stakeUnit] !== 100_000_000n ||
    firstPool.assets[rewardUnit] !== INITIAL_REWARD_AMOUNT
  ) throw new Error("Principal or rewards not preserved.");
  emulator.awaitSlot(60);
  const topupTime = now();
  const topup = await stake(
    lucid,
    config,
    scripts,
    await readPool(),
    50_000_000n,
    topupTime,
    { positionUtxo },
  );
  await (await topup.completed.sign.withWallet().complete()).submit();
  emulator.awaitBlock(1);
  const expectedRewards = BigInt((topupTime - firstTime) / 1000) *
    (INITIAL_REWARD_AMOUNT / INITIAL_REWARD_DURATION);
  if (
    topup.position.stakedAmount !== 150_000_000n ||
    topup.pool.totalStaked !== 150_000_000n ||
    topup.position.pendingRewards !== expectedRewards
  ) throw new Error("Top-up failed to checkpoint old stake rewards.");
  const positions = await lucid.utxosAtWithUnit(
    scripts.poolAddress,
    first.positionUnit,
  );
  if (positions.length !== 1 || positions[0].datum !== topup.positionDatum) {
    throw new Error("Position identity or datum changed incorrectly.");
  }
  const finalPool = await readPool();
  if (
    finalPool.assets[stakeUnit] !== 150_000_000n ||
    finalPool.assets[rewardUnit] !== INITIAL_REWARD_AMOUNT
  ) throw new Error("Top-up moved reward reserves.");
  // A second wallet joins later and must not inherit past emissions.
  const bob = generateEmulatorAccount({});
  const funding = await lucid.newTx()
    .pay.ToAddress(bob.address, {
      lovelace: 20_000_000n,
      [stakeUnit]: 100_000_000n,
    })
    .pay.ToAddress(bob.address, { lovelace: 5_000_000n }).complete();
  await (await funding.sign.withWallet().complete()).submit();
  emulator.awaitBlock(1);
  lucid.selectWallet.fromSeed(bob.seedPhrase);
  const joined = await stake(
    lucid,
    config,
    scripts,
    await readPool(),
    20_000_000n,
    now(),
  );
  await (await joined.completed.sign.withWallet().complete()).submit();
  emulator.awaitBlock(1);
  if (
    joined.position.pendingRewards !== 0n ||
    joined.position.rewardPerTokenPaid !== joined.pool.rewardPerTokenStored ||
    joined.position.rewardPerTokenPaid <= 0n
  ) throw new Error("Late staker inherited historical rewards.");
  if (
    joined.pool.totalStaked !== 170_000_000n ||
    (await readPool()).assets[stakeUnit] !== 170_000_000n
  ) throw new Error("Late deposit not reflected in vault and datum.");
});

Deno.test("partial and full unstake return principal and preserve reward claims", async () => {
  const { lucid, emulator, config, scripts, poolUtxo } =
    await testInitializePool(false);
  const now = () => Math.floor(emulator.now() / 1000) * 1000;
  const send = async (
    tx: { completed: Awaited<ReturnType<typeof stake>>["completed"] },
  ) => {
    const hash = await (await tx.completed.sign.withWallet().complete())
      .submit();
    emulator.awaitBlock(1);
    return hash;
  };
  await send(
    await notifyRewards(
      lucid,
      config,
      scripts,
      poolUtxo,
      INITIAL_REWARD_AMOUNT,
      INITIAL_REWARD_DURATION,
      now(),
    ),
  );
  const poolUnit = toUnit(scripts.poolPolicyId, POOL_TOKEN_NAME);
  const read = async (unit: string) =>
    (await lucid.utxosAtWithUnit(scripts.poolAddress, unit))[0];
  const started = now();
  const first = await stake(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    100_000_000n,
    started,
  );
  await send(first);
  emulator.awaitSlot(60);
  const stakeUnit = toUnit(
    config.stakingAsset.policyId,
    config.stakingAsset.tokenNameHex,
  );
  const rewardUnit = toUnit(
    config.rewardAsset.policyId,
    config.rewardAsset.tokenNameHex,
  );
  const balance = async () =>
    (await lucid.wallet().getUtxos()).reduce(
      (sum, u) => sum + (u.assets[stakeUnit] ?? 0n),
      0n,
    );
  const beforeBalance = await balance();
  const partial = await withdraw(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    await read(first.positionUnit),
    40_000_000n,
    now(),
  );
  await send(partial);
  if (await balance() !== beforeBalance + 40_000_000n) {
    throw new Error("Partial principal was not returned to owner.");
  }
  if (
    partial.position.stakedAmount !== 60_000_000n ||
    partial.pool.totalStaked !== 60_000_000n ||
    partial.position.pendingRewards <= 0n
  ) throw new Error("Partial withdrawal lost stake/rewards.");
  const preservedRewards = partial.position.pendingRewards;
  const full = await withdraw(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    await read(first.positionUnit),
    60_000_000n,
    now(),
  );
  await send(full);
  if (await balance() !== beforeBalance + 100_000_000n) {
    throw new Error("Full principal was not returned.");
  }
  const finalPool = await read(poolUnit);
  const finalPosition = await read(first.positionUnit);
  if (
    full.pool.totalStaked !== 0n || full.position.stakedAmount !== 0n ||
    full.position.pendingRewards < preservedRewards ||
    finalPosition.assets[first.positionUnit] !== 1n
  ) throw new Error("Full withdrawal lost pending claim or position.");
  if (
    (finalPool.assets[stakeUnit] ?? 0n) !== 0n ||
    finalPool.assets[rewardUnit] !== INITIAL_REWARD_AMOUNT
  ) throw new Error("Withdrawal consumed reward reserves.");
  let rejected = false;
  try {
    await withdraw(lucid, config, scripts, finalPool, finalPosition, 1n, now());
  } catch {
    rejected = true;
  }
  if (!rejected) {
    throw new Error("Overwithdrawal from empty position accepted.");
  }
});

Deno.test("locked unstake rejects before/at finish and succeeds after expiry", async () => {
  const { lucid, emulator, config, scripts, poolUtxo } =
    await testInitializePool(true);
  const now = () => Math.floor(emulator.now() / 1000) * 1000;
  const notify = await notifyRewards(
    lucid,
    config,
    scripts,
    poolUtxo,
    INITIAL_REWARD_AMOUNT,
    INITIAL_REWARD_DURATION,
    now(),
  );
  await (await notify.completed.sign.withWallet().complete()).submit();
  emulator.awaitBlock(1);
  const poolUnit = toUnit(scripts.poolPolicyId, POOL_TOKEN_NAME);
  const read = async (unit: string) =>
    (await lucid.utxosAtWithUnit(scripts.poolAddress, unit))[0];
  const first = await stake(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    100_000_000n,
    now(),
  );
  await (await first.completed.sign.withWallet().complete()).submit();
  emulator.awaitBlock(1);
  for (const lower of [now(), Number(notify.pool.periodFinishSeconds) * 1000]) {
    let rejected = false;
    try {
      await withdraw(
        lucid,
        config,
        scripts,
        await read(poolUnit),
        await read(first.positionUnit),
        100_000_000n,
        lower,
      );
    } catch {
      rejected = true;
    }
    if (!rejected) {
      throw new Error("Locked withdrawal accepted before/at deadline.");
    }
  }
  emulator.awaitSlot(
    Number(notify.pool.periodFinishSeconds - BigInt(now() / 1000)) + 1,
  );
  const unlockedByTime = await withdraw(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    await read(first.positionUnit),
    100_000_000n,
    now(),
  );
  await (await unlockedByTime.completed.sign.withWallet().complete()).submit();
  emulator.awaitBlock(1);
  if (
    unlockedByTime.position.stakedAmount !== 0n ||
    !unlockedByTime.pool.isLocked ||
    unlockedByTime.position.pendingRewards <= 0n
  ) {
    throw new Error(
      "Expiry withdrawal incorrectly needs a manual unlock or loses rewards.",
    );
  }
});

Deno.test("Claim pays only new rewards, works while locked and after full unstake", async () => {
  const { lucid, emulator, config, scripts, poolUtxo } =
    await testInitializePool(true);
  const now = () => Math.floor(emulator.now() / 1000) * 1000;
  const send = async (
    completed: Awaited<ReturnType<typeof getReward>>["completed"],
  ) => {
    const hash = await (await completed.sign.withWallet().complete()).submit();
    emulator.awaitBlock(1);
    return hash;
  };
  const poolUnit = toUnit(scripts.poolPolicyId, POOL_TOKEN_NAME);
  const rewardUnit = toUnit(
    config.rewardAsset.policyId,
    config.rewardAsset.tokenNameHex,
  );
  const stakeUnit = toUnit(
    config.stakingAsset.policyId,
    config.stakingAsset.tokenNameHex,
  );
  const read = async (unit: string) =>
    (await lucid.utxosAtWithUnit(scripts.poolAddress, unit))[0];
  const balance = async () =>
    (await lucid.wallet().getUtxos()).reduce(
      (sum, u) => sum + (u.assets[rewardUnit] ?? 0n),
      0n,
    );
  const notified = await notifyRewards(
    lucid,
    config,
    scripts,
    poolUtxo,
    INITIAL_REWARD_AMOUNT,
    INITIAL_REWARD_DURATION,
    now(),
  );
  await send(notified.completed);
  const stakeTime = now();
  const deposit = await stake(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    100_000_000n,
    stakeTime,
  );
  await send(deposit.completed);
  emulator.awaitSlot(60);
  const initialBalance = await balance();
  const claimTime = now();
  const first = await getReward(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    await read(deposit.positionUnit),
    claimTime,
  );
  await send(first.completed);
  const rate = INITIAL_REWARD_AMOUNT / INITIAL_REWARD_DURATION;
  if (
    first.rewardAmount !== BigInt((claimTime - stakeTime) / 1000) * rate ||
    await balance() !== initialBalance + first.rewardAmount
  ) throw new Error("Incorrect first claim payout.");
  if (
    first.position.pendingRewards !== 0n ||
    first.position.stakedAmount !== 100_000_000n || !first.pool.isLocked ||
    (await read(poolUnit)).assets[stakeUnit] !== 100_000_000n
  ) throw new Error("Claim changed lock or principal.");
  const secondTime = now();
  const second = await getReward(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    await read(deposit.positionUnit),
    secondTime,
  );
  await send(second.completed);
  if (
    second.rewardAmount !== BigInt((secondTime - claimTime) / 1000) * rate ||
    await balance() !==
      initialBalance + first.rewardAmount + second.rewardAmount
  ) throw new Error("Repeated claim paid historical rewards twice.");
  // At expiry principal can leave; unclaimed rewards must still be claimable.
  emulator.awaitSlot(
    Number(notified.pool.periodFinishSeconds - BigInt(now() / 1000)) + 1,
  );
  const unstaked = await withdraw(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    await read(deposit.positionUnit),
    100_000_000n,
    now(),
  );
  await send(unstaked.completed);
  const final = await getReward(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    await read(deposit.positionUnit),
    now(),
  );
  await send(final.completed);
  if (
    final.rewardAmount !== unstaked.position.pendingRewards ||
    final.rewardAmount <= 0n || final.position.stakedAmount !== 0n ||
    final.pool.totalStaked !== 0n
  ) throw new Error("Pending claim after unstake was lost.");
  const afterFinal = await balance();
  const zero = await getReward(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    await read(deposit.positionUnit),
    now(),
  );
  await send(zero.completed);
  if (
    zero.rewardAmount !== 0n || await balance() !== afterFinal ||
    zero.position.pendingRewards !== 0n
  ) throw new Error("Zero claim replay paid already claimed rewards.");
  if ((await read(deposit.positionUnit)).assets[deposit.positionUnit] !== 1n) {
    throw new Error("Claim lost position identity.");
  }
});

Deno.test("stake-all waits for funding and deposits only the separate wallet's Test1", async () => {
  const { lucid, emulator, config, scripts, poolUtxo, managerSeed } =
    await testInitializePool(false);
  const now = () => Math.floor(emulator.now() / 1000) * 1000;
  const staker = generateEmulatorAccount({});
  lucid.selectWallet.fromSeed(staker.seedPhrase);
  if (
    await buildStakeAll(lucid, config, scripts, poolUtxo, now()) !== undefined
  ) throw new Error("Unfunded wallet should not submit a stake.");
  // Restore the funded test manager wallet solely to transfer existing test funds.
  lucid.selectWallet.fromSeed(managerSeed);
  const stakeUnit = toUnit(
    config.stakingAsset.policyId,
    config.stakingAsset.tokenNameHex,
  );
  const rewardUnit = toUnit(
    config.rewardAsset.policyId,
    config.rewardAsset.tokenNameHex,
  );
  const funding = await lucid.newTx()
    .pay.ToAddress(staker.address, {
      lovelace: 20_000_000n,
      [stakeUnit]: 75_000_000n,
      [rewardUnit]: 5_000_000n,
    })
    .pay.ToAddress(staker.address, {
      lovelace: 20_000_000n,
      [stakeUnit]: 25_000_000n,
    })
    .pay.ToAddress(staker.address, { lovelace: 5_000_000n }).complete();
  await (await funding.sign.withWallet().complete()).submit();
  emulator.awaitBlock(1);
  lucid.selectWallet.fromSeed(staker.seedPhrase);
  const built = await buildStakeAll(lucid, config, scripts, poolUtxo, now());
  if (!built || built.amount !== 100_000_000n) {
    throw new Error("Full Test1 balance across UTxOs was not selected.");
  }
  await (await built.completed.sign.withWallet().complete()).submit();
  emulator.awaitBlock(1);
  const remaining = await lucid.wallet().getUtxos();
  if (
    remaining.reduce((sum, u) => sum + (u.assets[stakeUnit] ?? 0n), 0n) !== 0n
  ) throw new Error("Test1 remained unstaked.");
  if (
    remaining.reduce((sum, u) => sum + (u.assets[rewardUnit] ?? 0n), 0n) !==
      5_000_000n
  ) throw new Error("Stake-all consumed Test2.");
});

Deno.test("unstake-all supports partial then full withdrawal without losing the position", async () => {
  const { buildUnstakeAll } = await import("../user/unstake-all.ts");
  const { lucid, emulator, config, scripts, poolUtxo } =
    await testInitializePool(false);
  const now = () => Math.floor(emulator.now() / 1000) * 1000;
  const deposit = await stake(
    lucid,
    config,
    scripts,
    poolUtxo,
    100_000_000n,
    now(),
  );
  await (await deposit.completed.sign.withWallet().complete()).submit();
  emulator.awaitBlock(1);
  const poolUnit = toUnit(scripts.poolPolicyId, fromText("POOL"));
  const read = async (unit: string) => {
    const outputs = await lucid.utxosAtWithUnit(scripts.poolAddress, unit);
    if (outputs.length !== 1) throw new Error("Expected one identity output.");
    return outputs[0];
  };
  const partial = await buildUnstakeAll(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    await read(deposit.positionUnit),
    now(),
    40_000_000n,
  );
  if (!partial || partial.position.stakedAmount !== 60_000_000n) {
    throw new Error("Partial withdrawal selected an incorrect amount.");
  }
  await (await partial.completed.sign.withWallet().complete()).submit();
  emulator.awaitBlock(1);
  const full = await buildUnstakeAll(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    await read(deposit.positionUnit),
    now(),
  );
  if (
    !full || full.amount !== 60_000_000n || full.position.stakedAmount !== 0n
  ) {
    throw new Error("Full withdrawal did not select the remaining stake.");
  }
  await (await full.completed.sign.withWallet().complete()).submit();
  emulator.awaitBlock(1);
  const position = await read(deposit.positionUnit);
  if (position.assets[deposit.positionUnit] !== 1n) {
    throw new Error("Position NFT was lost.");
  }
  if (
    await buildUnstakeAll(
      lucid,
      config,
      scripts,
      await read(poolUnit),
      position,
      now(),
    ) !== undefined
  ) {
    throw new Error("Empty position must not submit another withdrawal.");
  }
});

Deno.test("unstake amount defaults to all and rejects malformed or nonpositive quantities", async () => {
  const { parseUnstakeAmount } = await import("../user/unstake-all.ts");
  if (
    parseUnstakeAmount(undefined) !== undefined ||
    parseUnstakeAmount("10000000") !== 10_000_000n
  ) {
    throw new Error("Incorrect withdrawal amount selection.");
  }
  for (const value of ["", "0", "-1", "1.5", "1e6", " 10", "all"]) {
    let rejected = false;
    try {
      parseUnstakeAmount(value);
    } catch {
      rejected = true;
    }
    if (!rejected) throw new Error(`Accepted invalid amount: ${value}`);
  }
});

Deno.test("staker journal blocks deposits during pending withdrawals and withdrawals during pending deposits", async () => {
  const { prepareStaking } = await import("../user/stake-all.ts");
  const { prepareWithdrawal } = await import("../user/unstake-all.ts");
  const { prepareClaim } = await import("../user/claim-all.ts");
  const { saveStakerState } = await import("../user/state.ts");
  const { lucid, scripts } = await testInitializePool(false);
  const tokens = await loadDeployedTestTokens();
  const owner =
    getAddressDetails(await lucid.wallet().address()).paymentCredential;
  if (owner?.type !== "Key") throw new Error("Expected owner key.");
  const directory = await Deno.makeTempDir({
    dir: "/private/tmp",
    prefix: "unstake-journal-",
  });
  const context = {
    lucid,
    tokens,
    network: tokens.network,
    owner: owner.hash,
    path: `${directory}/state.json`,
    deploymentPath: `${directory}/must-not-be-read.json`,
    blueprintPath: "plutus.json",
  };
  const state = {
    owner: owner.hash,
    poolPolicyId: scripts.poolPolicyId,
    positionUnit: scripts.poolPolicyId + "aa",
  };
  const expectBlocked = async (
    operation: () => Promise<unknown>,
    message: string,
  ) => {
    try {
      await operation();
    } catch (error) {
      if (error instanceof Error && error.message === message) return;
      throw error;
    }
    throw new Error("Overlapping wallet operation was accepted.");
  };
  try {
    await saveStakerState(context.path, {
      ...state,
      pendingWithdrawal: {
        txHash: "ab".repeat(32),
        amount: "100",
        expectedStakedAmount: "0",
      },
    });
    await expectBlocked(
      () => prepareStaking(context),
      "Resume unstake-all.ts before starting another deposit.",
    );
    await expectBlocked(
      () => prepareClaim(context),
      "Resume unstake-all.ts before starting a claim.",
    );
    await saveStakerState(context.path, { ...state, txHash: "cd".repeat(32) });
    await expectBlocked(
      () => prepareWithdrawal(context),
      "Resume stake-all.ts before starting a withdrawal.",
    );
    await expectBlocked(
      () => prepareClaim(context),
      "Resume stake-all.ts before starting a claim.",
    );
    await saveStakerState(context.path, {
      ...state,
      pendingClaim: {
        txHash: "ef".repeat(32),
        rewardAmount: "100",
        expectedPositionDatum: "unused",
      },
    });
    await expectBlocked(
      () => prepareStaking(context),
      "Resume claim-all.ts before starting another deposit.",
    );
    await expectBlocked(
      () => prepareWithdrawal(context),
      "Resume claim-all.ts before starting a withdrawal.",
    );
  } finally {
    await Deno.remove(directory, { recursive: true });
  }
});

Deno.test("claim-all pays after full withdrawal, saves confirmed state and skips a zero claim", async () => {
  const { buildClaimAll, refreshClaimState } = await import(
    "../user/claim-all.ts"
  );
  const { readStakerState, saveStakerState } = await import(
    "../user/state.ts"
  );
  const { lucid, emulator, config, scripts, poolUtxo } =
    await testInitializePool(false);
  const now = () => Math.floor(emulator.now() / 1000) * 1000;
  const send = async (
    completed: Awaited<ReturnType<typeof stake>>["completed"],
  ) => {
    const signed = await completed.sign.withWallet().complete();
    const hash = await signed.submit();
    emulator.awaitBlock(1);
    return hash;
  };
  const poolUnit = toUnit(scripts.poolPolicyId, POOL_TOKEN_NAME);
  const read = async (unit: string) =>
    (await lucid.utxosAtWithUnit(scripts.poolAddress, unit))[0];
  const notified = await notifyRewards(
    lucid,
    config,
    scripts,
    poolUtxo,
    INITIAL_REWARD_AMOUNT,
    INITIAL_REWARD_DURATION,
    now(),
  );
  await send(notified.completed);
  const deposit = await stake(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    100_000_000n,
    now(),
  );
  await send(deposit.completed);
  emulator.awaitSlot(60);
  const unstaked = await withdraw(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    await read(deposit.positionUnit),
    100_000_000n,
    now(),
  );
  await send(unstaked.completed);
  const rewardUnit = toUnit(
    config.rewardAsset.policyId,
    config.rewardAsset.tokenNameHex,
  );
  const balance = async () =>
    (await lucid.wallet().getUtxos()).reduce(
      (sum, u) => sum + (u.assets[rewardUnit] ?? 0n),
      0n,
    );
  const before = await balance();
  const built = await buildClaimAll(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    await read(deposit.positionUnit),
    now(),
  );
  if (
    !built || built.rewardAmount <= 0n || built.position.stakedAmount !== 0n
  ) {
    throw new Error("Zero-stake position lost accrued rewards.");
  }
  const hash = await send(built.completed);
  if (await balance() !== before + built.rewardAmount) {
    throw new Error("Reward payout mismatch.");
  }
  const owner =
    getAddressDetails(await lucid.wallet().address()).paymentCredential;
  if (owner?.type !== "Key") throw new Error("Expected owner key.");
  const tokens = await loadDeployedTestTokens();
  const directory = await Deno.makeTempDir({
    dir: "/private/tmp",
    prefix: "claim-journal-",
  });
  const context = {
    lucid,
    tokens,
    network: tokens.network,
    owner: owner.hash,
    path: `${directory}/state.json`,
    deploymentPath: "unused",
    blueprintPath: "plutus.json",
  };
  const state: StakerState = {
    owner: owner.hash,
    poolPolicyId: scripts.poolPolicyId,
    positionUnit: built.positionUnit,
    pendingClaim: {
      txHash: hash,
      rewardAmount: built.rewardAmount.toString(),
      expectedPositionDatum: built.positionDatum,
    },
  };
  try {
    await saveStakerState(context.path, state);
    await refreshClaimState({
      context,
      state,
      config,
      scripts,
      positionUnit: built.positionUnit,
      poolUnit,
    });
    const saved = await readStakerState(context.path, owner.hash);
    if (saved?.pendingClaim || saved?.positionRef?.txHash !== hash) {
      throw new Error("Claim progress not reconciled.");
    }
    const archived = JSON.parse(
      await Deno.readTextFile(`${context.path}.last-claim.json`),
    );
    if (archived.pendingClaim.txHash !== hash) {
      throw new Error("Claim history lost.");
    }
  } finally {
    await Deno.remove(directory, { recursive: true });
  }
  if (
    await buildClaimAll(
      lucid,
      config,
      scripts,
      await read(poolUnit),
      await read(built.positionUnit),
      now(),
    ) !== undefined
  ) {
    throw new Error(
      "Already claimed rewards must not create another transaction.",
    );
  }
});

Deno.test("vault-supported pool initializes unlocked using compiled scripts", async () => {
  await testInitializePool(false, true);
});

Deno.test("legacy wallet builders retain original position and redeemer formats", async () => {
  const { lucid, emulator, config, scripts, poolUtxo } =
    await testInitializePool(
      false,
      false,
      "deployments/mainnet/staking-pool/plutus.json",
    );
  const now = () => Math.floor(emulator.now() / 1000) * 1000;
  const send = async (
    completed: Awaited<ReturnType<typeof stake>>["completed"],
  ) => {
    await (await completed.sign.withWallet().complete()).submit();
    emulator.awaitBlock(1);
  };
  const poolUnit = toUnit(scripts.poolPolicyId, fromText("POOL"));
  const read = async (unit: string) =>
    (await lucid.utxosAtWithUnit(scripts.poolAddress, unit))[0];
  const notification = await notifyRewards(
    lucid,
    config,
    scripts,
    poolUtxo,
    70_000_000n,
    604_800n,
    now(),
  );
  await send(notification.completed);
  const deposit = await stake(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    10_000_000n,
    now(),
  );
  await send(deposit.completed);
  const topup = await stake(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    1_000_000n,
    now(),
    { positionUtxo: await read(deposit.positionUnit) },
  );
  await send(topup.completed);
  emulator.awaitSlot(10);
  const claim = await getReward(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    await read(deposit.positionUnit),
    now(),
  );
  await send(claim.completed);
  const withdrawal = await withdraw(
    lucid,
    config,
    scripts,
    await read(poolUnit),
    await read(deposit.positionUnit),
    11_000_000n,
    now(),
  );
  await send(withdrawal.completed);
  if (
    scripts.positionSchemaVersion !== 1 ||
    withdrawal.position.stakedAmount !== 0n
  ) throw new Error("Legacy position lifecycle changed.");
});

Deno.test("staking builders reject a reference carrying another pool program", async () => {
  const a = await testInitializePool(false);
  const b = await testInitializePool(false);
  if (!b.scripts.referenceUtxo) {
    throw new Error("Expected actual reference script fixture.");
  }
  const { rejects } = await import("node:assert");
  await rejects(
    () =>
      stake(
        a.lucid,
        a.config,
        { ...a.scripts, referenceUtxo: b.scripts.referenceUtxo },
        a.poolUtxo,
        1_000_000n,
        Math.floor(a.emulator.now() / 1000) * 1000,
      ),
    /reference does not carry/,
  );
});
