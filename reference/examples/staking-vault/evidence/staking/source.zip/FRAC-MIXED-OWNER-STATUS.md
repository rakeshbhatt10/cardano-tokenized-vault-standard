# frac mixed-owner implementation status

26 October 2026. Branch `codex/mixed-owner-staking`; uncommitted working tree.
Only `frac` was edited. No production keys or factory identity were selected, and
no live signing, submission, deployment or fund movement was executed. Local
emulator checks use ephemeral fixture signing; exported evidence is unsigned.

## Task status

| Task | Status |
| --- | --- |
| F1 | Implemented: v1 authorization, consumed State/continuation, exact pool/position/action/mint correlation |
| F2 | Implemented in staking: factory-gated OpenPosition and exact owner/Config/assets/seed binding |
| F3 | Implemented: vault first stake and top-up in matching pool/position spend paths |
| F4 | Implemented: appended action tag 10, combined settlement and restricted registered-controller distribution |
| F5 | Preserved: permanent unlock for vault pools, deposit-only pause, protected manager recovery and wallet-only lock behavior |
| F6 | Implemented: unsigned composable vault component, versioned records/configuration and hash-verified references |
| F7 | Staking components and compiled wallet regressions pass; full transactions with two actual factory-created controllers remain unproved |
| F8 | Local source-bound build, vectors, unsigned emulator evidence and reproducer exported; vault-side import and full integration acceptance remain pending |

## Runtime behavior

The live staking validator now accepts a VaultOwner only through the configured
factory profile. First creation verifies the authentic referenced certificate NFT
and Config ID, supported implementation, full Config hash, pool/position seed and
asset binding. Authentic factory issuance proves the instance derivation; staking
does not duplicate the factory's compiled-template application proof.

Every vault staking operation consumes its controller State, preserves its NFT
and required continuation, and matches the exact outer operation. The immutable
admitted controller must execute the full shared decoder and enforce its inner
action, shareholder economics, fees, payouts and State reserves. The staking
program independently enforces position ownership, principal, reward checkpoints,
liability, pool reserves, NFT scope and storage. Its smaller runtime projection
is not a permission to use an arbitrary unregistered script.

Combined exit settles only this position's earned rewards and principal. Wallet
payouts remain checked by staking. The registered-controller route explicitly
delegates exact shareholder distribution to the executing recognized controller,
as selected by shared interface v1. Standalone vault Withdraw/Claim and vault
position closure still reject. Empty vault positions remain reusable.

Registration is required only at first creation. Subsequent top-ups and exits do
not require a revocable registry permission or a repeated certificate lookup.
The controller's own immutable Config authentication remains required.

## Builders and records

`composeVaultOperation` in `offchain/user/builders/vault-operation.ts` returns an
unfinished unsigned builder plus the calculated next pool/position states. It
adds staking/controller inputs and witnesses and the staking continuations.
The caller must add the State continuation at the authorized index, share
mint/burn, receiver/fee outputs and funding, then evaluate the complete transaction.
It never selects an owner wallet, signs or submits. Config references are supplied
on every operation; certificate references are required only for creation.

New public preparation records identify interface/schema version, supported owner
modes and withdrawal-lock policy. Archived six-/seven-parameter formats and old
Mainnet deployment identities remain separate and unchanged.

## Verification boundary

Final local checks: **265/265 Aiken tests and 74/74 Deno tests pass**. TypeScript
entry-point checks, changed-file lint and Git whitespace checks also pass.

Aiken tests cover the actual mint/pool/position staking handlers, mixed ownership,
nonempty entry, two distinct controller identities, rewards, combined exits,
standalone-action rejection, wrong evidence, payout/reserve theft and legacy rules.
Certificates/State used in staking component fixtures are synthetic; those tests
do not establish actual factory issuance or execute the independent vault code.

Deno tests include final compiled staking-script wallet transactions under real
fixture limits and unsigned vault-component planning tests. The latter do not
complete/evaluate the external vault controller. No emulator transaction-size
limit was raised. Reference publication was measured with its actual fixture
key witness; the reference UTxO is actually published in the synthetic ledger.

The local handoff is [integration/mixed-owner-v1](integration/mixed-owner-v1/README.md).
It includes exact build/source hashes, the blueprint, source archive, shared CBOR
vectors and unsigned reference-publication/initialization evidence.

## Remaining integration gate — outside frac

The existing workshop checkpoint reports a mixed controller template of 18,163
bytes and a factory-controller publication assessment of 18,577 script bytes,
which cannot fit the unchanged 16,384-byte transaction limit. That repository
must reduce/publish its final controller, demonstrate genuine automatic factory
registration, import this fresh staking build, and run successful complete
wallet-plus-two-vault deposit/top-up/withdraw/redeem/re-entry transactions.

Consequently F7/full F8 acceptance is NOT complete and readiness/execution flags
remain false. Do not substitute planner tests, synthetic certificates, fictitious
reference outputs or an identity-only factory probe for that evidence.
