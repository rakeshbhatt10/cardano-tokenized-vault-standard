# Shared vault authorization v1 and staking runtime

The shared wire contract is defined by `MIXED-OWNER-INTERFACE.json`, the strict
`authorization.decode` / TypeScript codecs and shared golden CBOR vectors.
Position schema v2 is independent of authorization envelope v1.

The live validator now implements factory-admitted position creation, stake/top-up
and tag-10 WithdrawAndClaim. See [implementation status](FRAC-MIXED-OWNER-STATUS.md)
for the exact remaining external integration gate.

- Eight immutable parameters end in `factory_policy: Option<PolicyId>`.
  Vault-supported pools require an explicit authentic factory policy and remain
  permanently unlocked; wallet-only pools use None and retain optional locks.
- Admission checks occur at first position creation. The authentic certificate
  binds the recognized controller/State identity and full immutable Config. The
  configured factory proves one-shot issuance and exact instance derivation.
- Every operation independently requires consumed State and the matching action
  and continuation. Registration alone never permits spending funds.
- Existing positions preserve their admitted owner and custody binding. Valid
  exits do not depend on a later registry decision or a certificate reference.
- The standalone full evidence helper checks the complete shared decoder and
  exact transaction purposes. The live validator already checks those staking
  purposes in its own handlers, so it calls the State-permission layer. Its
  lean `decode_evidence` projection is valid only with an executing admitted
  controller, which must run the full strict decoder and verify its inner action.
  This avoids embedding the same controller decoder/economics in both programs.
- The selected direct-distribution profile delegates share burns, gross/net fees,
  exact receiver payments and retained reward basket to the recognized controller.
  Staking retains exact position/principal/reward/liability/reserve obligations.
- Wallet standalone actions remain available. Vault standalone Withdraw/Claim,
  Exit/CloseEmptyPosition and position NFT burns remain unsupported.

No production factory policy is provided. Source code support and local staking
checks do not establish successful creation/execution of the external controller.
Existing production artifacts are unchanged; deployment/execution remain disabled.
